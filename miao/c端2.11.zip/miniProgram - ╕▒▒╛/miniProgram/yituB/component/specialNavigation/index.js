const app = getApp();

//此组件引用方法  <Nav type='1'></Nav> / <Nav type='2' title='全部辩论'></Nav>

Component({
    properties: {
        // 这里定义了innerText属性，属性值可以在组件使用时指定
        tab: {
            type: String,
            value: '0',
        },
      noshow: {
        type: Boolean,
        value: !1,
      }
    },
    data: {
    },
    methods: {
      toIndex(){
        wx.redirectTo({
          url: '/pages/index_message_list/index',
        })
 
      },
      toProject(){
        
        wx.redirectTo({
          url: '/pages/project_list/index',
        })
 
      },
      toManage(){
        
        wx.redirectTo({
          url: '/pages/manage_1index_list/userdetail',
        })

      },
      toMine(){
        
        wx.redirectTo({
          url: '/pages/user-detail/userdetail',
        })
  
      }
    }
})
