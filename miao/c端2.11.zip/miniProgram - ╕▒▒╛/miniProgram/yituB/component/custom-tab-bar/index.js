const app = getApp()
Component({
  /**
   * 组件的属性列表
   */
  properties: {
  },

  data: {
    selected: app.tabSelIdx,
    color: "#7A7E83",
    selectedColor: "#08b2c1",
    list: [
      {
        "pagePath": "../i_sel_site/index1",
        "text": "购票1",
        "iconPath": "../../images/price012.png",
        "selectedIconPath": "../../images/price011.png"
      },
      {
        "pagePath": "../ticketsDetail/index",
        "text": "验票",
        "iconPath": "../../images/tablist012.png",
        "selectedIconPath": "../../images/tablist011.png"
      },
      {
        "pagePath": "../user-detail/userdetail",
        "text": "我的",
        "iconPath": "../../images/my011.png",
        "selectedIconPath": "../../images/my012.png"
      }
    ]
  },
  attached() {
  },
  methods: {
    switchTab(e) {
      const data = e.currentTarget.dataset
      app.tabSelIdx = data.index;
      console.log(app.tabSelIdx)
      const url = data.path
      // wx.switchTab({url})
      // wx.navigateTo({
      //   url: '',
      // })
      wx.reLaunch({
        url: url,
      })
      // wx.navigateTo({ url: '../user_address/address' }); // 跳转到售票页面
      this.setData({
        selected: data.index
      })
    }
  }
})