// miniprogram/pages/user_order_list/index.js
const app = getApp()
Component({

  properties: {
    huanzhe: {
      type: Object
    },
    proInfo: {
      type: Object
    },
    huanzheImg: {
      type: Object
    },
    
    myTitle: {
      type: String
    },

  },

  /**
   * 页面的初始数据
   */
  data: {
    sex:['男','女'],
    guomin: ['否', '是'],
    array1: [
      '患者信息模板', "图片上传模板", "设定日程模板", "文件上传模板", "视频上传模板", "设定时间模板", 
      // { 'name':"患者信息模板", val:'1' },
      // { 'name': "图片上传模板", val: '2' },
      // { 'name': "设定日程模板", val: '3' },
      // { 'name': "文件上传模板", val: '4' },
      // { 'name': "视频上传模板", val: '5' },
      // { 'name': "设定时间模板", val: '6' },
      ],
    index1: 0,

    array2: [
      '患者信息模板', "图片上传模板", "设定日程模板", "文件上传模板", "视频上传模板", "设定时间模板",
    ],
    index2: 0,
    
    patientNameStu:true, // 患者名称 


    "projectCode": "",//项目编码
    "eventCode": "",//事件编号
    "patientName": "",//患者姓名
    "sexIdx": 1,//性别  1：男 2：女
    "idType": 1,//证件类型
    "idNumber": "31212121212121",//证件号码
    "birthday": null,//出生年月
    "weight": "",//患者体重
    "guominIdx": 0,//是否有过敏史 0:否 1：是
    "allergyDetail": null,//过敏史描述
    "disease": null,//诊断病情
    "diseaseDetail": null,//病情详情

  },

  /**
   * 组件的方法列表
   */
  methods: {

    // 性别选择
    bindPickerChange1(e) {
      this.setData({
        sexIdx: e.detail.value
      })
    },

    // 是否有过敏史 选择
    bindGuominChange(e) {
      this.setData({
        guominIdx: e.detail.value
      })
    },
    


    // 执行人选择
    bindPickerChange2(e) {
      this.setData({
        index2: e.detail.value
      })
    },

    // 显示加载动画
    showLoading: function () {
      wx.showLoading({
        title: '加载中...',
        icon: 'loading'
      })
    },


    /**
      *  患者名称验证
      */
    patientNameBlur(e) {
      var that = this;
      let proName = e ? e.detail.value : e;
      if (proName.length > 3 && proName.length <= 15) {
        that.setData({ patientNameStru: true })
      } else {
        that.setData({ patientNameStu: false })
      }
      that.setData({
        ['huanzhe.patientName']: proName,
      })
    },
    
  },
})