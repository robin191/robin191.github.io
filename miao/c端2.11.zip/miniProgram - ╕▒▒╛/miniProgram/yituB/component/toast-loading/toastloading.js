// component/toast-loading/toastloading.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    toastList:{
      type:Array
    },
    myTitle: {
      type: String
    },
    myInfo:{
      type:String
    },
    toastIsShow:{
      type:Boolean
    }

  },
 
  /**
   * 组件的初始数据
   */
  data: {
    title: 'no',
  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
