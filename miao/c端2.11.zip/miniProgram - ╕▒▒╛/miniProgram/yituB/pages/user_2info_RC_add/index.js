// miniprogram/pages/user_1info_hospital/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '新增日程', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    isDefault: false,

    toastTitle: '',
    toastInfo: '',
    toastIsStu: false,

    longitude: '',
    latitude: '',
    address: '',
    content: '',
    contentStu: true,

    startdate: "2016-09-01",
    startweek: '周三',
    starttime: "12:01",

    enddate: "2016-09-01",
    endtweek: '周三',
    endtime: "12:01",
    isRead: true,
    dates: [
      '无通知', '提前15分钟通知', '提前30分钟通知', '提前1小时通知', '提前1天通知', '提前2天通知'
    ],
    datesIdx:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    if (options) {
      if (options.type) {
        this.setData({
          isRead: false,
          nvabarData: {
            showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
            title: '设定日程模板', //导航栏 中间的标题
          },
        })
        // wx.setNavigationBarTitle({
        //   title: '设定日程模板',
        // })
      }
    }
  },
  getNoticeTime(e){
    this.setData({
      datesIdx:e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
    let dates = new Date();
    let month = parseInt(dates.getMonth() + 1) + ''
    let nowDate = dates.getFullYear() + '-' + (month > 9 ? month : ('0' + month)) + '-' + (dates.getDate() > 9 ? dates.getDate() : ('0' + dates.getDate()))
    let week = this.getWeekDate(dates);
    let time = dates.getHours() + ':' + dates.getMinutes();
    this.setData({
      startdate: nowDate,
      enddate: nowDate
    });

    this.setData({
      startweek: week,
      endtime: week
    });
    this.setData({
      starttime: time,
      endtime: parseInt(dates.getHours() + 1) + ':' + dates.getMinutes()
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  switchChangeDefault(e) {
    if (!this.data.isRead) {
      this.setData({
        isDefault: false
      });
      return;
    }
    this.setData({
      isDefault: e.detail.value
    });
    if (this.data.isDefault) {
      this.setData({
        enddate: this.data.startdate,
        endtweek: this.data.startweek,
        starttime: '00:00',
        endtime: '23:59',
      })
    }
  },

  getWeekDate(now) {
    var day = now.getDay();
    var weeks = new Array("星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六");
    var week = weeks[day];
    return week;
  },

  startDateChange: function(e) {
    console.log(this.data.isDefault)
    if (!this.data.isDefault) {
      let dates = new Date(e.detail.value);
      let week = this.getWeekDate(dates);
      this.setData({
        startdate: e.detail.value,
        startweek: week
      })
    }
  },
  endDateChange: function(e) {
    let dates = new Date(e.detail.value);
    let week = this.getWeekDate(dates);
    this.setData({
      enddate: e.detail.value,
      endweek: week
    })
  },

  startTimeChange: function(e) {
    this.setData({
      starttime: e.detail.value
    })
  },
  endTimeChange: function(e) {
    this.setData({
      endtime: e.detail.value
    })
  },


  // 添加日程 api
  addSchedule() {
    let that = this;

    if (that.data.content.length < 2) {
      that.toastSetWay('', '请输入日程标题(至少2个字)', true);
      return;
    }


    let start = that.data.startdate + ' ' + that.data.starttime;
    let end = that.data.enddate + ' ' + that.data.endtime;
    let starts = new Date(start)
    let ends = new Date(end)
    console.log('------------', start, end)
    if (ends < starts) {
      that.toastSetWay('', '重新选择结束时间（结束时间小于开始时间）', true);
      return;
    }


    let params = {
      "noticeType":this.data.datesIdx,
      "address": that.data.address, //日程地址
      "lngNum": that.data.longitude, //经度
      "latNum": that.data.latitude, //纬度
      "content": that.data.content, //日程内容
      "beginTime": that.data.startdate + ' ' + that.data.starttime + ':00', //日程开始时间
      "endTime": that.data.enddate + ' ' + that.data.endtime + ':00' //结束时间
    };
    console.log('-----------', params)
    app.agriknow2.addSchedule(params).then(res => {
      if (res.code === 0) {
        that.toastSetWay('', '添加成功', true);
        setTimeout(function() {
          wx.navigateBack({

          })
        }, 1500)
      }
    })
  },

  /**
   *  备注信息验证
   */
  contentBlur(e) {
    var that = this;
    let content = e.detail.value;
    if (content.length > 1 && content.length <= 15) {
      that.setData({
        contentStu: true
      })
    } else {
      that.setData({
        contentStu: false
      })
    }
    that.setData({
      content: content,
    })
  },

  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({
      toastTitle: title,
      toastInfo: info,
      toastIsStu: true
    });
    var time = setInterval(function() {
      that.setData({
        toastTitle: title,
        toastInfo: info,
        toastIsStu: false
      });
      clearInterval(time);
    }, 3000);
  },

  // 添加日程
  addProjectBtn() {
    wx.reLaunch({
      url: '../user-detail/userdetail',
    })
  },


  // 选择上传站点
  mapAddress() {
    var that = this;
    wx.chooseLocation({
      success: function(res) {
        // success
        that.setData({
          // hasLocation: true,
          longitude: res.longitude,
          latitude: res.latitude,
          address: res.name,
          name: res.name
        })
        app.selUserSite = {
          type: 1,
          address: res.name,
          addressCompany: that.data.addressCompany
        }
      },
      fail: function() {
        // fail
      },
      complete: function() {
        // complete
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})