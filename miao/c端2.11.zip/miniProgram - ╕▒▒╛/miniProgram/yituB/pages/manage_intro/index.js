// miniprogram/pages/user_1info_hospital/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '推荐管理', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    array1: [{
      addrName:'全部地区'
    }],
    index1: 0,
    tab:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getCity()
   
  },
  toConfirm(e){
    wx.navigateTo({
      url: '/pages/index_message_detail_diagnosis/index?tel='+e.currentTarget.dataset.phone,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  changeTab(e){
    this.setData({
      tab:e.currentTarget.dataset.index
    })
    this.getlist()
  },
  getlist(){
    let that=this
    app.agriknow2.queryHospitalRecommends({
      isConfirm: parseInt(this.data.tab)+1,
      city:this.data.cityid,
      nickName: this.data.nickname
    }).then(res=>{
      console.log(res)
      if(res.code==0){
        that.setData({
          huanzhelist: res.page.list
        })
      }else{
        wx.showToast({
          title: res.msg,
          icon:'none'
        })
      }
      
    })
  },
  getCity(){
    let that =this
    app.agriknow2.queryRegionList({
      "page": "1",
      "limit": "1000",
    }).then(res=>{
      console.log(res)
      that.setData({
        array1: that.data.array1.concat(res.page.list)
      })
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getlist();
  },


  // 地区选择
  bindPickerChange1(e) {
    this.setData({
      index1: e.detail.value,
      cityid:this.data.array1[e.detail.value].id
    })
    this.getlist()
  },

  getnickname(e){
    this.setData({
      nickname:e.detail.value
    })
  },
  clearNickname(){
    this.setData({
      nickname: ''
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})