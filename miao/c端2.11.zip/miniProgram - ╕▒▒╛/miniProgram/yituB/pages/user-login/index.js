// miniprogram/pages/login-user/index.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '医好康', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    dataStu: 0,
    toastTitle: '',
    toastInfo: '',
    toastIsStu: false,
    hasUserInfo:{},
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log(wx.getStorageSync('userInfo'))
    console.log(wx.getStorageSync('userInfo'), (!wx.getStorageSync('userInfo')));
    console.log(wx.getStorageSync('userInfoPho'), (!wx.getStorageSync('userInfoPho')));
    if (!wx.getStorageSync('userInfo')) {
      this.setData({ dataStu: 0 });
    } else if (!wx.getStorageSync('userInfoPho')) {
      this.setData({ dataStu: 1 });
    }
  },
  // 初始化数据
  initWay() {

  },


  // onGetOpenid: function () {
  //   // 调用云函数
  //   wx.cloud.callFunction({
  //     name: 'login',
  //     data: {},
  //     success: res => {
  //       console.log('[云函数] [login] user openid: ', res.result.openid)
  //       app.globalData.openid = res.result.openid
  //       wx.navigateTo({
  //         url: '../userConsole/userConsole',
  //       })
  //     },
  //     fail: err => {
  //       console.error('[云函数] [login] 调用失败', err)
  //       wx.navigateTo({
  //         url: '../deployFunctions/deployFunctions',
  //       })
  //     }
  //   })
  // },


  // 获取用户微信信息
  getUserInfo: function (e) {
    app.globalData.userInfo = e.detail.userInfo;
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },




  // 根据code获取微信用户的openId等信息
  getAppId(userInfo) {
    var that = this;
    wx.login({
      success: function (res) {
        let code = res.code;
        app.agriknow2.userLogin({ code: code }).then(res => {
          if (res.code === 0) {
            wx.setStorageSync('token', res.token);
            that.getPhoneNumber(userInfo, res.token); // 用户信息解密
          }
        })
      }
    })
  },

  // 获取用户信息
  onGotUserInfo: function (e) {
    var that = this;
    console.log('获取用户信息=================', e.detail.userInfo )
    this.setData({ hasUserInfo: e.detail.userInfo });
    app.globalData.userInfo = e.detail.userInfo;
    let encryptedData = e.detail.encryptedData;
    let iv = e.detail.iv;
    this.setData({ userInfo: e.detail.userInfo });
    wx.login({
      success: function (res) {
        let code = res.code;
       // 登录 获取 token
       console.log('登录==============',code);
        app.agriknow2.userLogin({ code: code }).then(res => {
          let token = res.token;
          let sessionId = res.sessionId;
          if (res.code === 0) {
            wx.setStorageSync('token', res.token); 
            app.agriknow2._defaultHeaderToken.token = token;
            app.agriknow2._urlencodedToken.token = token;
             // 解析用户信息
            app.agriknow2.userAdd({ userInfo: encryptedData, userInfoIv: iv }, token).then(res => {
              wx.setStorageSync('userInfo', JSON.stringify(res.data));
              that.setData({ dataStu: 1 });
            })
          }
        })
      }
    })
  },

  getHighestRoleLevelByUserCode() {
    let that = this;
    app.agriknow2.getHighestRoleLevelByUserCode('', 'noloading').then(res => {
      if (res.code === 0) {
        let data = res.doctorHospitalRelation;
        wx.setStorageSync('hosCode', data.hospitalCode); // 医院code
        wx.setStorageSync('docCode', data.doctorCode); // 医生code
        wx.setStorageSync('roleLevel', data.roleLevel); // 权限
        wx.setStorageSync('docInfo', data.roleCode)
        wx.setStorageSync('userType', data.type)
        if (data.roleCode == 'CLINIC_ROLE_DOCTOR' || data.roleCode == 'HOSPITAL_ROLE_DOCTOR' || !data.roleCode) {
          wx.setStorageSync('noshow', !0) // 控制医生状态下底部导航不显示管理模块
        }
        if (!data.roleCode){
          wx.setStorageSync('noRole', !0)
        }
        wx.reLaunch({
          url: '../index_message_list/index',
        })
        // 超级管理员 管理员 没有患者推荐功能
        // 导诊员  只有 推荐患者 推荐报表
        // 普通医生没有管理权限
        // 诊所，没有科室管理

        // 医院角色 - 超级管理员 HOSPITAL_ROLE_SUPER_ADMIN
        // 医院角色-管理员 HOSPITAL_ROLE_ADMIN
        // 医院角色-导诊员HOSPITAL_ROLE_GUIDE
        // 医院角色-医生 HOSPITAL_ROLE_DOCTOR


        // 诊所角色-超级管理员 CLINIC_ROLE_SUPER_ADMIN
        // 诊所角色-管理员 CLINIC_ROLE_ADMIN
        // 诊所角色-医生 CLINIC_ROLE_DOCTOR

      }else{
        wx.showToast({
          title: res.msg,
          icon:'none'
        })
      }
    })
  },
  // 获取用户手机号 手机号
  getPhoneNumber: function (e, token) {
    var that = this;
    if (e.detail.errMsg == 'getPhoneNumber:ok') {
      var iv = e.detail.iv;
      var encryptedData = e.detail.encryptedData;
      app.agriknow2.usergetPhoneNumber({ phoneStr: encryptedData, userInfoIv: iv }).then(res => {
        wx.setStorageSync('userInfoPho', JSON.stringify(res.data));
        that.getHighestRoleLevelByUserCode();
       
      })
    }
  },




  // 获取用户信息
  getUserInfoInit() {
    console.log('获取用户信息')
    wx.getUserInfo({
      success: res => {
        console.log('============', res)
        // app.globalData.userInfo = res.userInfo

      }
    })
  },

  // 显示加载动画
  showLoading: function (name) {
    wx.showLoading({
      title: name,
      icon: 'loading'
    })
  },

  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({ toastTitle: title, toastInfo: info, toastIsStu: true });
    var time = setInterval(function () {
      that.setData({ toastTitle: title, toastInfo: info, toastIsStu: false });
      clearInterval(time);
    }, 3000);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})