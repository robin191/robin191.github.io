// pages/message_list/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '项目文件', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    oldData: [],
    dateTime: "项目时间",
    editStu: 0,
    projectStatu: 1, // 1 有项目  -1 无项目   -2 项目首页-用户  
    array1: ['全部类别', '图片', '视频/音频', '文件'],
    index1: 0,
    array2: ['全部成员'],
    array2Old: [],
    index2: 0,
    time: '时间',
    // 项目文档列表
    documentList: [
      // { img:'../../images/xiangmu/xinxueguan_lunwen.png', name:'心血管论文'},
      // { img: '../../images/xiangmu/xinxueguan_zhenduanbaogao.png', name: '心血管诊断报告' },
      // { img: '../../images/xiangmu/xinxueguan_bingli.png', name: '心血管病例' },
    ],
    // 项目图片列表
    pictureList: [],
    pictureListOld: [],
    // 项目视频列表
    videoList: [],

    allList: [],


    delFileList: [], // 要删除的文件数组
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    // let dates = new Date();
    // let month = parseInt(dates.getMonth() + 1) + ''
    // let nowDate = dates.getFullYear() + '-' + (month > 9 ? month : ('0' + month)) + '-' + (dates.getDate() > 9 ? dates.getDate() : ('0' + dates.getDate()))
    // this.setData({ dateTime: nowDate });
  },
  // 图片放大
  previewImage122: function(e) {
    console.log(e.currentTarget.dataset.id.path)
    wx.previewImage({
      current: e.currentTarget.dataset.id.path, // 当前显示图片的http链接
      urls: this.data.previewList // 需要预览的图片http链接列表
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {


    this.queryProjectTeams();
    this.queryProjectFiles();

  },
  // 时间选择
  bindDateChange: function(e) {
    this.setData({
      dateTime: e.detail.value
    });
    this.queryProjectFiles();
  },

  // 项目成员
  queryProjectTeams() {
    let that = this;
    let params = {
      "projectCode": app.projectCodeFile, // "YY00010028", // 
    };
    app.agriknow2.queryProjectTeams(params).then(res => {
      if (res.code === 0) {
        let data = res.projectTeamList;
        let arr = [];
        for (var item in data) {
          arr.push(data[item].remarkName || data[item].nickName)
        }
        that.setData({
          array2Old: data,
          array2: that.data.array2.concat(arr)
        });
      }
    })
  },

  // 确定取消方法
  bindcancel(e) {
    this.setData({
      dateTime: '项目时间'
    });
    this.queryProjectFiles();
  },

  // 图片放大
  previewImage1: function(e) {
    wx.previewImage({
      current: e.currentTarget.id, // 当前显示图片的http链接
      urls: this.data.pictureList.path // 需要预览的图片http链接列表
    })
  },

  // 1：图片 //文件类型 1：图片 2：视频/音频 3：文件 非必传
  queryProjectFiles() {
    let that = this;
    that.setData({
      editStu: false
    })
    let createBy = undefined;
    let array2Old = that.data.array2Old;
    if (that.data.index2 !== 0) {
      for (var item in array2Old) {
        if (array2Old[item].remarkName == that.data.array2[that.data.index2] || array2Old[item].nickName == that.data.array2[that.data.index2]) {
          createBy = array2Old[item].doctorCode
        }
      }
    }
    let fileType = undefined;
    if (that.data.index1 != 0) {
      fileType = parseFloat(that.data.index1)
    }
    let dateTime = that.data.dateTime == '项目时间' ? undefined : that.data.dateTime
    let params = {
      "projectCode": app.projectCodeFile, // "YY00010028", // 
      "fileType": fileType,
      "createBy": createBy,
      "createTime": dateTime
    };
    app.agriknow2.queryProjectFiles(params).then(res => {
      let data = res.fileInfoList;
      let document = [];
      let picture = [];
      let pictureListOld = [];
      let video = [];
      let previewList= []
      for (var item in data) {
        
        data[item].stu = 0;
        if (data[item].fileType === 1) {
          previewList.push(data[item].path)
          picture.push(data[item]);
        } else if (data[item].fileType === 2) {
          video.push(data[item])
        } else {
          document.push(data[item])
        }
      }
      that.setData({
        oldData: data,
        allList: data,
        pictureList: picture,
        videoList: video,
        documentList: document,
        previewList: previewList
      });
    })
  },

  // 选中文件
  delFile(e) {
    let info = e.currentTarget.dataset.item;
    let idx = e.currentTarget.dataset.idx;
    let type = e.currentTarget.dataset.type;
    console.log('点击删除-----------', type)
    if (type == 1) {
      let pictureList = this.data.pictureList;
      pictureList[idx].stu = info.stu == 1 ? 0 : 1;
      this.setData({
        pictureList: pictureList
      });
    } else if (type == 2) {
      let videoList = this.data.videoList;
      videoList[idx].stu = info.stu == 1 ? 0 : 1;
      this.setData({
        videoList: videoList
      });
    } else {
      let documentList = this.data.documentList;
      documentList[idx].stu = info.stu == 1 ? 0 : 1;
      this.setData({
        documentList: documentList
      });

      if(!this.data.editStu){
        wx.downloadFile({
          url: info.path,
          success(r) {
            console.log(r)
            let filePath = r.tempFilePath
            wx.openDocument({
              filePath: filePath,
              success(c) {
                console.log(c)
              }
            })
          }
        })
      }
    }
  },

  delWay() {
    let that =this
    wx.showModal({
      title: '提示',
      content: '是否删除选择文件',
      success(res){
        if(res.confirm){
          that.deleteFiles();
        }
      }
    })
    
  },
  // 编辑文件，删除
  deleteFiles() {
    let that = this;
    let pictureList = this.data.pictureList;
    let videoList = this.data.videoList;
    let documentList = this.data.documentList;
    let datas = [];
    let params = {

    };
    for (var item in pictureList) {
      if (pictureList[item].stu === 1) {
        datas.push(pictureList[item].id)
      }
    }
    for (var item in videoList) {
      if (videoList[item].stu === 1) {
        datas.push(videoList[item].id)
      }
    }
    for (var item in documentList) {
      if (documentList[item].stu === 1) {
        datas.push(documentList[item].id)
      }
    }
    if (datas.length <= 0) {
      wx.showToast({
        title: '请选择要删除的文件',
        icon: 'none'
      })
      return;
    }
    app.agriknow2.deleteFiles(datas).then(res => {
      if (res.code === 0) {
        that.queryProjectFiles();
        wx.showToast({
          title: '删除成功！',
          icon: 'none'
        })
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }

    })

  },


  // 查看详情
  checkDetail() {
    wx.navigateTo({
      url: '../project_list_detail/index',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },

  // 添加项目
  addProjectBtn() {
    // wx.navigateBack({
    //   delta: 1
    // })
    if (this.data.editStu == 1) {
      this.setData({
        editStu: 0
      })
    } else {
      this.setData({
        editStu: 1
      })
    }
  },

  bindPickerChange1(e) {
    this.setData({
      index1: e.detail.value
    });
    this.queryProjectFiles();
  },

  bindPickerChange2(e) {
    this.setData({
      index2: e.detail.value
    })
    this.queryProjectFiles();
  },

  bindTimeChange(e) {
    this.setData({
      time: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },



  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})