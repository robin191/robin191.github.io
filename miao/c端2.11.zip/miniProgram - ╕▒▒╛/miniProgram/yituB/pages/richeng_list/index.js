// pages/richeng_list/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '医好康', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log(options)
    let time = options.time
    this.setData({
      time: options.time
    })
    this.queryMySchedules(this.getNowMonth(time.split('-')[0] + '-' + parseInt(time.split('-')[1]) + '-' + 1)); // 获取当月
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  // 根据月，获取事件
  getNowMonth(data) {
    console.log(data)
    var date = new Date(data);
    var year = date.getFullYear() + "";
    var month = (date.getMonth() + 1) + "";
    var begin = year + "-" + (month > 9 ? month : '0' + month) + '-01'
    var lastDateOfCurrentMonth = new Date(year, month, 0);
    var end = year + "-" + (month > 9 ? month : '0' + month) + "-" + lastDateOfCurrentMonth.getDate();
    return begin + "," + end;
  },


  // 获取当月日程
  queryMySchedules(data) {
    let dataArr = data.split(',')
    let that = this;
    let params = {
      "beginTime": dataArr[0] + ' 00:00:00', //开始时间
      "endTime": dataArr[1] + ' 23:59:59' //结束时间
    };
    app.agriknow2.queryMySchedules(params).then(res => {
      if (res.code === 0) {
        for (var i in res.mapList) {
          let week = new Date(res.mapList[i].date).getDay()
          console.log(week)
          switch (week) {
            case 0:
              res.mapList[i].week = '日'
              break;
            case 1:
              res.mapList[i].week = '一'
              break;
            case 2:
              res.mapList[i].week = '二'
              break;
            case 3:
              res.mapList[i].week = '三'
              break;
            case 4:
              res.mapList[i].week = '四'
              break;
            case 5:
              res.mapList[i].week = '五'
              break;
            case 6:
              console.log(123456)
              res.mapList[i].week = '六'
              break;
          }
        }
        console.log(res.mapList)
        // for (var i in res.mapList) {
        //   res.mapList[i].beginTime = res.mapList[i].beginTime.split(' ')[1].split(':')[0] + ':' + res.mapList[i].beginTime.split(' ')[1].split(':')[1]
        //   res.mapList[i].endTime = res.mapList[i].endTime.split(' ')[1].split(':')[0] + ':' + res.mapList[i].endTime.split(' ')[1].split(':')[1]
        // }

        for (var i in res.mapList) {
          for (var j in res.mapList[i].myScheduleEntity) {
            res.mapList[i].myScheduleEntity[j].beginTime = res.mapList[i].myScheduleEntity[j].beginTime.split(' ')[1].split(':')[0] + ':' + res.mapList[i].myScheduleEntity[j].beginTime.split(' ')[1].split(':')[1]
            res.mapList[i].myScheduleEntity[j].endTime = res.mapList[i].myScheduleEntity[j].endTime.split(' ')[1].split(':')[0] + ':' + res.mapList[i].myScheduleEntity[j].endTime.split(' ')[1].split(':')[1]
          }
        }
        that.setData({
          list: res.mapList
        })
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})