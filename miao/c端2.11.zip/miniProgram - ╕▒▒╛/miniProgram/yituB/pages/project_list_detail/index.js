// pages/message_list/index.js
const app = getApp()
var uploadImage = require('../../utils/uploadFile.js');
var util = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '项目详情', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    userInfo: {
      "projectCode": "",
      "patientName": "",
      "sex": 1,
      "idNumber": "",
      "birthday": "",
      "weight": "",
      "isAllergy": 1,
      "allergyDetail": "",
      "disease": "",
      "diseaseDetail": "",
      "versionNo": ""
    },
    sexArr: ['男', '女'],
    sexIdx: 0,
    
    guominArr: ['否', '是'],
    guominIdx: 0,

    userNameStu: true,//昵称
    idNumberStu: true,//身份证
    imgUrl: [],
    videoUrl: [],
    imgUrlGetApi: [], // 从后台获取到地址，保存到数据库
    imgUrlData: [], // 后台获取到的数据




    eventArr: [
      'EVENT_TYPE_PATIENT_INFO',
      'EVENT_TYPE_IMAGE_UPLOAD',
      'EVENT_TYPE_SCHEDULE_TEMPELE',
      'EVENT_TYPE_FILE_UPLOAD',
      'EVENT_TYPE_VIDEO_UOLOAD',
      'EVENT_TYPE_SET_TIME',
    ],
    nowPage: 1,
    hasData: -1, // -1 初始化   1 有数据  0 无数据
    isLoading: -1, // -1 初始化   1 加载    0 隐藏


    nowUserInfoPho:'',
    names:'111111111111111',
    removeProStu:0, // 移交项目长弹框  1 弹  0 隐藏
    nowUserIsAdministrator:-1, // 医生列表显示  1 为项目管理者  0为普通用户
    indexs:0,
    tabList:[
      {name:'事件列表',val:0},
      { name: '团队成员', val: 1 },
      { name: '患者信息', val: 2 },
      { name: '项目信息', val: 3 },
    ], // tab选项
    messageList: [],
    
    // 团队成员列表
    userList:[],
    projectStatu:-2, // 1 有项目  -1 无项目   -2 项目首页-用户  
    array1: ['全部项目', '项目1', '项目3', '项目4'],
    index1: 0,
    array2: ['全部地点', '中国', '巴西', '日本'],
    index2: 0,
    time: '时间',
    lineTypeList: [
      { typeName: '全部项目', idx: '1', typeNo: '1' }, { typeName: '全部地点', idx: '2', typeNo: '2' },
      { typeName: '时间', idx: '3', typeNo: '3' }
    ], // 公交线路类型
    toastTitle: '',
    toastInfo: '',
    toastIsStu: false,

    
    projectInfo:{}, // 项目信息
    projectCode: "YY00010017", // 项目id
    // 项目信息
    
    teamList:[], // 团队列表
    iscreat:'', 
    isadmin:'', //  获取到创建人的 和管理员的 code 进行移除普通成员  

    huanzhe:{}, // 患者信息
    huangzhe1:{name:'哈哈哈哈'},
    
    huanzheImg:[], // 患者图片

    transferTeamsList:[], // 所有移交的对象列表
    transferTeamsIndex:0, // 所选择的移交对象下表
    oldTransferTeamsList: [], // 所有移交的对象列表

    isMeDataIsQut:false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({ projectCode: app.projectCode });
    if (wx.getStorageSync('zhenduan')) {
      wx.removeStorageSync('zhenduan')
    }
    if (wx.getStorageSync('guomin')) {
      wx.removeStorageSync('guomin')
    }
    if (wx.getStorageSync('detail')) {
      wx.removeStorageSync('detail')
    }
   
  },

  /**
     * 生命周期函数--监听页面显示
     */
  onShow: function () {
    this.getProEventOne(); // api - 事件列表
    this.queryProjectInfo();  // api - 项目详情

    this.queryTransferTeams(); // 移交对象
    this.getProTeams(); // api - 团队成员
    this.getProHuanzhe(); // api - 患者信息
   
    this.setData({  projectCode: app.projectCode });
   
    console.log(app.globalData.gomes)
   if(app.globalData.gomes){
     this.setData({
       indexs:3
     })
   }
  },

  // 首页-事件提交-患者信息模板
  uploadImageTemplateWay() {
    var that = this;
    that.setData({
      ['userInfo.sex']: parseInt(that.data.sexIdx) + 1,
      ['userInfo.isAllergy']: parseInt(that.data.guominIdx) + 1
    })


    let fileInfos = [];
    let imgUrlGetApi = that.data.imgUrlGetApi;
    for (var item in imgUrlGetApi) {

      var namearr = imgUrlGetApi[item].split('/');
      var name = namearr[namearr.length - 1];
      let data = {
        "projectCode": that.data.eventCode,
        "fileName": name,
        "path": imgUrlGetApi[item],
        "projectCode": that.data.projectCode,
        "size": 30
      };
      fileInfos.push(data);
    }
    let params = {
      deleteIds:[],
      fileInfos: fileInfos,
      projectPatient: that.data.userInfo
    }
    app.agriknow2.updatePatientInfoWithFilesPro(params, 'noloading').then(res => {
      if (res.code === 0) {
        that.toastSetWay('', '提交成功', true);
        wx.navigateBack({ data:1})
      } else {
        that.toastSetWay('', '提交失败', true)
      }
    })
  },

  // api - 患者信息  that.data.projectCode 'YY0020023'
  getProHuanzhe() {
    let that = this;
    let params = { projectCode: that.data.projectCode };
    app.agriknow2.queryPatientInfoByProject(params).then(res => {
      if (res.code === 0) {
        let data = res.projectPatient
        that.setData({ userInfo: data, sexIdx: data.sex ? parseInt(data.sex) - 1 :0, guominIdx: parseInt(data.isAllergy) })
        if (res.projectPatient.eventCode) {
          that.getProHuanzheImg(data.eventCode); // 患者图片
        }
      }
    })
  },

  // api - 患者信息 图片  that.data.projectCode 'YY0020023'
  getProHuanzheImg(eventCode) {
    let that = this;
    let params = { eventCode: eventCode };
    app.agriknow2.queryFilesByEventCode(params).then(res => {
      if (res.code === 0) {
        let data = res.fileInfoList;
        let arr = [];
        for (var item in data) {
          arr.push(data[item].path);
        }
        that.setData({ imgUrlData: arr });
      }
    })
  },


  // 跳转输入内容
  disease(e) {
    this.setData({ diseaseType: e.currentTarget.dataset.type })
    wx.navigateTo({
      url: '/pages/manage_keshi_disease/index?type=' + e.currentTarget.dataset.type,
    })
  },


  // 身份证
  idNumberBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name !== '' && name.length === 18) {
      that.setData({ idNumberStu: true })
    } else {
      that.setData({ idNumberStu: false })
    }
    that.setData({
      ['userInfo.idNumber']: name,
    })
  },

  // 姓名
  userNameBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name.length > 1) {
      that.setData({ userNameStu: true })
    } else {
      that.setData({ userNameStu: false })
    }
    that.setData({
      ['patientName.userName']: name,
    })
  },

  // 性别选择
  bindSexChange(e) {
    this.setData({
      sexIdx: e.detail.value
    })
  },


  // 过敏史
  bindGuominChange(e) {
    this.setData({
      guominIdx: e.detail.value
    })
  },

  //上传图片 从云服务取到地址
  updloadWay1: function () {
    var nowTime = util.formatTime(new Date());
    let data = this.data.imgUrl;
    let that = this;

    for (var item in data) {
      let typeArr = data[item].split('.');

      let type = typeArr[typeArr.length - 2] + '.' + typeArr[typeArr.length - 1];
      uploadImage(type, data[item], 'img/' + nowTime + '/',
        function (result) {
          that.setData({ imgUrlGetApi: that.data.imgUrlGetApi.concat(result) })
          // that.uploadImageTemplateWay(result); // 保存到数据库
        }, function (result) {
        }
      )
    }
  },

  // 患者 图片选择
  chooseImage: function (e) {
    var that = this;
    if (that.data.imgUrl.length > 9){
      return;
    }
    wx.chooseImage({
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        that.setData({
          imgUrl: that.data.imgUrl.concat(res.tempFilePaths)
        });
      }
    })
  },



  /**
  * 页面相关事件处理函数--监听用户下拉动作
  */
  onPullDownRefresh: function () {
    // 显示顶部刷新图标  
    

    wx.showNavigationBarLoading();
    this.getProEventOne('pull');
    this.queryTransferTeams(); // 移交对象
    this.getProTeams(); // api - 团队成员
    this.getProHuanzhe(); // api - 患者信息
  },

  // 第一次加载
  // api - 事件列表
  getProEventOne(type) {
    this.setData({ nowPage: 1 });
    let that = this;
    let params = {
      "page": that.data.nowPage + '',
      "limit": "10",
       "type": 1,
        projectCode: that.data.projectCode, };
    app.agriknow2.queryEventListOfProject(params).then(res => {
      if (type === 'pull') {
        // 隐藏导航栏加载框  
        wx.hideNavigationBarLoading();
        // 停止下拉动作  
        wx.stopPullDownRefresh();
      }
      if (res.code === 0) {
        let data = res.page.list;
        if (data.length >= 1) {
          that.setData({  projectStatu: 1 });
        } else {
          that.setData({ projectStatu: -1});
        }
        if (data.length >= 10) {
          that.setData({  hasData: 1 });
        } else {
          that.setData({ hasData: -1, nowPage: that.data.nowPage + 1, });
        }

        that.setData({ messageList: data });
      }
    })
  },

  // api - 事件列表
  getProEvent() {
    let that = this;
    let params = {
      "page": that.data.nowPage + '',
      "limit": "10",
       "type": 1, projectCode: that.data.projectCode, };
    app.agriknow2.queryEventListOfProject(params).then(res => {
      if (res.code === 0) {
        let data = res.page.list;
        if (data.length < 10) {
          that.setData({ hasData: 0 });
        } else {
          that.setData({ hasData: 1, nowPage: that.data.nowPage + 1, });
        }
        that.setData({ messageList: that.data.messageList.concat(data)  });
      }
    })
  },


  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.hasData == 1) {
      this.getProEvent(); // 获取信息列表
    }
  },




  // ****************************** 事件 开始 ******************************

  // 进入详情
  toEventDetailBtn(e) {
    let item = e.currentTarget.dataset.item;
    item.eventCode = item.code;
    item.projectCode = item.projectCode;
    // item.isExecutor = 1;
    item.isComplete = item.isComplete;
    
    let url = '../index_message_detail/index?info=' + JSON.stringify(item); // 系统消息 推荐
    if (item.templateCode == this.data.eventArr[0]) { // 患者信息模板 
      url = '../index_message_detail_incident_huanzhe/index?info=' + JSON.stringify(item);
    } else if (item.templateCode == this.data.eventArr[1]) { // 图片上传模板  
      url = '../index_message_detail_incident_img/index?info=' + JSON.stringify(item);
    } else if (item.templateCode == this.data.eventArr[2]) { // 设定日程模板
      url = '../index_message_detail_incident_schedule/index?info=' + JSON.stringify(item);
    } else if (item.templateCode == this.data.eventArr[3]) { // 文件上传模板 
      url = '../index_message_detail_incident_file/index?info=' + JSON.stringify(item);
    } else if (item.templateCode == this.data.eventArr[4]) { // 视频上传模板 
      url = '../index_message_detail_incident_video2/index?info=' + JSON.stringify(item);
    } else if (item.templateCode == this.data.eventArr[5]) { // 设定时间模板 
      url = '../index_message_detail_incident_schedule/index?info=' + JSON.stringify(item);
    }

    wx.navigateTo({
      url: url,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },


  // ****************************** 事件 结束 ******************************










// ****************************** 移交项目 开始 ******************************
  // 移交项目 项目移交对象
  queryTransferTeams() {
    let that = this;
    let params = { projectCode: that.data.projectCode };
    app.agriknow2.queryTransferTeams(params).then(res => {
      if (res.code === 0) {
        let data = res.projectTeamList;
        let arr = [];
        let d = []
        for (var item in data){
          if (data[item].isQuit == 0){ // 去除已移除的人员
            arr.push(data[item].remarkName);
            d.push(data[item])
          }
        }
        that.setData({ transferTeamsList: arr, oldTransferTeamsList: d});
      }
    })
  },

  // 移交项目
  transferAuthority() {
    let that = this;
    let docCode = that.data.oldTransferTeamsList[that.data.transferTeamsIndex].doctorCode;
    let params = { projectCode: that.data.projectCode, doctorCode: docCode };
    app.agriknow2.transferAuthority(params).then(res => {
      if (res.code === 0) {
        wx.showToast({
          title: '移交成功',
        })
        that.getProTeams(); // api - 团队成员
      }else{
        that.toastSetWay('', res.msg,true)
      }
      that.closeYiJiaoBtn();
    })
  },


  // 移除成员
  memberQuit(e) {
    let that = this;
    wx.showModal({
      title: '移除',
      content: '确定要移除此成员吗？',
      success: function (res) {
        if (res.confirm) {
          let dcode = e.currentTarget.dataset.item.doctorCode;
          let params = { projectCode: that.data.projectCode, doctorCode: dcode };
          app.agriknow2.memberQuit(params).then(res => {
            if (res.code === 0) {
              wx.showToast({
                title: '移除成功',
              })
              that.getProTeams(); // api - 团队成员
            }
          })
        } else if (res.cancel) {
          wx.showToast({
            title: '您已取消',
            icon:'none'
          })
        }
      }
    });
   
  },


  // 我要退出
  userRemoveBtn() {
    let that = this;
    wx.showModal({
      title: '提示',
      content: '是否要退出',
      success: function (res) {
        if (res.confirm) {
          let params = { projectCode: that.data.projectCode };
          app.agriknow2.memberQuit1(params).then(res => {
            if (res.code === 0) {
              wx.showToast({
                title: '退出成功',
              })
              that.getProTeams(); // api - 团队成员
            }
          })
        } else if (res.cancel) {
          wx.showToast({
            title: '您已取消',
            icon:'none'
          })
        }
      }
    })

    
  },

  // ****************************** 移交项目 结束 ******************************

  // 标题选择
  selTypeLine(e){
    this.setData({ indexs: e.currentTarget.dataset.idx});
  },

  // 关闭项目
  closeProBtn() {
    let that = this;
    wx.showModal({
      title: '提示',
      content: '是否删除',
      success: function (res) {
        if (res.confirm) {
          let params = { code: that.data.projectCode };
          app.agriknow2.closeProject(params).then(res => {
            if (res.code === 0) {
              wx.showToast({
                title: '关闭成功',
              })
              wx.reLaunch({
                url: '../project_list/index',
              })
            }
          })
        } else if (res.cancel) {
          wx.showToast({
            title: '您已取消',
            icon: 'none'
          })
        }
      }
    });

 
  },





  // api - 项目详情
  queryProjectInfo() {
    let that = this;
    let params = { code: that.data.projectCode };
    app.agriknow2.queryProjectInfo(params).then(res => {
      if (res.code === 0) {
        that.setData({ projectInfo: res.projectInfoVo})
        let userInfo = JSON.parse(wx.getStorageSync('userInfoPho'));
        that.setData({ nowUserInfoPho: userInfo.mobilePhone})
        if (userInfo.mobilePhone === res.projectInfoVo.cuserMobilePhone ){
          that.setData({ nowUserIsAdministrator:1})
        }else{
          that.setData({ nowUserIsAdministrator: 0 })
        }
      }
    })
  },

  
  // api - 团队成员
  getProTeams() {
    let that = this;
    let params = { projectCode: that.data.projectCode };
    app.agriknow2.queryProjectTeams(params).then(res => {
      if (res.code === 0) {
        let isMeData = {};
        let isMeIdx = 0;
        let data = res.projectTeamList;
        
        let arr = []
        for (var item in data){
          if (data[item].projectRole == 1) {
            that.setData({ iscreat: data[item].mobilePhone })
          } else if (data[item].projectRole == 2) {
            that.setData({ isadmin: data[item].mobilePhone })
          }
          if (data[item].isMe == 1){
            isMeData = data[item];
            isMeIdx = item;
          }else{
            arr.push(data[item]);
          }
          // arr.push(data[item]);
        }

        if (that.data.iscreat === that.data.nowUserInfoPho){
          that.setData({ nowUserIsAdministrator:1});
        } else if (that.data.isadmin === that.data.nowUserInfoPho) {
          that.setData({ nowUserIsAdministrator: 1 });
        }else{
          that.setData({ nowUserIsAdministrator: 0 });
        }


        
        arr.unshift(isMeData);

        if (isMeData.isQuit == 1){ // 已退出
          that.setData({ isMeDataIsQut:true})
        }
        
        that.setData({ userList: arr})
      }
    })
  },

 

  // api - 新建事件
  addEvent() {
    let that = this;
    let params = { projectCode: that.data.projectCode };
    app.agriknow2.addEvent(params).then(res => {
      if (res.code === 0) {

      }
    })
  },

  // 添加事件
  addIncidentBtn(){
    app.getProjectInfo.code = this.data.projectCode;
    wx.navigateTo({
      url: '../project_add_incident/index',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  // 添加项目
  addProjectBtn(){
    let url = '../project_add/index';
    if (this.data.indexs === 0){
      app.getProjectInfo.code = this.data.projectCode;
      url = '../project_add_incident/index' 
    } else if (this.data.indexs === 1) { 
      app.createProInfo.selHospitalInfo.hospitalCode = this.data.projectInfo.hospitalCode;
      app.createProInfo.selGuanli = [];

      let userListd = [];
      let d = this.data.userList;
      for (var item in d){
        if (d[item].isQuit == 0){
          userListd.push(d[item])
        }
      }
        app.createProInfo.selDoc = userListd;

      // app.createProInfo.selDoc = this.data.oldTransferTeamsList;
      
      url = '../project_add_doctor_list/index?type=33' 
     
    }else{
      url = '../project_list_detail_useradd/index?projectCode=' + this.data.projectCode
    }
    wx.navigateTo({
      url: url,
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },

 

  transferTeamsChange1(e) {
    this.setData({
      transferTeamsIndex: e.detail.value
    })
  },

  bindPickerChange2(e) {
    this.setData({
      index2: e.detail.value
    })
 },

  bindTimeChange(e) {
    this.setData({
      time: e.detail.value
    })
  },



  


  // // 项目移除
  // clearProBtn() {
  //   this.toastSetWay('', '您已成功移交管理者身份', true);
  // },


  // // 项目退出
  // quitProBtn() {
  //   this.toastSetWay('', '您已成功项目退出项目', true);
  // },


  // 打开移交窗口
  opeanYiJiaoBtn() {
    this.queryTransferTeams();
    this.setData({ removeProStu:1 });
  },

  // 关闭移交窗口
  closeYiJiaoBtn(){
    this.setData({ removeProStu:0});
  },
  

  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({ toastTitle: title, toastInfo: info, toastIsStu: true });
    var time = setInterval(function () {
      that.setData({ toastTitle: title, toastInfo: info, toastIsStu: false });
      clearInterval(time);
    }, 3000);
  },

  // 项目文件
  detailFile(){
    app.projectCodeFile = this.data.projectCode
    wx.navigateTo({
      url: '../project_list_detail_file_list/index',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  
  // 备忘录
  detailMemo(){
    app.projectCodeMemo = this.data.projectCode
    wx.navigateTo({
      url: '../project_list_detail_memo_sel/index',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  // 图片放大
  previewImage: function (e) {
    wx.previewImage({
      current: e.currentTarget.id, // 当前显示图片的http链接
      urls: this.data.imgUrlData // 需要预览的图片http链接列表
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    app.globalData.gomes = !1
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})