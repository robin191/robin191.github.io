// miniprogram/pages/user_1info_hospital/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '医院信息', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    longitude: '120.123218',
    latitude:'30.263964',
    markers: [{
      id: 0,
      iconPath: "../../images/start.png",
      latitude: 23.099994,
      longitude: 113.324520,
      width: 50,
      height: 50
    }],

    tabList: [
      { name: '医院信息', val: 0 },
      { name: '项目清单', val: 1 },
    ], // tab选项
    tabIndex:0,

    proList: [{ name: '项目名称1' }, { name: '项目名称1' }, { name: '项目名称1' }, ],

    isMy:0,
    isReady:0, // 1 为只读  0为修改
    hospitalCode:'YY002',
    hospitalInfo:{}, // 项目详情
    proList:[], // 项目清单

    nameStu:true,
    contactStu: true,
    contactTelStu: true,

    toastTitle: '',
    toastInfo: '',
    toastIsStu: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   

    let isMy = options.isMy;
    this.setData({ isMy: 1, isReady: 0 });
    this.getHospitalDetailApi();
    let hosCode = wx.getStorageSync('hosCode')
    this.setData({ hospitalCode: hosCode })
   
    if (wx.getStorageSync('disease')) {
      wx.removeStorageSync('disease')
    }

  },

  /**
 * 生命周期函数--监听页面显示
 */
  onShow: function () {
    if (wx.getStorageSync('disease')) {
      this.setData({ ['hospitalInfo.hospitalProfile']: wx.getStorageSync('disease')}) 
    }


    
  },

  // 我的-我的医院-医院修改 api
  updateMyHospitalDetail() {
    let that = this;
    if (!that.data.nameStu){
      that.toastSetWay('', '请填写医院名称', true)
      return;
    }
    if (!that.data.contactStu) {
      that.toastSetWay('', '请填写联系人', true)
      return;
    }
    if (!that.data.contactTelStu) {
      that.toastSetWay('', '请填写联系方式', true)
      return;
    }

    if (!that.data.hospitalInfo.address) {
      that.toastSetWay('', '请选择医院地址', true)
      return;
    }


    let params = {
      "name": that.data.hospitalInfo.name,
      "contact": that.data.hospitalInfo.contact,
      "contactTel": that.data.hospitalInfo.contactTel,
      "address": that.data.hospitalInfo.address,
      "lngNum": that.data.hospitalInfo.lngNum,
      "latNum": that.data.hospitalInfo.latNum,
      "hospitalProfile": that.data.hospitalInfo.hospitalProfile
     };
    app.agriknow2.updateMyHospitalDetail(params).then(res => {
      if (res.code === 0) {
        that.toastSetWay('','修改成功',true);
        wx.navigateBack({
          data:1
        })
      }else{
        that.toastSetWay('', res.msg, true)
      }
    })
  },



  // 我的-我的医院-医院信息 api
  getHospitalDetailApi() {
    let that = this;
    let params = { hospitalCode: that.data.hospitalCode};
    app.agriknow2.getMyHospitalDetail(params).then(res => {
      if (res.code === 0) {
        that.setData({ hospitalInfo: res.myHospitalDetail});
        if (!(that.data.hospitalInfo.latNum && that.data.hospitalInfo.lngNum)){
          wx.getLocation({
            type: "wgs84",
            success: function (res) {
              var latitude = res.latitude;
              var longitude = res.longitude;
              that.setData({
                latitude: res.latitude,
                longitude: res.longitude,
                markers: [{
                  latitude: res.latitude,
                  longitude: res.longitude
                }]
              })
            }
          })
        }else{
          that.setData({
            latitude: that.data.hospitalInfo.latNum,
            longitude: that.data.hospitalInfo.lngNum,
            markers: [{
              latitude: that.data.hospitalInfo.latNum,
              longitude: that.data.hospitalInfo.lngNum
            }]
          })
        }
      }
    })
  },


  // 联系人电话
  contactTelBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name !== '' && name.length === 11) {
      that.setData({ contactTelStu: true })
    } else {
      that.setData({ contactTelStu: false })
    }
    that.setData({
      ['hospitalInfo.contactTel']: name,
    })
  },


  // 联系人验证
  contactBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name.length > 1 && name.length <= 10) {
      that.setData({ contactTelStu: true })
    } else {
      that.setData({ contactTelStu: false })
    }
    that.setData({
      ['hospitalInfo.contact']: name,
    })
  },

  /**
       *  医院名称验证
       */
  nameBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name.length > 1 && name.length <= 15) {
      that.setData({ nameStu: true })
    } else {
      that.setData({ nameStu: false })
    }
    that.setData({
      ['hospitalInfo.name']: name,
    })
  },

  sureBtn(){
    if (this.data.isReady == 1){
      this.setData({ isReady: 0})
    }
    
    if (this.data.isReady === 0){
      this.updateMyHospitalDetail();
    }
  },

  // 选择上传站点
  mapAddress() {
    var that = this;
    wx.chooseLocation({
      success: function (res) {
        // success
        that.setData({
          ['hospitalInfo.latNum']: res.latitude,
          ['hospitalInfo.lngNum']: res.longitude,
          ['hospitalInfo.address']: res.address,
        })

        console.log('==', that.data.hospitalInfo.latNum, that.data.hospitalInfo.lngNum)

        that.setData({
          latitude: that.data.hospitalInfo.latNum,
          longitude: that.data.hospitalInfo.lngNum,
          markers: [{
            latitude: that.data.hospitalInfo.latNum,
            longitude: that.data.hospitalInfo.lngNum
          }]
        })
        app.selUserSite = { type: 1, address: res.name, addressCompany: that.data.addressCompany }
      },
      fail: function () {
        // fail
      },
      complete: function () {
        // complete
      }
    })
  },

  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({ toastTitle: title, toastInfo: info, toastIsStu: true });
    var time = setInterval(function () {
      that.setData({ toastTitle: title, toastInfo: info, toastIsStu: false });
      clearInterval(time);
    }, 3000);
  },

  toDisease(){
    wx.navigateTo({
      url: '/pages/manage_keshi_disease/index?type=3&con=' + this.data.hospitalInfo.hospitalProfile,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },



  // 标题选择
  selTypeLine(e) {
    console.log(e.currentTarget.dataset.idx);
    this.setData({ tabIndex: e.currentTarget.dataset.idx });

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})