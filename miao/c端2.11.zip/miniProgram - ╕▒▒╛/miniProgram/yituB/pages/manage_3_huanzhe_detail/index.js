// miniprogram/pages/user_order_list/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '患者信息', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    array1: [
      '患者信息模板', "图片上传模板", "设定日程模板", "文件上传模板", "视频上传模板", "设定时间模板",
      // { 'name':"患者信息模板", val:'1' },
      // { 'name': "图片上传模板", val: '2' },
      // { 'name': "设定日程模板", val: '3' },
      // { 'name': "文件上传模板", val: '4' },
      // { 'name': "视频上传模板", val: '5' },
      // { 'name': "设定时间模板", val: '6' },
    ],
    index1: 0,

    sexArr: ['男', '女'],
    sexIdx: 1,
    array2: [
      '患者信息模板', "图片上传模板", "设定日程模板", "文件上传模板", "视频上传模板", "设定时间模板",
    ],
    index2: 0,

    tuijianPatients: {},

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

    this.setData({
      tuijianPatients: app.managetTuijianPatients.huanzhe,
      sexIdx: app.managetTuijianPatients.huanzhe.sex - 1
    })
    console.log(this.data.tuijianPatients,this.data.sexIdx)
  },


  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.getIntroMes()
  },
  getIntroMes(){
    let that =this
    app.agriknow2.query30DayHospitalRecommend({
      "cuserOpenId": this.data.tuijianPatients.openId,
      "recommendHospitalCode": wx.getStorageSync('hosCode'),
      "recommenderType": 2
    }).then(res=>{
      if(res.code==0){
        console.log(res)
        if (!res.hospitalRecommendReportVo){
          that.setData({
            showIntroMes:!1
          })
        }else{
          that.setData({
            introHos: res.hospitalRecommendReportVo.receiveHospitalName,
            showIntroMes:!0
          })
        }
      }
    })
  },
  // 推荐患者
  addHuanzheBtn() {
    wx.navigateTo({
      url: '/pages/user_3info_huanzhe_tuijian/index?types=2'
    }); // 患者信息
  },

  // 发送消息
  sendInfo() {
    wx.navigateTo({
      url: '../user_2info_Rhuanzhe_send_info/index'
    }); // 发送消息
  },

  userQRTo() {
    wx.navigateTo({
      url: '../user_add_QR/index',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },

  // 性别选择
  bindSexChange(e) {
    this.setData({
      sexIdx: e.detail.value
    })
  },

  // 事件模板选择
  bindPickerChange1(e) {
    this.setData({
      index1: e.detail.value
    })
  },

  // 执行人选择
  bindPickerChange2(e) {
    this.setData({
      index2: e.detail.value
    })
  },

  // 显示加载动画
  showLoading: function() {
    wx.showLoading({
      title: '加载中...',
      icon: 'loading'
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function(ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '浦江行',
      path: 'pages/i_sel_site/index1',
      success: function(res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function(res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  }
})

/**
 * 提示框
 */
function showToastWay(msg) {
  wx.showToast({
    title: msg,
    icon: 'none',
    duration: 1500
  })
}