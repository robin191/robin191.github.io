// miniprogram/pages/user_order_list/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '建立事件', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    toastTitle: '',
    toastInfo: '',
    toastIsStu: false,

    array1: [
      '患者信息模板', "图片上传模板", "设定日程模板", "文件上传模板", "视频上传模板", "设定时间模板", 
      // { 'name':"患者信息模板", val:'1' },
      // { 'name': "图片上传模板", val: '2' },
      // { 'name': "设定日程模板", val: '3' },
      // { 'name': "文件上传模板", val: '4' },
      // { 'name': "视频上传模板", val: '5' },
      // { 'name': "设定时间模板", val: '6' },
      ],
    index1: 0,
    mobelList:[], //
    
    index2: 0,

    proName: '', // 事件名称
    proNameStu: true,

    proName2: '', // 事件说明
    proNameStu2: true,

    executorInfo:[], // 执行人信息
    executorInfoStu:true, // 是否选择执行人

    projectInfo:{}, // 项目信息
    
    mobelVal:'', // 给后台传的模板值

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({ projectInfo: app.getProjectInfo}); // 项目信息
  },


  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({ executorInfo: app.createProIncident.executor});
    this.getModel();
  },
  
  // 根据模板数据 查到对应值 value description
  getModelWay(){
    let array1 = this.data.array1;
    for (var item in array1){
      if (array1[item].description === this.data.mobelList[this.data.index1]){
        this.setData({ mobelVal: array1[item].value});
      }
    }
  },
  // 事件模板选择
  bindPickerChange1(e) {
    this.setData({
      index1: e.detail.value
    });

    if (this.data.mobelList[this.data.index1] === '患者信息模板') {
      app.createProIncident.executor = [];
      this.setData({ executorInfo:[]});
    }
  },

  // 创建事件
  creatEventWay(){
    var that = this;
    that.getModelWay();// 获取模板值
    // enentName 事件名称    projectCode 项目名称  templateCode 模板编码 executorCode 执行人编码  explain 事件说明  departmentCode

    let params = { 
      eventName: that.data.proName, 
      projectCode: that.data.projectInfo.code, 
      templateCode: that.data.mobelVal, 
      executorCode: app.createProIncident.executor[0].doctorCode, 
      description: that.data.proName2, 
      }; 
    app.agriknow2.iaddEvent(params).then(res => {
      if(res.code == 0){
        app.createProIncident = { executor: [] }
        wx.reLaunch({
          url: '../project_list/index',
        })
      }else{
        that.toastSetWay('', res.msg, true);
      }
      // let data = res.page;
      // that.setData({ proList: data.list })
     
    })
  },

  // 添加事件
  addBtn() {
    this.proNameBlur({ detail: { value: this.data.proName } });  // 项目名称 验证
    this.proNameBlur2({ detail: { value: this.data.proName2 } });  // 项目名称 验证
    this.hosptitalBlur();         // 医院名称 验证
    if (!this.isOkAdd1()) return   // 验证都不通过就断
    this.creatEventWay(); // 创建事件

  },


  // 获取模板列表
  getModel() {
    var that = this;
    
    app.agriknow2.querySysDict({ "type": "event_template" }).then(res => {
      if(res.code == 0){
        let data = res.sysDictList;
        let mobelList = [];
        for (var item in data) {
          mobelList.push(data[item].description)
        }
        that.setData({ array1: data })
        that.setData({ mobelList: mobelList})
        that.setData({ mobelVal: that.data.array1[0].value});
      }
    })
  },

  // 选中执行人
  selExecutorBtn(){
    let type = 1;
    if (this.data.mobelList[this.data.index1] === '患者信息模板'){
      type = 2;
    }
    wx.navigateTo({ url: '../project_add_i_executor_list/index?type=' + type }); // 选中执行人
  },

  /**
   *  事件名称 验证
   */
  proNameBlur(e) {
    var that = this;
    let proName = e ? e.detail.value : e;
    if (proName.length > 1 && proName.length <= 30) {
      that.setData({ proNameStu: true })
    } else {
      that.setData({ proNameStu: false })
    }
    that.setData({
      proName: proName,
    })
  },

  /**
   *  事件备注 验证
   */
  proNameBlur2(e) {
    var that = this;
    let proName2 = e ? e.detail.value : e;
    if (proName2.length > 1 ) {
      that.setData({ proNameStu2: true })
    } else {
      that.setData({ proNameStu2: false })
    }
    that.setData({
      proName2: proName2,
    })
  },

  /**
 *  医院名称 验证
 */
  hosptitalBlur() {
    if (this.data.executorInfo.length >= 1 ) {
      this.setData({ executorInfoStu: true })
    } else {
      this.setData({ executorInfoStu: false })
    }
  },

  // 添加事件验证
  isOkAdd1() {
    let blg = true;
    if (!this.data.proNameStu) {
      blg = false;
    } else if (!this.data.executorInfoStu) {
      blg = false;
    }
    return blg;
  },

 






  selTemplate(){
          // '患者信息模板', "图片上传模板", "设定日程模板", "文件上传模板", "视频上传模板", "设定时间模板", 
      // "pages/project_add_i_template_video/index",
      //   "pages/project_add_i_template_file/index",
      //   "pages/project_add_i_template_richeng/index",
      //   "pages/project_add_i_template_tupian/index",
      //   "pages/project_add_i_template_huanzhe/index",
    // "pages/project_add_i_template_time/index",
    let url = '../' + this.data.array1[this.data.index1].label + '/index?type=2';
    console.log('--------------', this.data.array1[this.data.index1].label)
    if (this.data.array1[this.data.index1].label == 'user_2info_RC'){
       url = '../' + this.data.array1[this.data.index1].label + '/index?type=2';
    }
    console.log(url)
    wx.navigateTo({ url: url }); // 
  },


  // 执行人选择
  bindPickerChange2(e) {
    this.setData({
      index2: e.detail.value
    })
  },

  // 显示加载动画
  showLoading: function () {
    wx.showLoading({
      title: '加载中...',
      icon: 'loading'
    })
  },

  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({ toastTitle: title, toastInfo: info, toastIsStu: true });
    var time = setInterval(function () {
      that.setData({ toastTitle: title, toastInfo: info, toastIsStu: false });
      clearInterval(time);
    }, 3000);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '浦江行',
      path: 'pages/i_sel_site/index1',
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  }
})

/**
 * 提示框
 */
function showToastWay(msg) {
  wx.showToast({
    title: msg,
    icon: 'none',
    duration: 1500
  })
}