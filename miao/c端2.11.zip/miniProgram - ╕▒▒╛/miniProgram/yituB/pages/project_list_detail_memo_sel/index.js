// miniprogram/pages/project_list_detail_ memo_add/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '备忘录', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    array1: ["最近一周", "最近一个月", "当天"
      // { 'name':"患者信息模板", val:'1' },
      // { 'name': "图片上传模板", val: '2' },
      // { 'name': "设定日程模板", val: '3' },
      // { 'name': "文件上传模板", val: '4' },
      // { 'name': "视频上传模板", val: '5' },
      // { 'name': "设定时间模板", val: '6' },
    ],
    index1: 0,
    infoList:[], // 备忘录信息列表
    content:'',

    nowPage: 1,
    hasData: -1, // -1 初始化   1 有数据  0 无数据
    isLoading: -1, // -1 初始化   1 加载    0 隐藏
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.queryMemorandumListOne();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    // 显示顶部刷新图标  
    wx.showNavigationBarLoading();
    this.queryMemorandumListOne('pull');
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.hasData == 1) {
      this.queryMemorandumList(); // 获取信息列表
    }
  },

  del(){
    this.setData({ content:''});
  },

  // 备忘录列表查询
  queryMemorandumListOne(type) {
    let that = this;
    this.setData({ nowPage: 1 });
    let params = {
      "page": that.data.nowPage + '',
      "limit": "10",
      "projectCode": app.projectCodeMemo, // 'YY00010028' app.projectCodeMemo,
      "content": that.data.content
    };
    app.agriknow2.queryMemorandumList(params).then(res => {
      if (type === 'pull') {
        // 隐藏导航栏加载框  
        wx.hideNavigationBarLoading();
        // 停止下拉动作  
        wx.stopPullDownRefresh();
      }
      if (res.code === 0) {
        let data = res.page.list;
        if (data.length < 10) {
          that.setData({ hasData: 0 });
        } else {
          that.setData({ hasData: 1, nowPage: that.data.nowPage + 1, });
        }
        for (var item in data) {
          data[item].data1 = data[item].createTime.substring(5, 7)
          data[item].createTime = data[item].createTime.substring(5, 16)
        }
        that.setData({ infoList: data });
      }
    })
  },



  // 备忘录列表查询
  queryMemorandumList() {
    let that = this;
    that.setData({ isLoading: 1 });
    let params = {
      "page": that.data.nowPage + '',
      "limit": "10",
      "projectCode": app.projectCodeMemo, // 'YY00010028' app.projectCodeMemo,
      "content": that.data.content
      };
    app.agriknow2.queryMemorandumList(params).then(res => {
      if (res.code === 0) {
        let data = res.page.list;
        if (data.length < 10) {
          that.setData({ hasData: 0 });
        } else {
          that.setData({ hasData: 1, nowPage: that.data.nowPage + 1, });
        }
        for(var item in data){
          data[item].data1 = data[item].createTime.substring(5,7)
        }
        that.setData({ infoList: that.data.infoListconcat(data)});
        that.setData({ isLoading: 0 });
      }
    })
  },


  // 添加备忘录 
  addMemoBtn(){
    wx.navigateTo({
      url: '../project_list_detail_memo_add/index?type=1',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  // 查看备忘录 
  checkMemoBtn(){
    wx.navigateTo({
      url: '../project_list_detail_memo_list/index',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  // 编辑备忘录 
  updBtn(e) {
    let info = e.currentTarget.dataset.info;
    app.memoInfo = info;
    wx.navigateTo({
      //  + JSON.stringify(info)
      url: '../project_list_detail_memo_add/index?type=2',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  /**
    *  患者名称验证
    */
  patientNameBlur(e) {
    var that = this;
    let content =  e.detail.value;
    // if (proName.length > 3 && proName.length <= 15) {
    //   that.setData({ patientNameStru: true })
    // } else {
    //   that.setData({ patientNameStu: false })
    // }
    that.setData({
      content: content,
    })
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },



  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})