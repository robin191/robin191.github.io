// miniprogram/pages/user_1info_hospital/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '执行人', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    tabList: [
      { name: '团队成员', val: 0 },
      { name: '患者信息', val: 1 },
    ], // tab选项
    tabIndex:0,
    selIndex:0,

    execList:[ ],
    isSelExec: [], // 已选中的执行人  // { stu: 1, title: '张三的4', num: '115345454422' }
    huanzhe: undefined,
    projectCode:'P-001',
    hasC:false, // 是否可选择患者
    isSelHuzhe:0,
    isGet:0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if(options){
      if (options.type == 2) {
        this.setData({ hasC: true })
      }
    }
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({ projectCode: app.projectCode});
    this.getDoc();
    this.getUser();
  },

  selHuzhe(){
    if (this.data.hasC){
      this.setData({ isSelHuzhe: 1 })
    }
    
  },

  // 执行人列表
  getDoc() {
    var that = this;
    app.agriknow2.queryInProjectTeams11({ projectCode: that.data.projectCode }).then(res => {
      if (res.code == 0){
        for (var item in res.projectTeamList){
          res.projectTeamList[item].stu = 0;
        }
        that.setData({ execList: res.projectTeamList, isGet:1 })
        that.getUser()
      }
      
    })
  },

  // 患者列表
  getUser(){
    var that = this;
    app.agriknow2.iqueryPatientByProjectCode({ projectCode: that.data.projectCode }).then(res => {
        let arr = [];
        arr.push(res.projectPatient)
        that.setData({ huanzhe: res.projectPatient})
    })
  },


// 进行选择内容
selBtn(e){
  let idx = e.currentTarget.dataset.idx;
  let execList = this.data.execList;

  for (var item in execList){
    execList[item].stu = 0
  }
  execList[idx].stu = 1; 

  this.setData({ execList: execList });
  let isSelExec = []
  for (var item in execList){
    if (execList[item].stu === 1){
      isSelExec.push(execList[item]);
    }
  }
  this.setData({ isSelExec: isSelExec, isSelHuzhe:0});
},

  //确定返回
  addBtn(){
    console.log('-----------', this.data.isSelHuzhe, this.data.huanzhe)
    let isSelExec = this.data.isSelExec;
    if (this.data.isSelHuzhe == 1){ // 当执行人为患者时， 以医生数据进行返回
      isSelExec = [{ nickName: this.data.huanzhe.patientName, doctorCode: this.data.huanzhe.patientCode}]
    }

    app.createProIncident.executor = isSelExec;
    wx.navigateBack({ delta: 1 });
  },

  // 地区选择
  bindPickerChange1(e) {
    this.setData({
      index1: e.detail.value
    })
  },


  // 标题选择
  selTypeLine(e) {
    console.log(e.currentTarget.dataset.idx);
    this.setData({ tabIndex: e.currentTarget.dataset.idx });

  },

  returnBtn(){
    wx.navigateBack({//返回
      delta: 1
    })
  },

  // 新增患者
  addHuanzheBtn(){
    wx.navigateTo({ url: '../project_add_user_list/index' }); // 患者信息
  },

  // 发送消息
  sendInfo(){
    wx.navigateTo({ url: '../project_add_user_list/index' }); // 患者信息
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})