// miniprogram/pages/project_list_detail_ memo_add/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '确认推荐', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    mobelStu: 0,

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      tel: options.tel
    })
    console.log(JSON.parse(options.info))
    if (JSON.parse(options.info)) {
      console.log(1233)
      this.setData({
        confirmRecommend: JSON.parse(options.info)
      });
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.gethuanzhemes()
  },
  gethuanzhemes() {
    let that = this
    app.agriknow2.queryConfirmRecommendPage({
      "mobilePhone": this.data.tel,
      openId: app.globalData.hexiaoCode
    }).then(function(res) {
      if (res.code == 0) {
        that.setData({
          confirmRecommend: res.confirmRecommend
        })
        console.log(that.data.confirmRecommend)
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }

    })

  },
  // 打开移交窗口
  opeanMobelBtn(e) {
    this.setData({
      mobelStu: 1,
      ids: e.currentTarget.dataset.id
    });
  },

  // 关闭移交窗口
  closeMobelBtn() {
    this.setData({
      mobelStu: 0
    });
  },

  sureBtn() {
    // this.setData({ mobelStu: 0 });
    let that = this
    app.agriknow2.confirmRecommend(this.data.ids).then(res => {
      console.log(res)
      that.setData({
        mobelStu: 0
      });
      that.onShow()
    })
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})