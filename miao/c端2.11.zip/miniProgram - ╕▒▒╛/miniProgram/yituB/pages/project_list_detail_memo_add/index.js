// miniprogram/pages/project_list_detail_ memo_add/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '备忘录', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    content:'',
    patientNameStu: true, // 备忘录名称 
    "patientName": "",//备忘录
    id:"",
    time1:'',
    time2:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('=========',options);
    // let blg = false
    // for (let i in options) {
    //   blg = true;
    // }

    // if (blg){
    //   console.log('========', JSON.parse(options.info));
    //   let info = JSON.parse(options.info);
    //   if (info) {
    //     console.log('info.content==', info.content)
    //     this.setData({ content: info.content, id: info.id })
    //     console.log('+++++++++',this.data.content, this.data.id,)
    //   }
    // }
    if(options.type == 1){
      app.memoInfo = {};
    }else{
      let info = app.memoInfo;
      let time = info.lastUpdateTime !== null ? info.lastUpdateTime : info.createTime;
      console.log('====',time);
      let data1 = time.substring(5,7);
      this.setData({ id: info.id, patientName: info.content, data1: data1, time: time, })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  // 备忘录新增
  addMemorandum() {
    let that = this;
    if (that.data.patientName.length <= 2){
      wx.showToast({
        image: '../../images/fail2.png',
        title: '请输入信息',
      })
      return;
    }
    if(that.data.id){
      that.updWay(); // 修改备忘录
    }else{
      that.addWay();
    }
  },

  //添加备忘录 
  addWay(){
    let that = this;
    let params = {
      "doctorCode": wx.getStorageSync('docCode'),
      "projectCode": app.projectCodeMemo, // 'YY00010028' app.projectCodeMemo,
      "content": that.data.patientName
    };
    app.agriknow2.addMemorandum(params).then(res => {
      if (res.code === 0) {
        wx.navigateBack({
          delta: 1
        })
      }
    })
  },

  //修改备忘录 
  updWay() {
    let that = this;
    let params = {
      id: that.data.id,
      "content": that.data.patientName
    };
    app.agriknow2.updateMemorandum(params).then(res => {
      if (res.code === 0) {
        wx.navigateBack({
          delta: 1
        })
      }
    })
  },


  // 保存备忘录
  addBtn(){
    wx.navigateBack({
      delta: 1
    })
  },

  /**
       *  备忘录验证
       */
  patientNameBlur(e) {
    var that = this;
   
    let proName = e ? e.detail.value : e;
    console.log('========', proName)
    if (proName.length > 3 && proName.length <= 15) {
      that.setData({ patientNameStru: true })
    } else {
      that.setData({ patientNameStu: false })
    }
    that.setData({
      patientName: proName,
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})