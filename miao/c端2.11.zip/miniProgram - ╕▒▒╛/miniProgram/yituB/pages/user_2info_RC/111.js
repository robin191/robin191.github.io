const app = getApp()
var Moment = require("../../utils/moment.js");
var DATE_YEAR = new Date().getFullYear();
var DATE_MONTH = new Date().getMonth() + 1;
var DATE_DAY = new Date().getDate();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    riliStu: 0,
    year: '',
    month: '',
    day: '',
    days: {},
    daysLength: 0,
    systemInfo: {},
    weekStr: ['一', '二', '三', '四', '五', '六', '日',],
    checkDate: [], // 选中的日期
    sumMoney: -2, // 总票价
    priceCount: -1, // 票总数量
    // 余票
    faresNum: [
      { year: '2020', 'month': '01', 'date': '05', amount: '2', has: '' },
      { year: '2019', 'month': '01', 'date': '01', amount: '2', surplusTicket: '23', price: '1' },
    ], //{ month: '7', 'date': '29', 'num': '20' }
    ticketsDate: '', // 可购买的票日期   开始日期--结束日期

    scheduleList: [
      {
        time1: '10月30日', time2: '周六', dataList: [
          { name: '上午 09：00-12：00', info: '交罚款了附近撒点看法就是打开了分开了' },
          { name: '全天', info: '交罚款了附近撒点看法就是打开了分开了' },
        ],
      },
      {
        time1: '10月30日', time2: '周六', dataList: [
          { name: '上午 09：00-12：00', info: '交罚款了附近撒点看法就是打开了分开了' },
          { name: '全天', info: '交罚款了附近撒点看法就是打开了分开了' },
        ],
      }

    ],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this = this;
    let now = new Date();
    let year = now.getFullYear();
    let month = now.getMonth() + 1;
    this.setData({
      year: year,
      month: month
    })
    wx.getSystemInfo({
      success: function (res) {
        _this.setData({
          systemInfo: res,
        });
      }
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.createDateListData(); // 重新生成购票日期
  },

  // 添加日程
  addrichengBtn() {
    wx.navigateTo({ url: '../user_2info_RC_add/index' }); // 添加日程
  },
  // 是否显示 日历
  btnShowHeight() {
    if (this.data.riliStu === 1) {
      this.setData({ riliStu: 0 })
    } else {
      this.setData({ riliStu: 1 })
    }
  },



  /**创建日历数据  每次创建时都进行 清空 所选择的日期余票与总票价*/
  createDateListData: function (setYear, setMonth) {
    this.setData({ checkDate: [] }); // 日历创建完成之后，将之前默认选中的日期余票进行清除
    this.setData({ sumMoney: 0 }); // 总价清空
    //全部时间的月份都是按0~11基准，显示月份才+1
    let dateArr = []; //需要遍历的日历数组数据
    let arrLen = 0; //dateArr的数组长度
    let now = setYear ? new Date(setYear, setMonth) : new Date();
    let year = setYear || now.getFullYear();
    let nextYear = 0;
    let month = setMonth || now.getMonth();
    //没有+1方便后面计算当月总天数
    let nextMonth = (month + 1) > 11 ? 12 : (month + 1); // (month + 1) > 11 ? 1 : (month + 1)
    //目标月1号对应的星期
    let startWeek = this.getWeek(year, nextMonth, 0); //new Date(year + ',' + (month + 1) + ',' + 1).getDay(); 
    //获取目标月有多少天
    let dayNums = this.getTotalDayByMonth(year, nextMonth); //new Date(year, nextMonth, 0).getDate();   
    let obj = {};
    let num = 0;
    if (month + 1 > 11) {
      nextYear = year + 1;
      dayNums = new Date(nextYear, nextMonth, 0).getDate();
    }
    for (var j = -startWeek + 1; j <= dayNums; j++) {
      var tempWeek = -1;
      if (j > 0) {
        tempWeek = this.getWeek(year, nextMonth, j);
      }
      var clazz = '';
      if (tempWeek == 0 || tempWeek == 6)
        clazz = 'week'
      if (j < DATE_DAY && year == DATE_YEAR && nextMonth == DATE_MONTH)
        //当天之前的日期不可用
        clazz = 'unavailable ' + clazz;
      else
        clazz = '' + clazz
      /**如果当前日期已经选中，则变色 */
      var date = year + "-" + nextMonth + "-" + j;
      var index = this.checkItemExist(this.data.checkDate, date);
      if (index != -1) {
        clazz = clazz + ' active';
      }

      // 节假日绑定
      var sFtv = app.sFtv;
      var daytext = '';
      for (let k = 0; k < sFtv.length; k++) {
        if (month + 1 == sFtv[k].month && j == sFtv[k].day) {
          daytext = sFtv[k].name;
        }
      }

      // 余票amount/票价price 绑定
      var amount = '-';
      var price = -1;

      for (var item in this.data.faresNum) {

        // 年 月 日  相同  才进行赋值
        if (this.data.faresNum[item].year === year && this.data.faresNum[item].month == month + 1 && this.data.faresNum[item].date == j) {
          amount = this.data.faresNum[item].surplusTicket;
          price = parseInt(this.data.faresNum[item].price) || -2; //  票价
        }
      }
      dateArr.push({
        daytext: daytext,
        day: j,
        class: clazz,
        amount: amount,
        price: price,
      })

    }

    this.setData({ days: dateArr }); // 生成日历

    if (this.data.isOperation.type4 === 1) {
      // 当天选中
      if (this.data.isOperation.type5[1] === 1) {
        this.selTicketsWayS(); // 日期选中
      }
      // 当月选中
      if (this.data.isOperation.type5[0] === 1) {
        if (this.data.isSelNowMonth) { // 普通线路时 当月选中
          var nowDate = new Date();
          this.setData({ checkDate: [], sumMoney: -1 });
          var blg = false;
          var nums = 0;
          for (var item in this.data.faresNum) {
            if (this.data.faresNum[item].surplusTicket > 0 && this.data.faresNum[item].month == (nowDate.getMonth() + 1)) {
              nums += 1;
              this.selTicketsWay(this.data.faresNum[item].year, this.data.faresNum[item].month, this.data.faresNum[item].date, this.data.faresNum[item].surplusTicket, this.data.faresNum[item].price);
            }
          }
          this.setData({ nowMonthTicketsNum: nums })
        }
      }
    }

  },


  /**
  * 上个月
  */
  lastMonthEvent: function () {
    //全部时间的月份都是按0~11基准，显示月份才+1
    // 当月全选情况
    if (this.data.isSelNowMonth) {
      this.setData({
        days: {},
        daysLength: 0,
        isSelNowMonth: false
      })
      // this.initWays(); // 数据初始化
    }
    let year = this.data.month - 2 < 0 ? this.data.year - 1 : this.data.year;
    let month = this.data.month - 2 < 0 ? 11 : this.data.month - 2;
    this.setData({
      year: year,
      month: (month + 1)
    })
    this.createDateListData(year, month);


  },
  /**
  * 下个月
  */
  nextMonthEvent: function () {
    // 当月全选情况
    if (this.data.isSelNowMonth) {
      this.setData({
        days: {},
        daysLength: 0,
        isSelNowMonth: false
      })
      // this.initWays(); // 数据初始化
    }
    //全部时间的月份都是按0~11基准，显示月份才+1
    let year = this.data.month > 11 ? this.data.year + 1 : this.data.year;
    let month = this.data.month > 11 ? 0 : this.data.month;
    this.setData({
      year: year,
      month: (month + 1)
    })
    this.createDateListData(year, month);


  },
  /*
  * 获取月的总天数
  */
  getTotalDayByMonth: function (year, month) {
    month = parseInt(month, 10);
    var d = new Date(year, month, 0);
    return d.getDate();
  },

  /*
  * 获取月的第一天是星期几
  */
  getWeek: function (year, month, day) {
    var d = new Date(year, month - 1, day);
    return d.getDay();
  },



  // 进行选票
  renderPressStyle: function (year, month, day, amount, price) {
    var days = this.data.days;
    var sumPrice = 0; // 单人总票价
    var sumMone = 0; // 总价

    //渲染点击样式
    for (var j = 0; j < days.length; j++) {
      var tempDay = days[j].day;
      days[j].price = days[j].price;
      console.log(days[j].price)
      if (tempDay == day) {
        var date = year + "-" + month + "-" + day;
        var obj = {
          day: date,
          amount: amount,
          price: price
        };
        var checkDateJson = this.data.checkDate;
        var index = this.checkItemExist(checkDateJson, date);
        if (index == -1 && days[j].amount > 0) {
          checkDateJson.push(obj);
          days[j].class = days[j].class + ' active';
          if (this.data.isOperation.type4 === 0) {
            this.setData({ sumMoney: this.data.sumMoney + price }); // 总价赋值
          }

        } else {
          checkDateJson.splice(index, 1);
          var arrs = days[j].class.split(' ');
          var newArrs = [];
          for (var item in arrs) {
            newArrs.push(arrs[item] == 'active' ? '' : arrs[item])
          }
          days[j].class = newArrs + '';
          if (this.data.isOperation.type4 === 0) {
            this.setData({ sumMoney: this.data.sumMoney - price }); // 总价赋值
          }
        }

        this.setData({
          checkDate: checkDateJson,
        })
        break;
      }
    }

    // 普通线路总价计算  只适用于当月
    if (this.data.isOperation.type4 === 1 && this.data.isOperation.type5[0] === 1) {
      sumPrice = 0;
      for (var item in checkDateJson) {
        sumPrice = sumPrice + parseInt(checkDateJson[item].price);
      }
      this.setData({ sumMoney: sumPrice }); // 总价赋值
    }


    this.setData({
      days: days, daysLength: checkDateJson ? checkDateJson.length : 0
    });

  },

  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({ toastTitle: title, toastInfo: info, toastIsStu: true });
    var time = setInterval(function () {
      that.setData({ toastTitle: title, toastInfo: info, toastIsStu: false });
      clearInterval(time);
    }, 3000);
  },
  /**检查数组中是否存在该元素 */
  checkItemExist: function (arr, value) {

    for (var i = 0; i < arr.length; i++) {
      if (value === arr[i].day) {
        return i;
      }
    }
    return -1;
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})