const app = getApp()
var Moment = require("../../utils/moment.js");
var DATE_YEAR = new Date().getFullYear();
var DATE_MONTH = new Date().getMonth() + 1;
var DATE_DAY = new Date().getDate();
var CalendarData = new Array(100);
var madd = new Array(12);
var tgString = "甲乙丙丁戊己庚辛壬癸";
var dzString = "子丑寅卯辰巳午未申酉戌亥";
var numString = "一二三四五六七八九十";
var monString = "正二三四五六七八九十冬腊";
var weekString = "日一二三四五六";
var sx = "鼠牛虎兔龙蛇马羊猴鸡狗猪";
var cYear, cMonth, cDay, TheDate;
CalendarData = new Array(0xA4B, 0x5164B, 0x6A5, 0x6D4, 0x415B5, 0x2B6, 0x957, 0x2092F, 0x497, 0x60C96, 0xD4A, 0xEA5, 0x50DA9, 0x5AD, 0x2B6, 0x3126E, 0x92E, 0x7192D, 0xC95, 0xD4A, 0x61B4A, 0xB55, 0x56A, 0x4155B, 0x25D, 0x92D, 0x2192B, 0xA95, 0x71695, 0x6CA, 0xB55, 0x50AB5, 0x4DA, 0xA5B, 0x30A57, 0x52B, 0x8152A, 0xE95, 0x6AA, 0x615AA, 0xAB5, 0x4B6, 0x414AE, 0xA57, 0x526, 0x31D26, 0xD95, 0x70B55, 0x56A, 0x96D, 0x5095D, 0x4AD, 0xA4D, 0x41A4D, 0xD25, 0x81AA5, 0xB54, 0xB6A, 0x612DA, 0x95B, 0x49B, 0x41497, 0xA4B, 0xA164B, 0x6A5, 0x6D4, 0x615B4, 0xAB6, 0x957, 0x5092F, 0x497, 0x64B, 0x30D4A, 0xEA5, 0x80D65, 0x5AC, 0xAB6, 0x5126D, 0x92E, 0xC96, 0x41A95, 0xD4A, 0xDA5, 0x20B55, 0x56A, 0x7155B, 0x25D, 0x92D, 0x5192B, 0xA95, 0xB4A, 0x416AA, 0xAD5, 0x90AB5, 0x4BA, 0xA5B, 0x60A57, 0x52B, 0xA93, 0x40E95);
madd[0] = 0;
madd[1] = 31;
madd[2] = 59;
madd[3] = 90;
madd[4] = 120;
madd[5] = 151;
madd[6] = 181;
madd[7] = 212;
madd[8] = 243;
madd[9] = 273;
madd[10] = 304;
madd[11] = 334;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '医好康', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    riliStu: 1,
    year: '',
    month: '',
    day: '',
    days: {},
    daysLength: 0,
    systemInfo: {},
    weekStr: ['一', '二', '三', '四', '五', '六', '日', ],
    checkDate: [], // 选中的日期
    sumMoney: -2, // 总票价
    priceCount: -1, // 票总数量
    // 余票
    faresNum: [{
        year: '2020',
        'month': '1',
        'date': '5',
        amount: '2',
        has: '11'
      },
      {
        year: '2020',
        'month': '1',
        'date': '1',
        amount: '2',
        has: '11'
      },
      {
        year: '2020',
        'month': '01',
        'date': '20',
        amount: '2',
        has: '11'
      },
      {
        year: '2020',
        'month': '01',
        'date': '21',
        amount: '2',
        has: '11'
      },
    ], //{ month: '7', 'date': '29', 'num': '20' }
    ticketsDate: '', // 可购买的票日期   开始日期--结束日期

    scheduleList: [{
        time1: '10月30日',
        time2: '周六',
        dataList: [{
            name: '上午 09：00-12：00',
            info: '交罚款了附近撒点看法就是打开了分开了'
          },
          {
            name: '全天',
            info: '交罚款了附近撒点看法就是打开了分开了'
          },
        ],
      },
      {
        time1: '10月30日',
        time2: '周六',
        dataList: [{
            name: '上午 09：00-12：00',
            info: '交罚款了附近撒点看法就是打开了分开了'
          },
          {
            name: '全天',
            info: '交罚款了附近撒点看法就是打开了分开了'
          },
        ],
      }
    ],


  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var _this = this;
    let now = new Date();
    let year = now.getFullYear();
    let month = now.getMonth() + 1;
    this.setData({
      year: year,
      month: month
    })
    wx.getSystemInfo({
      success: function(res) {
        _this.setData({
          systemInfo: res,
        });
      }
    })
  },

  tolist() {
    console.log(this.data.year, this.data.month)
    let time = this.data.year + '-' + this.data.month
    wx.navigateTo({
      url: '/pages/richeng_list/index?time=' + time,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

    let date = new Date();
    this.getday(date)
    this.queryMySchedules(this.getNowMonth(date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate())); // 获取当月

    // this.queryMyScheduleByDate()
    let year = new Date().getFullYear()
    let month = new Date().getMonth() + 1
    let days = new Date().getDate()
    console.log(year + '-' + month + '-' + days)
    this.queryMyScheduleByDate(year + '-' + month + '-' + days)
    this.setData({
      choosedDate: year + '-' + month + '-' + days
    })
  },

  // 根据月，获取事件
  getNowMonth(data) {
    console.log(data)
    var date = new Date(data);
    var year = date.getFullYear() + "";
    var month = (date.getMonth() + 1) + "";
    var begin = year + "-" + (month > 9 ? month : '0' + month) + '-01'
    var lastDateOfCurrentMonth = new Date(year, month, 0);
    var end = year + "-" + (month > 9 ? month : '0' + month) + "-" + lastDateOfCurrentMonth.getDate();
    return begin + "," + end;
  },

  // 获取当月日程
  queryMySchedules(data) {
    console.log(data)
    let dataArr = data.split(',')
    let that = this;
    let params = {
      "beginTime": dataArr[0] + ' 00:00:00', //开始时间
      "endTime": dataArr[1] + ' 23:59:59' //结束时间
    };
    app.agriknow2.queryMySchedules(params).then(res => {
      if (res.code === 0) {
        console.log(res)
        let arr = [];
        for (let i in res.mapList) {
          arr.push({
            year: res.mapList[i].date.split('-')[0],
            month: res.mapList[i].date.split('-')[1],
            'date': res.mapList[i].date.split('-')[2],
            amount: '2',
            has: '11'
          })
        }
        that.setData({
          faresNum: arr
        })
        // that.createDateListData(); // 重新生成购票日期
        that.createDateListData(dataArr[0].split('-')[0], parseInt(dataArr[0].split('-')[1]) - 1)
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },


  // 添加日程
  addrichengBtn() {
    wx.navigateTo({
      url: '../user_2info_RC_add/index'
    }); // 添加日程
  },


  // 日历点击
  onPressDateEvent(e) {
    let date = e.currentTarget.dataset.year + '-' + e.currentTarget.dataset.month + '-' + e.currentTarget.dataset.day
    this.queryMyScheduleByDate(date)
    this.setData({
      choosedDate: date
    })
    this.getday(date)
  },
  getday(e) {
    console.log(new Date(e).getDay())
    let d = new Date(e).getDay(),
      chinese = ''
    switch (d) {
      case 0:
        chinese = '日'
        break;
      case 1:
        chinese = '一'
        break;
      case 2:
        chinese = '二'
        break;
      case 3:
        chinese = '三'
        break;
      case 4:
        chinese = '四'
        break;
      case 5:
        chinese = '五'
        break;
      case 6:
        chinese = '六'
        break;
    }

    this.setData({
      weekday: chinese
    })
  },

  // 根据具体日期查询
  queryMyScheduleByDate(date) {
    let that = this;
    let params = {
      params: date
    };
    app.agriknow2.queryMyScheduleByDate(params).then(res => {
      if (res.code === 0) {
        for (var i in res.mySchedule) {
          res.mySchedule[i].beginTime = res.mySchedule[i].beginTime.split(' ')[1].split(':')[0] + ':' + res.mySchedule[i].beginTime.split(' ')[1].split(':')[1]
          res.mySchedule[i].endTime = res.mySchedule[i].endTime.split(' ')[1].split(':')[0] + ':' + res.mySchedule[i].endTime.split(' ')[1].split(':')[1]
        }
        console.log(res.mySchedule)
        that.setData({
          scheduleList: res.mySchedule
        })
      }
    })
  },



  // 是否显示 日历
  btnShowHeight() {
    if (this.data.riliStu === 1) {
      this.setData({
        riliStu: 0
      })
    } else {
      this.setData({
        riliStu: 1
      })
    }
  },



  /**创建日历数据  每次创建时都进行 清空 所选择的日期余票与总票价*/
  createDateListData: function(setYear, setMonth) {
    console.log('创建日历方法==============', setYear, setMonth)
    console.log(j, year, month + 1)
    this.setData({
      checkDate: []
    }); // 日历创建完成之后，将之前默认选中的日期余票进行清除

    //全部时间的月份都是按0~11基准，显示月份才+1
    let dateArr = []; //需要遍历的日历数组数据
    let arrLen = 0; //dateArr的数组长度
    let now = setYear ? new Date(setYear, setMonth) : new Date();
    let year = setYear || now.getFullYear();
    let nextYear = 0;
    let month = setMonth || now.getMonth();
    //没有+1方便后面计算当月总天数
    let nextMonth = (month + 1) > 11 ? 12 : (month + 1); // (month + 1) > 11 ? 1 : (month + 1)
    //目标月1号对应的星期
    let startWeek = this.getWeek(year, nextMonth, 0); //new Date(year + ',' + (month + 1) + ',' + 1).getDay(); 
    //获取目标月有多少天
    let dayNums = this.getTotalDayByMonth(year, nextMonth); //new Date(year, nextMonth, 0).getDate();   
    let obj = {};
    let num = 0;
    if (month + 1 > 11) {
      nextYear = year + 1;
      dayNums = new Date(nextYear, nextMonth, 0).getDate();
    }
    for (var j = -startWeek + 1; j <= dayNums; j++) {
      var tempWeek = -1;
      if (j > 0) {
        tempWeek = this.getWeek(year, nextMonth, j);
      }
      var clazz = '';
      if (tempWeek == 0 || tempWeek == 6)
        clazz = 'week'
      if (j < DATE_DAY && year == DATE_YEAR && nextMonth == DATE_MONTH)
        //当天之前的日期不可用
        clazz = 'unavailable ' + clazz;
      else
        clazz = '' + clazz
      /**如果当前日期已经选中，则变色 */
      var date = year + "-" + nextMonth + "-" + j;
      var index = this.checkItemExist(this.data.checkDate, date);
      if (index != -1) {
        clazz = clazz + ' active';
      }

      // 余票amount/票价price 绑定
      var amount = '-';
      var price = -1;
      for (var item in this.data.faresNum) {
        // 年 月 日  相同  才进行赋值
        if (this.data.faresNum[item].year == year && this.data.faresNum[item].month == month + 1 && this.data.faresNum[item].date == j) {
          amount = '';
          price = ''; //  票价
        }
      }

      let isNow = 0;
      let nows = new Date();

      if (nows.getDate() == j && nows.getFullYear() == year && (nows.getMonth() + 1) == (month + 1)) {
        isNow = 1;
      }

      let isSel = 0;


      let nong = this.GetLunarDay(year, month + 1, j); // 农历数据
      dateArr.push({
        daytext: j,
        day: j,
        class: clazz,
        amount: amount,
        nong: nong,
        isNow: isNow,
        isSel: isSel
      })

    }
    console.log(dateArr)
    this.setData({
      days: dateArr
    }); // 生成日历
  },


  /**
   * 上个月
   */
  lastMonthEvent: function() {
    //全部时间的月份都是按0~11基准，显示月份才+1
    // 当月全选情况
    if (this.data.isSelNowMonth) {
      this.setData({
        days: {},
        daysLength: 0,
        isSelNowMonth: false
      })
      // this.initWays(); // 数据初始化
    }
    let year = this.data.month - 2 < 0 ? this.data.year - 1 : this.data.year;
    let month = this.data.month - 2 < 0 ? 11 : this.data.month - 2;
    this.setData({
      year: year,
      month: (month + 1)
    })
    // this.createDateListData(year, month);
    this.queryMySchedules(this.getNowMonth(year + '-' + (month + 1) + '-' + 1)); // 获取当月

  },
  /**
   * 下个月
   */
  nextMonthEvent: function() {
    // 当月全选情况
    if (this.data.isSelNowMonth) {
      this.setData({
        days: {},
        daysLength: 0,
        isSelNowMonth: false
      })
      // this.initWays(); // 数据初始化
    }
    //全部时间的月份都是按0~11基准，显示月份才+1
    let year = this.data.month > 11 ? this.data.year + 1 : this.data.year;
    let month = this.data.month > 11 ? 0 : this.data.month;
    this.setData({
      year: year,
      month: (month + 1)
    })
    // this.createDateListData(year, month);

    this.queryMySchedules(this.getNowMonth(year + '-' + (month + 1) + '-' + 1)); // 获取当月

  },
  /*
   * 获取月的总天数
   */
  getTotalDayByMonth: function(year, month) {
    month = parseInt(month, 10);
    var d = new Date(year, month, 0);
    return d.getDate();
  },

  /*
   * 获取月的第一天是星期几
   */
  getWeek: function(year, month, day) {
    var d = new Date(year, month - 1, day);
    return d.getDay();
  },



  // 进行选票
  renderPressStyle: function(year, month, day, amount, price) {
    var days = this.data.days;
    var sumPrice = 0; // 单人总票价
    var sumMone = 0; // 总价

    //渲染点击样式
    for (var j = 0; j < days.length; j++) {
      var tempDay = days[j].day;
      days[j].price = days[j].price;
      console.log(days[j].price)
      if (tempDay == day) {
        var date = year + "-" + month + "-" + day;
        var obj = {
          day: date,
          amount: amount,
          price: price
        };
        var checkDateJson = this.data.checkDate;
        var index = this.checkItemExist(checkDateJson, date);
        if (index == -1 && days[j].amount > 0) {
          checkDateJson.push(obj);
          days[j].class = days[j].class + ' active';
          if (this.data.isOperation.type4 === 0) {
            this.setData({
              sumMoney: this.data.sumMoney + price
            }); // 总价赋值
          }

        } else {
          checkDateJson.splice(index, 1);
          var arrs = days[j].class.split(' ');
          var newArrs = [];
          for (var item in arrs) {
            newArrs.push(arrs[item] == 'active' ? '' : arrs[item])
          }
          days[j].class = newArrs + '';
          if (this.data.isOperation.type4 === 0) {
            this.setData({
              sumMoney: this.data.sumMoney - price
            }); // 总价赋值
          }
        }

        this.setData({
          checkDate: checkDateJson,
        })
        break;
      }
    }

    // 普通线路总价计算  只适用于当月
    if (this.data.isOperation.type4 === 1 && this.data.isOperation.type5[0] === 1) {
      sumPrice = 0;
      for (var item in checkDateJson) {
        sumPrice = sumPrice + parseInt(checkDateJson[item].price);
      }
      this.setData({
        sumMoney: sumPrice
      }); // 总价赋值
    }


    this.setData({
      days: days,
      daysLength: checkDateJson ? checkDateJson.length : 0
    });

  },

  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({
      toastTitle: title,
      toastInfo: info,
      toastIsStu: true
    });
    var time = setInterval(function() {
      that.setData({
        toastTitle: title,
        toastInfo: info,
        toastIsStu: false
      });
      clearInterval(time);
    }, 3000);
  },
  /**检查数组中是否存在该元素 */
  checkItemExist: function(arr, value) {

    for (var i = 0; i < arr.length; i++) {
      if (value === arr[i].day) {
        return i;
      }
    }
    return -1;
  },






















  /*获取当前农历日期*/
  showCal() {
    var D = new Date();
    var yy = D.getFullYear();
    var mm = D.getMonth() + 1;
    var dd = D.getDate();
    var ww = D.getDay();
    var ss = parseInt(D.getTime() / 1000);
    if (yy < 100) yy = "19" + yy;
    return GetLunarDay(yy, mm, dd);
  },

  //定义全局变量 


  GetBit(m, n) {
    return (m >> n) & 1;
  },

  //农历转换 
  e2c() {
    TheDate = (arguments.length != 3) ? new Date() : new Date(arguments[0], arguments[1], arguments[2]);
    var total, m, n, k;
    var isEnd = false;
    var tmp = TheDate.getYear();
    if (tmp < 1900) {
      tmp += 1900;
    }
    total = (tmp - 1921) * 365 + Math.floor((tmp - 1921) / 4) + madd[TheDate.getMonth()] + TheDate.getDate() - 38;

    if (TheDate.getYear() % 4 == 0 && TheDate.getMonth() > 1) {
      total++;
    }
    for (m = 0;; m++) {
      k = (CalendarData[m] < 0xfff) ? 11 : 12;
      for (n = k; n >= 0; n--) {
        if (total <= 29 + this.GetBit(CalendarData[m], n)) {
          isEnd = true;
          break;
        }
        total = total - 29 - this.GetBit(CalendarData[m], n);
      }
      if (isEnd) break;
    }
    cYear = 1921 + m;
    cMonth = k - n + 1;
    cDay = total;
    if (k == 12) {
      if (cMonth == Math.floor(CalendarData[m] / 0x10000) + 1) {
        cMonth = 1 - cMonth;
      }
      if (cMonth > Math.floor(CalendarData[m] / 0x10000) + 1) {
        cMonth--;
      }
    }
  },

  GetcDateString() {
    var tmp = "";
    /*显示农历年：（ 如：甲午(马)年 ）*/
    /*tmp+=tgString.charAt((cYear-4)%10); 
    tmp+=dzString.charAt((cYear-4)%12); 
    tmp+="("; 
    tmp+=sx.charAt((cYear-4)%12); 
    tmp+=")年 ";*/
    // if (cMonth < 1) {
    //   tmp += "(闰)";
    //   tmp += monString.charAt(-cMonth - 1);
    // } else {
    //   tmp += monString.charAt(cMonth - 1);
    // }
    // tmp += "月";

    tmp += (cDay < 11) ? "初" : ((cDay < 20) ? "十" : ((cDay < 30) ? "廿" : "三十"));
    if (cDay % 10 != 0 || cDay == 10) {
      tmp += numString.charAt((cDay - 1) % 10);
    }
    return tmp;
  },

  GetLunarDay(solarYear, solarMonth, solarDay) {
    //solarYear = solarYear<1900?(1900+solarYear):solarYear; 
    if (solarYear < 1921 || solarYear > 2020) {
      return "";
    } else {
      solarMonth = (parseInt(solarMonth) > 0) ? (solarMonth - 1) : 11;
      this.e2c(solarYear, solarMonth, solarDay);
      return this.GetcDateString();
    }
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})