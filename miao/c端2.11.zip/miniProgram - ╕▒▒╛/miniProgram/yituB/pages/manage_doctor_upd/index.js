// miniprogram/pages/manage_doctor_upd/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '医生', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    sex: ['男', '女'],
    sexIdx: 0,
    role: ['医院超级管理员', '医院管理员', '诊所超级管理员', '诊所管理员', '医院导诊员', '医院医生', '诊所医生'],
    roleIdx: 0,
    typeArr: ['本机构医生', '外机构医生'],
    typeIdx: 0,
    proName: '',
    proNameStu: true,
    proInfo: {
      remarkName: ''
    },

    doctorCode: "o7buL5SpzSCoTH5PZ7n7NDxlcYKk",
    hospitalCode: "YY002",
    kslist:[],
    ksIndex:0

  },
  bindSexChange1(e) {
    this.setData({
      roleIdx: e.detail.value
    })
  },
  bindSexChange2(e) {
    console.log(e)
    this.setData({
      typeIdx: e.detail.value
    })
  },
  bindSexChange4(e){
    console.log(e)
    this.setData({
      ksIndex: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    if (options.info) {
      let info = JSON.parse(options.info);
      console.log(info)
      this.setData({
        doctorCode: info.doctorCode || info.openId,
        hospitalCode: info.hospitalCode || info.myHospitalCode,
      })
    }
    this.queryHospitalDoctor();
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  querySysDict() {  //角色列表
    let that = this
    let type = wx.getStorageSync('userType')
    app.agriknow2.querySysDict({
      "type": type == 1 ? 'organization_roles_hospital' : 'organization_roles_clinic'
    }).then(res => {
      console.log(res)
     if(res.code==0){
       that.setData({
         role: res.sysDictList
       })
       for (var i in res.sysDictList) { 
         if (res.sysDictList[i].value == that.data.roleCode){
           that.setData({
             roleIdx: i
           })
           return false;
         }
       }
       if (that.data.roleCode){
         that.setData({
           superAdmin:!0,
           roleIdx: -1
         })
       }
     }
    })
  },

  querykeshilist(){
    let that = this
    app.agriknow2.hospitaldepartmentLists({
      "hospitalCode":wx.getStorageSync('hosCode'),//医院编码
    }).then(res=>{
      if(res.code==0){
        console.log(res)
        that.setData({
          kslist:res.page.list
        })
        for (var i in res.page.list) {
          if (res.page.list[i].departmentCode == that.data.myDepartmentCode) {
            that.setData({
              ksIndex: i
            })
            return false;
          }
        }
      }else{
        wx.showToast({
          title: res.msg,
          icon:'none'
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
  },


  // 医生详情
  queryHospitalDoctor(hosptitalCode) {
    console.log('---', hosptitalCode)
    var that = this;
    let params = {
      "doctorCode": that.data.doctorCode,
      "hospitalCode": wx.getStorageSync('hosCode'),
    }
    app.agriknow2.queryHospitalDoctor(params).then(res => {
      if (res.code === 0) {
        let data = res.doctorInfo;
        console.log(data)
        // that.setData({ proName: data.remarkName, proInfo: data, typeIdx: (data.relationship - 1), roleIdx: (data.roleLevel - 1)});
        that.setData({
          proName: data.remarkName,
          proInfo: data,
          typeIdx: (data.relationship - 1),
          roleCode: data.roleCode,
          myDepartmentCode: data.myDepartmentCode
        });
        that.querySysDict()
        this.querykeshilist();
      }else{
        wx.showToast({
          title: res.msg,
          icon:'none'
        })
      }
    })
  },

  // 医生修改
  updateMyHospitalDetail(hosptitalCode) {
    var that = this;
    let params = {
      "openId": that.data.proInfo.openId, //医生编码 必填
      "relationship": parseInt(that.data.typeIdx) + 1, //与医院关系 1：隶属（本机构） 2：合作（外机构） 必填
      "remarkName": that.data.proName, //医生备注名 必填
      "roleCode": that.data.superAdmin?that.data.roleCode:that.data.role[that.data.roleIdx].value, //角色编码 必填
      "myDepartmentCode": that.data.kslist.length>0 ? that.data.kslist[that.data.ksIndex].departmentCode : '', //本院科室编码 必填
      "myHospitalCode": wx.getStorageSync('hosCode'), //医院编码 必填
    }
    app.agriknow2.updateHospitalDoctor(params).then(res => {
      if (res.code === 0) {
        console.log(res)
        wx.showLoading({
          title: '修改成功',
          icon:'none'
        })
       setTimeout(function(){
         wx.navigateBack({
           delta: 1
         })
       },1500)
      }else{
        wx.showToast({
          title: res.msg,
          icon:'none'
        })
      }
    })
  },

  /**
   *  项目名称 验证
   */
  proNameBlur(e) {
    var that = this;
    let proName = e ? e.detail.value : e;
    if (proName.length > 1 && proName.length <= 15) {
      that.setData({
        proNameStu: true
      })
    } else {
      that.setData({
        proNameStu: false
      })
    }
    that.setData({
      proName: proName,
    })
    console.log(that.data.proNameStu)
  },

  // 选择医院
  toYiyuan() {
    wx.navigateTo({
      url: '../user_uadd_zhengsuo/index',
    })
  },

  // 选择科室
  toKeshi() {
    wx.navigateTo({
      url: '../user_uadd_keshi_list/index',
    })
  },

  // 选择职称
  toZhichen() {
    wx.navigateTo({
      url: '../user_uadd_zhichen/index',
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})