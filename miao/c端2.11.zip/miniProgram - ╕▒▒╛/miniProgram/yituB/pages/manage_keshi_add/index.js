// miniprogram/pages/manage_doctor_upd/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '新增科室', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    sex: ['男', '女'],
    sexIdx: 0,
    role: ['医院超级管理员', '医院管理员', '诊所超级管理员', '诊所管理员', '医院导诊员', '医院医生', '诊所医生'],
    roleIdx: 0,
    typeArr: ['本机构医生', '外机构医生'],
    typeIdx: 0,
    proName: '',
    proNameStu: true,
    proInfo: {
      remarkName: '',

    },

    doctorCode: "o7buL5SpzSCoTH5PZ7n7NDxlcYKk",
    hospitalCode: wx.getStorageSync('hosCode'),
    chooseSeries: {
      departmentName: '请选择'
    },

    isSelDoctor: [], // 添加科室所选择的医生
    isSelDoctorNum:'0人',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.info) {
      let info = JSON.parse(options.info);
      console.log(info)
      this.setData({ doctorCode: info.doctorCode, hospitalCode: info.hospitalCode })
    }
    this.queryHospitalDoctor();


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  disease() {
    wx.navigateTo({
      url: '/pages/manage_keshi_disease/index',
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   

    if (wx.getStorageSync('isSelDoctor')) {
      let isSelDoctor = JSON.parse(wx.getStorageSync('isSelDoctor'))
      this.setData({ isSelDoctor: isSelDoctor, isSelDoctorNum: isSelDoctor.length+'人' });
      console.log('所选择的医生=====', this.data.isSelDoctor)
    }
    if (wx.getStorageSync('chooseSeries')) {
      this.setData({
        chooseSeries: wx.getStorageSync('chooseSeries')
      })
    }
    if (wx.getStorageSync('disease')) {
      this.setData({
        disease: wx.getStorageSync('disease')
      })
    }


  },

  // 科室类型选择
  selTypeBtn() {
    wx.navigateTo({
      url: '../manage_keshi_type_sel/index',
    })
  },

  // 选择医生
  toSelDoctorBtn() {
    wx.navigateTo({
      url: '../manage_keshi_doctor_list/index',
    })
  },


  // 医生详情
  queryHospitalDoctor(hosptitalCode) {
    console.log('---', hosptitalCode)
    var that = this;
    let params = {
      "doctorCode": that.data.doctorCode,
      "hospitalCode": that.data.hospitalCode,
    }
    app.agriknow2.queryHospitalDoctor(params).then(res => {
      if (res.code === 0) {
        let data = res.doctorInfo;
        that.setData({ proName: data.remarkName, proInfo: data, typeIdx: (data.relationship - 1), roleIdx: (data.roleLevel - 1) });
      }
    })
  },

  // 医生修改
  updateMyHospitalDetail() {
    var that = this;
    let doctor = [];
    let isSelDoctor = that.data.isSelDoctor
    for (var item in isSelDoctor){
      doctor.push(isSelDoctor[item].doctorCode);
    }
    let data = {
      departmentName: this.data.ksname,//科室名称
      departmentType: this.data.chooseSeries.departmentType,//科室类型
      speciality: this.data.disease,//擅长疾病
      recommendationFee: this.data.intro,//推荐费
      doctorCodes: doctor, //科室医生编码列表 非必填
    }
    // 
    app.agriknow2.addDepartment(data).then(res => {
      console.log(res)
      if (res.code == 0) {
        wx.showToast({
          title: '添加成功',
          icon: 'none'
        })
        setTimeout(function () {
          wx.navigateBack({

          })
        }, 1500)
      }else{
        wx.showToast({
          title: res.msg,
          icon:'none'
        })
      }
    })
  },

  /**
  *  项目名称 验证
  */
  proNameBlur(e) {
    this.setData({
      ksname: e.detail.value
    })
  },
  intro(e) {
    this.setData({
      intro: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    wx.removeStorageSync('isSelDoctor')
    wx.removeStorageSync('chooseSeries')
    wx.removeStorageSync('disease')   
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})