// miniprogram/pages/user_1info_hospital/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '我的患者', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    array1: ['全部地区', '浙江', '上海', '杭州'],
    index1: 0,

    tabList: [
      { name: '全部病患', val: 0 },
      { name: '推荐中的病患', val: 1 },
      { name: '已就诊病患', val: 2 },
    ], // tab选项
    tabIndex:0,

    hospital1:[],
    // hospital1:[],
    // hospital2:[{title:'医院1',num:'12'},
    //   { title: '医院1', num: '12' }, { title: '医院1', num: '12' }, { title: '医院1', num: '12' }, { title: '医院1', num: '12' },
    // ],
    hospital2:[],

    allPatients:[], // 全部患者

    tuijianPatients:[], // 推荐中 患者
    haveseePatients:[], // 已就诊 患者
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.queryMyPatients(); // 我的-我的患者列表 api
    // this.queryHospitalRecommend(1); // 推荐中 
    // this.queryHospitalRecommend(2); // 已就诊
  },

  // 我的-我的患者列表 api  全部列表
  queryMyPatients() {
    let that = this;
    app.agriknow2.queryMyPatients({
      page: '1',
      limit: '100'
    }).then(res => {
      if (res.code === 0) {
        that.setData({ allPatients:res.page.list})
      }else{
        wx.showToast({
          title: res.msg,
          icon:'none'
        })
      }
    })
  },

  // 我的-我的患者列表 api  推荐中&已就诊
  queryHospitalRecommend(type) {
    let that = this;
    let params = { recommendState: type,
      page:'1',
      limit:'100'}
    app.agriknow2.queryHospitalRecommend1(params).then(res => {
      if (res.code === 0) {
        let data = res.page.list;
        if(type === 1){
          that.setData({ tuijianPatients: data })
        }else{
          that.setData({ haveseePatients: data })
        }
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },

  

  // 去推荐
  toTuijian(){
   
    wx.navigateTo({ url: '../user_3info_huanzhe_tuijian/index'}); //  去推荐
  },

  // 地区选择
  bindPickerChange1(e) {
    this.setData({
      index1: e.detail.value
    })
  },


  // 标题选择
  selTypeLine(e) {
    let tabIndex = e.currentTarget.dataset.idx;
    this.setData({ tabIndex: tabIndex });
    if (tabIndex === 0){
      this.queryMyPatients(); // 我的-我的患者列表 api
    } else if (tabIndex === 1){
      this.queryHospitalRecommend(1); // 推荐中 
    } else if (tabIndex === 2) {
      this.queryHospitalRecommend(2); // 已就诊
    }
  },

  // 患者详情
  detailBtn(e){
    app.tuijianPatients.huanzhe = e.currentTarget.dataset.info;
    wx.navigateTo({ url: '../user_3info_huanzhe_detail/index' }); // 患者信息
  },

  // 新增患者
  addHuanzheBtn(){
    wx.navigateTo({ url: '../user_3info_huanz_add/index' }); // 患者信息
  },

  // 发送消息
  sendInfo(){
    app.globalData.mysend = !0
    wx.navigateTo({ url: '../user_2info_Rhuanzhe_send_info/index' }); // 患者信息
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})