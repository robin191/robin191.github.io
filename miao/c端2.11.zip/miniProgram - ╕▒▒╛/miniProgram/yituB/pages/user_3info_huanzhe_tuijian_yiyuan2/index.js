// miniprogram/pages/user_1info_hospital/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '推荐', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    tabList: [
      { name: '附近的医院', val: 0 },
      { name: '合作过的医院', val: 1 },
    ], // tab选项
    tabIndex:0,

    hospital1:[],
    hospital2:[],
    selIdx:0,
    selIdx2:0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getMyCooperationHospital(); // 我的-正在合作中的医院 api
    this.getMyHistoryHospital(); // 我的-历史合作的医院 api
  },

  // 我的-正在合作中的医院 api
  getMyCooperationHospital() {
    let that = this;
    app.agriknow2.getNearbyHospital({
      "page": "1",//当前页码
      "limit": "100"//每页条数
    }).then(res => {
      if (res.code === 0) {
        that.setData({ hospital1: res.page.list});
      }
    })
  },

  // 我的-历史合作的医院 api
  getMyHistoryHospital() {
    let that = this;
    app.agriknow2.queryCooperateWithOrgan({
      type:1
    }).then(res => {
      if (res.code === 0) {
        that.setData({ hospital2: res.page.list});
      }
    })
  },

  // 合作中的医院
  selBtn1(e){
    this.setData({ selIdx: e.currentTarget.dataset.idx});
  },

  // 历史合作的医院
  selBtn2(e) {
    this.setData({ selIdx2: e.currentTarget.dataset.idx });
  },

  // 确定
  sureBtn(){

    if (this.data.tabIndex == 0){
      app.tuijianPatients.yiyuan = this.data.hospital1[this.data.selIdx];
    }else{
      app.tuijianPatients.yiyuan = this.data.hospital2[this.data.selIdx2];
    }
   
    wx.navigateBack({
      data:1
    })
  },

  // 标题选择
  selTypeLine(e) {
    console.log(e.currentTarget.dataset.idx);
    this.setData({ tabIndex: e.currentTarget.dataset.idx });

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})