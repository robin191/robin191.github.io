// miniprogram/pages/user_order_list/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
    showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '-推荐-', //导航栏 中间的标题
  },
  height: app.globalDatas.height * 2 + 20,
    tuijianSuccess:0, // 推荐成功状态
    array1: [
      '患者信息模板', "图片上传模板", "设定日程模板", "文件上传模板", "视频上传模板", "设定时间模板", 
      // { 'name':"患者信息模板", val:'1' },
      // { 'name': "图片上传模板", val: '2' },
      // { 'name': "设定日程模板", val: '3' },
      // { 'name': "文件上传模板", val: '4' },
      // { 'name': "视频上传模板", val: '5' },
      // { 'name': "设定时间模板", val: '6' },
      ],
    index1: 0,

    typeArr: [ '推荐到医院', '推荐到诊所'],
    typeIdx:1,
    array2: [
      '患者信息模板', "图片上传模板", "设定日程模板", "文件上传模板", "视频上传模板", "设定时间模板",
    ],
    index2: 0,
    tuijianPatients:{},// 推荐患者信息
    tuijianInfo: { zhensuo: {}, doctor: {} } // doctorCode hospitalCode
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   
  },


  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({ tuijianInfo: app.managetTuijianPatients});
  },

  // 进行推荐
  cooperationHospitalWay() {
    var that = this;
    let tuijianPatients = app.managetTuijianPatients;
    if (!tuijianPatients.zhensuo.code){
      wx.showToast({
        title: '请选择诊所',
      })
      return;
    }

    // 推荐到诊所
    let params = {
      "patientName": tuijianPatients.userName,//患者姓名
      "patientCoding": tuijianPatients.openId,//患者编码
      "patientPhone": tuijianPatients.mobilePhone,//患者手机号
      "acceptDoctorCode": tuijianPatients.doctor.doctorCode,//接收医生，非必须
      "recommenderType": 2,//医院推荐（固定传参）
      "recommendType": that.data.typeIdx + 1,//推荐类型 1:推荐到医院 2：推荐到诊所
      "acceptHospitalCode": tuijianPatients.zhensuo.code,//接收患者的医院编码
      "acceptHospitalName": tuijianPatients.zhensuo.name//接收患者的医院名称
    }


    if ( (that.data.typeIdx+1) == 2) {  // 推荐到医院

      params = {
        "patientName": tuijianPatients.userName,//患者姓名
        "patientCoding": tuijianPatients.openId,//患者编码
        "patientPhone": tuijianPatients.mobilePhone,//患者手机号

        "recommendHospitalCode": wx.getStorageSync('hosCode'),//推荐医院编码
        "recommendDoctorCode": wx.getStorageSync('docCode'),//推荐医生
        "acceptDoctorCode": tuijianPatients.doctor.doctorCode,//接收医生，非必须
        "recommenderType": 2,//机构推荐（固定传参）
        "recommendType": that.data.typeIdx + 1,//推荐类型 1:推荐到医院 2：推荐到诊所
        "acceptHospitalCode": tuijianPatients.zhensuo.code,//接收患者的医院编码
        "acceptHospitalName": tuijianPatients.zhensuo.name//接收患者的医院名称
      }

    }


    app.agriknow2.recommendPatient(params).then(res => {
      if(res.code === 0){
        wx.navigateBack({ delta: 1 })
      }
    })
  },




  // 诊所选择
  selZhenSuo(){
    wx.navigateTo({ url: '../manage_3_huanzhe_tuijian_zhensuo/index' }); // 诊所选择
  },
  // 诊所医生
  selYisheng() {
    wx.navigateTo({ url: '../manage_3_huanzhe_tuijian_yisheng/index' }); // 诊所医生
  },
// 医院
  selYiyuan() {
    wx.navigateTo({ url: '../manage_3_huanzhe_tuijian_yiyuan/index' }); // 诊所医院
  },
  // 医院科室
  selKeshi() {
    wx.navigateTo({ url: '../manage_3_huanzhe_tuijian_keshi/index' }); // 医院科室
  },


  // 新增患者
  addHuanzheBtn() {
    wx.navigateTo({ url: '../project_add_user_list/index' }); // 患者信息
  },

  // 发送消息
  sendInfo() {
    wx.navigateTo({ url: '../project_add_user_list/index' }); // 患者信息
  },

  userQRTo(){
    wx.navigateTo({
      url: '../user_add_QR/index',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  // 性别选择
  bindTypeChange(e){
    this.setData({
      typeIdx: e.detail.value
    })
  },

  // 事件模板选择
  bindPickerChange1(e) {
    this.setData({
      index1: e.detail.value
    })
  },

  // 执行人选择
  bindPickerChange2(e) {
    this.setData({
      index2: e.detail.value
    })
  },

  // 显示加载动画
  showLoading: function () {
    wx.showLoading({
      title: '加载中...',
      icon: 'loading'
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '浦江行',
      path: 'pages/i_sel_site/index1',
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  }
})

/**
 * 提示框
 */
function showToastWay(msg) {
  wx.showToast({
    title: msg,
    icon: 'none',
    duration: 1500
  })
}