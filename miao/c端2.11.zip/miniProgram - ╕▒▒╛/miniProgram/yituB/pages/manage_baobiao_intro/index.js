// pages/manage_baobiao_intro/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '推荐报表', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    startTime1:'开始日期',
    endTime1:'结束日期',
    startTime:null,
    endTime:null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getTableInfo()
  },
  getTableInfo(){
    let that=this
    app.agriknow2.myHospitalRecommendReport({
      beginTime:this.data.startTime,
      endTime:this.data.endTime
    }).then(res=>{
      console.log(res)
      that.setData({
        list:res.page.list
      })
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  chooseStartTime(e){
    console.log(e.detail.value)
    let starttime = new Date(e.detail.value).getTime()
    if (this.data.endTime == null){
      this.setData({
        startTime: e.detail.value
      })
      this.getTableInfo()
    }else{
      let endtime = new Date(this.data.endTime).getTime()
      if (endtime >= starttime){
        this.setData({
          startTime: e.detail.value
        })
        this.getTableInfo()
      }else{
        wx.showToast({
          title: '结束日期不能早于开始日期',
          icon: 'none'
        })
      }
    }
    
  },
  chooseEndTime(e){
    console.log(e.detail.value)
    let endtime = new Date(e.detail.value).getTime()
    let starttime = this.data.startTime == null ? 0 : new Date(this.data.startTime).getTime()
    console.log(endtime, starttime)
    if (endtime >= starttime) {
      this.setData({
        endTime: e.detail.value
      })
      this.getTableInfo()
    } else {
      wx.showToast({
        title: '结束日期不能早于开始日期',
        icon: 'none'
      })
    }
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})