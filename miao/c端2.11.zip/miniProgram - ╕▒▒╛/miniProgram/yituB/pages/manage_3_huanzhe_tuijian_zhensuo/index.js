// miniprogram/pages/user_1info_hospital/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {

    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '推荐', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    tabList: [
      { name: '附近的医院', val: 0 },
      { name: '合作过的遗言', val: 1 },
    ], // tab选项
    tabIndex:0,
    selIndex:0,
    hospital1: [{ title:'诊所1诊所1',num:'1534545442'},
      { title: '诊所1', num: '115345454422' }, { title: '诊所1', num: '115345454422' }, { title: '诊所1', num: '12' }, { title: '诊所1', num: '115345454422' },
    ],
    // hospital1:[],
    // hospital2:[{title:'医院1',num:'12'},
    //   { title: '医院1', num: '12' }, { title: '医院1', num: '12' }, { title: '医院1', num: '12' }, { title: '医院1', num: '12' },
    // ],
    hospital2:[],

    hospitalList:[], // 医院列表

    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getMyCooperationHospital(); // 医院列表
  },

  // 医院列表
  getMyCooperationHospital() {
    console.log('获取医院列表')
    var that = this;
    let params = {
      "name": "",//医院名称 非必传
      "type": 2 //医院类型 1：医院 2：诊所 必传
    }
    app.agriknow2.queryCooperateWithOrganMan(params).then(res => {
      console.log(res);
      let data = res.page.list;
      that.setData({ hospitalList: data })
    })
  },

  // 进行选择内容
  selBtn(e){
    this.setData({ selIndex: e.currentTarget.dataset.idx});
  },

  // 返回到推荐
  sureBtn(){
    app.managetTuijianPatients.zhensuo = this.data.hospitalList[this.data.selIndex]
    wx.navigateBack({ delta: 1 })
  },
  // 地区选择
  bindPickerChange1(e) {
    this.setData({
      index1: e.detail.value
    })
  },


  // 标题选择
  selTypeLine(e) {
    console.log(e.currentTarget.dataset.idx);
    this.setData({ tabIndex: e.currentTarget.dataset.idx });

  },

  returnBtn(){
    wx.navigateBack({//返回
      delta: 1
    })
  },

  // 新增患者
  addHuanzheBtn(){
    wx.navigateTo({ url: '../project_add_user_list/index' }); // 患者信息
  },

  // 发送消息
  sendInfo(){
    wx.navigateTo({ url: '../project_add_user_list/index' }); // 患者信息
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})