// miniprogram/pages/user_register/index.js
const app = getApp();
let timer = null;
Page({

  /**
   * 页面的初始数据
   */
  data: {

    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '添加患者', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    toastTitle: '',
    toastInfo: '',
    toastIsStu: false,

    saoNoUser:-1, // -1 用户添加 1 有用户  0 无用户
    isBtn: false,
    // 用户所填数据 
    registData: {
      companyId: wx.getStorageSync("companyId"),//  String	是	公司ID 
      phoneNum: '',	//	String	是	手机号码 17888211416
      phoCode: '',      // 验证码 
    },
    
    //  数据验证是否填写正确
    registEreg: {
      phoneNum: true,	 //	  String	是	手机号码
      phoCode: false   //   验证码是否填写正确
    },

    codeTime: -1,   // 验证码失效时间设置
    phoCodeApi: '', // 后台返回的验证码

    huanzheInfo:{}, // 患者信息
    openId:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
  * 提交事件
  */
  registinfoWay: function () {
    let that = this;
    // 验证手机号
    if (!that.data.openId) {
      if (!phoneRegWay(that.data.registData.phoneNum)) {
        return;
      }
    } else {
      showToastWay('请进行扫描或输入手机号')
    }
    // openId: that.data.openId || undefined 
    app.agriknow2.queryClientUserinfo1({ mobilePhone: that.data.registData.phoneNum || undefined, openId: that.data.openId || undefined }).then(res => {
      if (res.code === 0){
        if (res.clientUserinfoReturn.id){
          that.setData({ saoNoUser: 1 });
        }else{
          that.setData({ saoNoUser: 0 });
        }
        that.setData({ huanzheInfo: res.clientUserinfoReturn });
        app.createProInfo.huanzhe = [res.clientUserinfoReturn]
      }else{
        wx.showToast({
          title: res.msg,
          icon:'none'
        })
      }
    })
  },


  saoBtn(){
    let that = this;
    wx.scanCode({
      success(res) {
        if (res.errMsg == 'scanCode:ok'){
          that.setData({ openId: res.result});
          that.registinfoWay();
        }else{
          wx.showToast({
            title: '无法识别',
            icon: 'none',
          })
        }
        console.log('====扫描')
        console.log(res)
      },
      fail(){
        wx.showToast({
          title: '无法识别',
          icon: 'none',
        })
      }
    });
    // this.setData({ saoNoUser:-1});
  },

  returnPage2() {
    app.createProInfo.huanzhe = this.data.huanzheInfo
    wx.navigateBack({
      delta: 1
    })
  },

  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({ toastTitle: title, toastInfo: info, toastIsStu: true });
    var time = setInterval(function () {
      that.setData({ toastTitle: title, toastInfo: info, toastIsStu: false });
      clearInterval(time);
    }, 3000);
  },


  // 返回
  returnPage(){

    wx.navigateBack({ delta: 1 })
  },

  /**
   *  获取界面手机号
   */
  phoneNumBlur(e){
    this.setData({['registData.phoneNum']: e.detail.value})
    if (this.data.registData.phoneNum !== '' && this.data.registData.phoneNum.length === 11) {
      this.setData({ ['registEreg.phoneNum']: true });
    } else {
      this.setData({ ['registEreg.phoneNum']: false });
    }
  },

  

 
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
    }
    return {
      title: '医好康',
      path: 'pages/i_sel_site/index1',
      success: function (res) {
        // 转发成功
      },
      fail: function (res) {
        // 转发失败
      }
    }
  }
})

/**
 * 提示框
 */
function showToastWay(msg){
  wx.showToast({
    title: msg,
    icon: 'none',
    duration: 1500
  })
}

/**
*  加载等待提示框
*/
function showLoading(msg) {
  wx.showToast({
    title: '加载中',
    icon: 'loading'
  });
}
/**
*  取消等待提示框
*/
function cancelLoading() {
  wx.hideToast();
}

/**
*  手机号码验证
*/
function phoneRegWay(phone){
  if (phone==null||phone==''){
    showToastWay('请输入手机号')
    return false;
  }
  var phoneReg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
  if (!phoneReg.test(phone)) {
    showToastWay('手机号有误！')
    return false;
  }
  return true;
}