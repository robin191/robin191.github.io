// miniprogram/pages/user_order_list/index.js
const app = getApp();
var uploadImage = require('../../utils/uploadFile.js');
var util = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '我的', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    imgUrl: [],
    array1: [
      '患者信息模板', "图片上传模板", "设定日程模板", "文件上传模板", "视频上传模板", "设定时间模板",
      // { 'name':"患者信息模板", val:'1' },
      // { 'name': "图片上传模板", val: '2' },
      // { 'name': "设定日程模板", val: '3' },
      // { 'name': "文件上传模板", val: '4' },
      // { 'name': "视频上传模板", val: '5' },
      // { 'name': "设定时间模板", val: '6' },
    ],
    index1: 0,

    sexArr: ['男', '女'],
    sexIdx: 0,
    array2: [
      '患者信息模板', "图片上传模板", "设定日程模板", "文件上传模板", "视频上传模板", "设定时间模板",
    ],
    index2: 0,

    userInfo: {},

    userNameStu: true, //昵称
    idNumberStu: true, //身份证

    diseaseType: 0,
    userDetail: {
      yiyuan: {
        type: 0
      },
      zhensuo: {}
    },

    isShowKeshi: 1, // 1 显示  0 不显示
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.queryMyDoctorInfo(); // 个人信息
    if (wx.getStorageSync('chooseSeries')) {
      wx.removeStorageSync('chooseSeries')
    }

  },


  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    if (app.userDetailInfo.yiyuan.type == 2) { // 当选择诊所时， 科室置空
      app.userDetailInfo.keshi = undefined;
      this.setData({
        isShowKeshi: 0
      })
    } else if (app.userDetailInfo.yiyuan.type == 1) {
      this.setData({
        isShowKeshi: 1
      })
    }

    console.log(app.userDetailInfo)
    if (app.userDetailInfo.yiyuan.city) { // 当选择过医院之后，重新
      if (app.userDetailInfo.keshi) {
        if (app.userDetailInfo.yiyuan.code !== app.userDetailInfo.keshi.hospitalCode) {
          app.userDetailInfo.keshi = undefined;
        }
      }

    }

    this.setData({
      userDetail: app.userDetailInfo
    }); // 医院  诊所  科室 yiyuan   keshi

    // 擅长疾病

      if (this.data.diseaseType == 1) {
        this.setData({
          ['userInfo.speciality']: wx.getStorageSync('disease')
        })
      } else {
        this.setData({
          ['userInfo.personalProfile']: wx.getStorageSync('disease')
        })
      }

  },

  // 身份证
  idNumberBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name !== '' && name.length === 18) {
      that.setData({
        idNumberStu: true
      })
    } else {
      that.setData({
        idNumberStu: false
      })
    }
    that.setData({
      ['userInfo.idNumber']: name,
    })
  },

  // 姓名
  userNameBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name.length > 1) {
      that.setData({
        userNameStu: true
      })
    } else {
      that.setData({
        userNameStu: false
      })
    }
    that.setData({
      ['userInfo.userName']: name,
    })
  },


  // 职称
  titleCodeBlur(e) {
    this.setData({
      ['userInfo.titleCode']: name,
    })
  },



  // 个人信息 修改api
  updateMyDoctorInfo(e) {
    let that = this;
    console.log('----', that.data.sexIdx, '--', parseInt(that.data.sexIdx + 1))
    let params = {
      "avatarUrl": e, //头像地址
      "sex": parseInt(that.data.sexIdx) + 1, //性别  1：男 2：女
      "nickName": that.data.userInfo.userName, //昵称
      "idNumber": that.data.userInfo.idNumber, //身份证
      "hospitalCode": that.data.userDetail.yiyuan.code, //医院编码
      "departmentCode": that.data.userDetail.keshi ? that.data.userDetail.keshi.departmentCode || undefined : undefined, //科室
      "titleCode": that.data.userDetail.zhichen.value, //职称
      "speciality": that.data.userInfo.speciality, // 疾病
      "personalProfile": that.data.userInfo.personalProfile // 简介
    };

    app.agriknow2.updateMyDoctorInfo(params).then(res => {
      if (res.code === 0) {
        wx.navigateBack({

        })
      }
    })
  },

  // 个人信息
  queryMyDoctorInfo() {
    let that = this;
    app.agriknow2.queryMyDoctorInfo().then(res => {
      if (res.code === 0) {
        let data = res.doctorInfo;
        that.setData({
          userInfo: res.doctorInfo,
          sexIdx: parseInt(data.sex) - 1 || 0,
          ['userDetail.yiyuan.code']: data.hospitalCode,
          ['userDetail.keshi.departmentCode']: data.departmentCode,
          ['userDetail.yiyuan.name']: data.hospitalName,
          ['userDetail.keshi.departmentName']: data.departmentName,

        });


      }
    })
  },

  userQRTo() {
    wx.navigateTo({
      url: '../user_add_QR/index',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },

  // 选择医院
  toYiyuan() {
    wx.navigateTo({
      url: '../user_uadd_zhengsuo/index',
    })
  },

  // 选择科室
  toKeshi() {
    wx.navigateTo({
      url: '../user_uadd_keshi_list/index',
    })
  },

  // 选择职称
  toZhichen() {
    wx.navigateTo({
      url: '../user_uadd_zhichen/index',
    })
  },


  userQRTo() {
    wx.navigateTo({
      url: '../user_add_QR/index',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },

  // 性别选择
  bindSexChange(e) {
    this.setData({
      sexIdx: e.detail.value
    })
  },


  // 跳转输入内容
  disease(e) {
    this.setData({
      diseaseType: e.currentTarget.dataset.type
    })
    if(this.data.diseaseType==1){
      var con = this.data.userInfo.speciality
    }else{
      var con = this.data.userInfo.personalProfile
    }
    wx.navigateTo({
      url: '/pages/manage_keshi_disease/index?type=' + e.currentTarget.dataset.type + '&con=' +con,
    })
  },

  // 显示加载动画
  showLoading: function() {
    wx.showLoading({
      title: '加载中...',
      icon: 'loading'
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  changeImg() {
    let that = this,
      userInfo = this.data.userInfo
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function(res) {
        console.log(res)
        userInfo.avatarUrl = res.tempFilePaths[0]
        that.setData({
          userInfo: userInfo,
          imgUrl: res.tempFilePaths
        });
      },
    })
  },
  updloadWay1: function() {



    console.log(1)
    var nowTime = util.formatTime(new Date());
    let data = this.data.imgUrl;
    let that = this;
    let arr = [],
      n = -1


    if (!phoneRegWay(that.data.userInfo.idNumber)) {
      return;
    }

    if (data.length > 0) {
      for (var item in data) {
        let typeArr = data[item].split('.');

        let type = typeArr[typeArr.length - 2] + '.' + typeArr[typeArr.length - 1];
        console.log(item, data.length)
        uploadImage(type, data[item], 'img/' + nowTime + '/',
          function(result) {
            arr.push(result)

            n++;
            console.log(item, data.length - 1, n)
            if (item == data.length - 1 && item == n) {
              console.log('------------')
              that.uploadImageTemplateWay(arr); // 保存到数据库
            }
          },
          function(result) {}
        )
      }
    } else {
      this.updateMyDoctorInfo(this.data.userInfo.avatarUrl)
    }

  },
  // 保存到数据库
  uploadImageTemplateWay: function(result, item) {
    console.log(result)
    var that = this;
    this.updateMyDoctorInfo(result[0])

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {
    wx.removeStorageSync('disease')
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function(ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '浦江行',
      path: 'pages/i_sel_site/index1',
      success: function(res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function(res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  }
})

/**
* 身份证验证
*/
function phoneRegWay(phone) {
  if (phone == null || phone == '') {
    showToastWay('请输入身份证')
    return false;
  }
  var reg = /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/;

  if (!reg.test(phone)) {
    showToastWay('请输入有效身份证号！')
    return false;
  }
  return true;
}


/**
 * 提示框
 */
function showToastWay(msg) {
  wx.showToast({
    title: msg,
    icon: 'none',
    duration: 1500
  })
}
