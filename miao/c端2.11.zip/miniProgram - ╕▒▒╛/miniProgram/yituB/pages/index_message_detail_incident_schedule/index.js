// miniprogram/pages/project_list_detail_ memo_add/index.js
const app = getApp();
var uploadImage = require('../../utils/uploadFile.js');
var util = require('../../utils/util.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {

    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '日程模板', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    isBtn: false,
    noBtn: false, // 不可操作
    toastTitle: '',
    toastInfo: '',
    toastIsStu: false,

    saoNoUser: 1, // 1 显示  0 隐藏
    mobelStu: 0,  // 输入手机号  1 弹  0 隐藏
    messageInfo: undefined,
    messageInfo2: {},


    memoList: [],   // 移交与备注列表
    memoIndex: 0,
    index2: 0,
    time: '请选择具体时间',




    // 项目移交
    removeProStu: 0, // 移交项目长弹框  1 弹  0 隐藏
    removeProStuMemo: 0, // 添加备注

    eventCode: 'YY000100010005', // YY00300020002 YY00200350004
    projectCode: '', // 项目code
    incidentDetail: {}, // 事件详情

    

    userList: [], // 成员
    teamList: [], //移交对象列表
    teamOldList: [], // 原始数据
    teamIdx: 0, // 移交对象下标
    executorContent: '', // 移交 备注

    isOperation:false, // 确认提交 
    isShowBtn: false, //  移交

    isDefault: false,
    longitude: '',
    latitude: '',
    address: '',
    content: '',
    contenri:'',
    contenriStu: true,

    startdate: "2016-09-01",
    startweek: '周三',
    starttime: "12:01",

    enddate: "2016-09-01",
    endtweek: '周三',
    endtime: "12:01",

    nowPage: 1,
    hasData: -1, // -1 初始化   1 有数据  0 无数据
    isLoading: 1, // -1 初始化   1 加载    0 隐藏
    info:{},
    isBtn:false
  },
  gomes() {
    app.globalData.gomes = !0
    wx.navigateBack({

    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options) {
      let info = JSON.parse(options.info);
      if (info.isExecutor == 1 && info.isComplete == 0){ // 可进行添加日程
        this.setData({ isOperation:true});
      }else{
        this.queryScheduleByEventCode();// 日程信息 api 从后台获取
      }
      if (info.isExecutor == 1) { // 可进行移交
        this.setData({ isShowBtn: true });
      }

      this.setData({ info: info, eventCode: info.eventCode, projectCode: info.projectCode });
    }
    let dates = new Date();
    let month = parseInt(dates.getMonth() + 1) + ''
    let nowDate = dates.getFullYear() + '-' + (month > 9 ? month : ('0' + month)) + '-' + (dates.getDate() > 9 ? dates.getDate() : ('0' + dates.getDate()))
    let week = this.getWeekDate(dates);
    let time = dates.getHours() + ':' + dates.getMinutes();
    this.setData({ startdate: nowDate, enddate: nowDate });

    this.setData({ startweek: week, endtime: week });
    this.setData({ starttime: time, endtime: parseInt(dates.getHours() + 1) + ':' + dates.getMinutes() })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.readMessage();
    this.getEventBaseInfo(); // 事件信息 详情
    this.queryScheduleByEventCode();// 日程信息 api 从后台获取
    this.queryIsRead(); // 团队成员
    this.eventremarksList(); // 备注与移交列表
  },

  /**
 * 页面相关事件处理函数--监听用户下拉动作
 */
  onPullDownRefresh: function () {
    // 显示顶部刷新图标  
    wx.showNavigationBarLoading();
    this.eventremarksListOne('pull');
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.hasData >= 1) {
      
      this.eventremarksList();
    }
  },

  // 备注与移交列表
  eventremarksListOne(type) {
    this.setData({ nowPage: 1 });
    let that = this;

    let params = { "page": that.data.nowPage + '', "limit": "10", "eventCode": that.data.eventCode, };
    app.agriknow2.eventremarksList(params).then(res => {

      if (res.code === 0) {
        let data = res.page.list;
        for (var item in data) {
          data[item].createTime = data[item].createTime ? data[item].createTime.substring(5, 16) : data[item].createTime;
        }
        if (data.length >= 10) {
          that.setData({ hasData: 1 });
          this.setData({ nowPage: parseInt(that.data.nowPage) + 1 })
        } else {
          that.setData({ hasData: -1 });
        }
        if (type === 'pull') {
          // 隐藏导航栏加载框  
          wx.hideNavigationBarLoading();
          // 停止下拉动作  
          wx.stopPullDownRefresh();
        }
        that.setData({ memoList: data });
      }
    })
  },

  // 备注与移交列表
  eventremarksList() {
    let that = this;
    let params = { "page": that.data.nowPage + '', "limit": "10", "eventCode": that.data.eventCode, };
    app.agriknow2.eventremarksList(params).then(res => {
      if (res.code === 0) {
        let data = res.page.list;
        for (var item in data) {
          data[item].createTime = data[item].createTime ? data[item].createTime.substring(5, 16) : data[item].createTime;
        }
        if (data.length >= 10) {
          this.setData({ nowPage: parseInt(that.data.nowPage) + 1 })
          that.setData({ hasData: 1 });
        } else {
          that.setData({ hasData: -1 });
        }
        that.setData({ memoList: that.data.memoList.concat(data) });
      }
    })
  },


  // 日程信息 api 从后台获取
  queryScheduleByEventCode() {
    let that = this;
    let params = { "eventCode": that.data.eventCode, };
    app.agriknow2.queryScheduleByEventCode(params).then(res => {
      if (res.code === 0) {
        let data = res.mySchedule;
        let start = data.beginTime.split(' ');
        console.log()
        let startweek = this.getWeekDate(new Date(start[0]));
        let end = data.endTime.split(' ');
        let endweek = this.getWeekDate(new Date(end[0]));
        that.setData({ 
          contenri: data.content, 
          longitude: data.lngNum, 
          latitude: data.latNum, 
          isDefault: data.deleteFlag == 1 ? true:false,
          address: data.address,

          startdate: start[0],
          startweek: startweek,
          starttime: start[1],

          enddate: end[0],
          endtweek: endweek,
          endtime: end[1],
        });         
      }
    })
  },

  // *************************** 添加日程 开始 ***************************
  // 添加日程 api
  addSchedule() {
    let that = this;

    if (that.data.contenri.length < 2) {
      that.toastSetWay('', '请输入日程标题(至少2个字)', true);
      return;
    }
    // if (that.data.address.length < 1) {
    //   that.toastSetWay('', '请输入日程地址', true);
    //   return;
    // }

    let start = that.data.startdate + ' ' + that.data.starttime;
    let end = that.data.enddate + ' ' + that.data.endtime;
    let starts = new Date(start)
    let ends = new Date(end)
    if (ends < starts) {
      that.toastSetWay('', '重新选择结束时间（结束时间小于开始时间）', true);
      return;
    }


    let params = {
      "eventCode": that.data.eventCode,
      "doctorCode": wx.getStorageSync('docCode'),
      "content": that.data.contenri,
      "beginTime": that.data.startdate + ' ' + that.data.starttime + ':00',
      "endTime": that.data.enddate + ' ' + that.data.endtime + ':00',
      "wholeDay": that.data.isDefault ? 1 : 0, //是否全天日程 0：否 1：是 必填
      "address": that.data.address,
      "lngNum": that.data.longitude,
      "latNum": that.data.latitude
    };
    app.agriknow2.commitScheduleTemplateModel(params).then(res => {
      if (res.code === 0) {
        that.toastSetWay('', '添加成功', true);
        that.setData({
          noBtn: true, isOperation:false })
      }
    })
  },

  switchChangeDefault(e) {
    if (this.data.isOperation && !this.datanoBtn){
      this.setData({ isDefault: e.detail.value });
      if (this.data.isDefault) {
        this.setData({
          enddate: this.data.startdate,
          endtweek: this.data.startweek,
          starttime: '00:00',
          endtime: '23:59',
        })
      }
    }else{
      this.setData({ isDefault: this.data.isDefault});
    }
    
  },

  getWeekDate(now) {
    var day = now.getDay();
    var weeks = new Array("星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六");
    var week = weeks[day];
    return week;
  },

  startDateChange: function (e) {
    console.log('日程=====开始时间')
   
      let dates = new Date(e.detail.value);
      let week = this.getWeekDate(dates);
      this.setData({
        startdate: e.detail.value, startweek: week
      })
    
  },
  endDateChange: function (e) {
    let dates = new Date(e.detail.value);
    let week = this.getWeekDate(dates);
    this.setData({
      enddate: e.detail.value, endtweek: week
    })
  },

  startTimeChange: function (e) {
    this.setData({
      starttime: e.detail.value
    })
  },
  endTimeChange: function (e) {
    this.setData({
      endtime: e.detail.value
    })
  },




  /**
   *  备注信息验证
   */
  contenriBlur(e) {
    var that = this;
    let contenri = e.detail.value;
    if (contenri.length > 1 && contenri.length <= 15) {
      that.setData({ contenriStu: true })
    } else {
      that.setData({ contenriStu: false })
    }
    that.setData({
      contenri: contenri,
    })
  },

  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({ toastTitle: title, toastInfo: info, toastIsStu: true });
    var time = setInterval(function () {
      that.setData({ toastTitle: title, toastInfo: info, toastIsStu: false });
      clearInterval(time);
    }, 3000);
  },

  // 添加日程
  addProjectBtn() {
    wx.reLaunch({
      url: '../user-detail/userdetail',
    })
  },


  // 选择上传站点
  mapAddress() {
    var that = this;
    wx.chooseLocation({
      success: function (res) {
        // success
        that.setData({
          // hasLocation: true,
          longitude: res.longitude,
          latitude: res.latitude,
          address: res.name,
          name: res.name
        })
        app.selUserSite = { type: 1, address: res.name, addressCompany: that.data.addressCompany }
      },
      fail: function () {
        // fail
      },
      complete: function () {
        // complete
      }
    })
  },

  // *************************** 添加日程 结束 ***************************


 
  // 移交处理人列表
  queryProjectTeamsPro() {
    let that = this;
    that.opeanYiJiaoBtn(); // 打开移交窗口
    that.setData({ isBtn: false })
    let params = { "eventCode": that.data.eventCode, };
    app.agriknow2.queryProjectTeamsPro(params).then(res => {
      if (res.code === 0) {
        let data = res.projectTeamList;
        let arr = [];
        for (var item in data) {
          arr.push(data[item].remarkName || '暂无名称');
        }
        that.setData({ teamList: arr, teamOldList: data });
        // teamList: [], //移交对象列表
        //   teamOldList: [], // 原始数据
      }
    })
  },

  // 移交事件
  changeEventExecutor() {
    let that = this;
    let teamOldList = that.data.teamOldList;
    let executor = '';
    for (var item in teamOldList) {
      if (teamOldList[item].remarkName == that.data.teamList[that.data.teamIdx]) {
        executor = teamOldList[item].doctorCode
      }
    }
    let params = {
      "code": that.data.eventCode,//事件编码
      "content": that.data.executorContent,//备注内容
      "executor": executor//接收人编码
    };
    that.setData({ isBtn:true})
    app.agriknow2.changeEventExecutor(params).then(res => {
      
      if (res.code === 0) {
        that.setData({ isOperation: false });
        that.setData({ isBtn: false })
        that.setData({ executorContent: '' });
        that.closeYiJiaoBtn();
        that.eventremarksListOne(); // 备注与移交列表
      }else{
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },

  // 事件信息 详情
  getEventBaseInfo() {
    let that = this;
    let params = { "code": that.data.eventCode, };
    app.agriknow2.getEventBaseInfo(params).then(res => {
      if (res.code === 0) {
        res.eventInfo.data1 = res.eventInfo.createTime ? res.eventInfo.createTime.substring(5, 7) : res.eventInfo.createTime;
        res.eventInfo.createTime = res.eventInfo.createTime ? res.eventInfo.createTime.substring(5, 16) : res.eventInfo.createTime
        that.setData({ incidentDetail: res.eventInfo, projectCode: res.eventInfo.projectCode });
    
      }
    })
  },

  // 项目进行已读
  readMessage() {
    let that = this;
    let params = {
      "messageId": that.data.info.messageId, //消息ID 必填
    };
    app.agriknow2.readMessage(params).then(res => {
      if (res.code === 0) {
      }
    })
  },

  // 团队成员查看状态 
  queryIsRead() {
    let that = this;
    let params = { "eventCode": that.data.eventCode, };
    app.agriknow2.queryIsRead(params).then(res => {
      if (res.code === 0) {
        that.setData({ userList: res.messageReceiverRelationVos });
      }
    })
  },

  

  // 添加备注
  addEventRemark() {
    let that = this;
    if (that.data.content.length < 3) {
      wx.showToast({
        title: '请填写备注说明（至少3个字）',
        icon:'none'
      })
      return;
    } else if (that.data.content.length > 120) {
      wx.showToast({
        title: '请填写备注说明（最多120个字符）',
        icon: 'none'
      })
      return;
    }
    that.setData({ isBtn:true})
    let params = {
      "eventCode": that.data.eventCode,
      "content": that.data.content//备注内容 必填
    };
    app.agriknow2.addEventRemark(params).then(res => {
      that.setData({ isBtn: false })
      if (res.code === 0) {
        that.closeMemoBtn();
        that.setData({ content: '' });
        that.eventremarksListOne(); // 备注与移交列表
      }
    })
  },

  /**
     *  移交备注信息验证
     */
  executorContentBlur(e) {
    var that = this;
    let executorContent = e ? e.detail.value : e;
    // if (content.length > 1 && content.length <= 15) {
    //   that.setData({ contentStu: true })
    // } else {
    //   that.setData({ contentStu: false })
    // }
    that.setData({
      executorContent: executorContent,
    })
  },

  /**
   *  备注信息验证
   */
  contentBlur(e) {
    var that = this;
    let content = e ? e.detail.value : e;
    if (content.length > 1 && content.length <= 15) {
      that.setData({ contentStu: true })
    } else {
      that.setData({ contentStu: false })
    }
    that.setData({
      content: content,
    })
  },

  // 移交人选择
  teamChange(e) {
    this.setData({
      teamIdx: e.detail.value
    })
  },


  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({ toastTitle: title, toastInfo: info, toastIsStu: true });
    var time = setInterval(function () {
      that.setData({ toastTitle: title, toastInfo: info, toastIsStu: false });
      clearInterval(time);
    }, 3000);
  },


  sureBtn() {
    wx.navigateTo({ url: '../index_message_list/index' }); // 跳转到售票页面
  },

  // 打开移交窗口
  opeanYiJiaoBtn() {
    this.setData({ removeProStu: 1 });
  },

  // 关闭移交窗口
  closeYiJiaoBtn() {
    this.setData({ removeProStu: 0 });
  },

  // 打开备注窗口
  opeanMemoBtn() {
    this.setData({ isBtn: false })
    this.setData({ removeProStuMemo: 1 });
  },

  // 关闭备注窗口
  closeMemoBtn() {
    this.setData({ removeProStuMemo: 0 });
  },

  // 新增事件
  addProjectBtn() {
    app.getProjectInfo = this.data.projectCode;
    wx.navigateTo({ url: '../project_add_incident/index' }); // 跳转到售票页面
  },

  // 时间选择
  bindTimeChange(e) {
    this.setData({
      time: e.detail.value
    })
  },

  // 打开移交窗口
  opeanMobelBtn() {
    this.setData({ mobelStu: 1 });
  },

  // 关闭移交窗口
  closeMobelBtn() {
    this.setData({ mobelStu: 0 });
    wx.reLaunch({
      url: '../index_message_list/index',
    })
  },

  // 确认到诊
  toDetailDiagonsis() {
    wx.navigateTo({
      url: '../index_message_detail_diagnosis/index',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})