// miniprogram/pages/user_register/index.js
const app = getApp();
let timer = null;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '医好康', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    isBtn: false,
    // 用户所填数据 
    registData: {
      companyId: wx.getStorageSync("companyId"),//  String	是	公司ID 
      phoneNum: '',	//	String	是	手机号码 17888211416
      phoCode: '',      // 验证码 
    },
    //  数据验证是否填写正确
    registEreg: {
      phoneNum: true,	 //	  String	是	手机号码
      phoCode: false   //   验证码是否填写正确
    },

    codeTime: -1,   // 验证码失效时间设置
    phoCodeApi: '', // 后台返回的验证码
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   *  获取界面手机号
   */
  phoneNumBlur(e){
    this.setData({['registData.phoneNum']: e.detail.value})
    if (this.data.registData.phoneNum !== '' && this.data.registData.phoneNum.length === 11) {
      this.setData({ ['registEreg.phoneNum']: true });
    } else {
      this.setData({ ['registEreg.phoneNum']: false });
    }
  },

  // 验证码失去焦点
  phoCodeBlur(e) {
    let phoCard = e.detail.value;
    this.setData({ ['registData.phoCode']: phoCard })
    if (this.data.phoCodeApi === '' || this.data.codeTime == -1) {
      showToastWay('请获取验证码');
    } else {
      if (this.data.registData.phoCode === this.data.phoCodeApi) {
        this.setData({ ['registEreg.phoCode']: true });
      } else {
        showToastWay('输入正确验证码');
        this.setData({ ['registEreg.phoCode']: false });
      }
    }
  },

  // 发送验证验证码 按钮
  getPhoCodeWay() {
    var time = 60,
    that = this;
    // 验证手机号
    if (!phoneRegWay(that.data.registData.phoneNum)) {
      return;
    }
    // 验证码发送
    app.agriknow2.getSendApi({ mobile: that.data.registData.phoneNum }).then(res => {
      if(res.code==0){
        that.setData({ phoCodeApi: res.content });
      }else{
        showToastWay('系统繁忙，请稍后再试')
      }
    }).catch(err => { // 数据请求失败;
      showToastWay('获取验证码失败')
    });
    that.setData({ codeTime: time });
    timer = setInterval(function () {
      time --;
      that.setData({ codeTime: time });
      if (time <= 0) {
        that.setData({ codeTime: -1 });
        clearTimeout(timer);
      }
    }, 1000);
  },

  /**
   * 提交事件
   */
  registinfoWay:function(){
    let that  = this;
    // 验证手机号
    if(!phoneRegWay(that.data.registData.phoneNum)){
      return;
    }
    if (that.data.registEreg.phoCode){
      showLoading();
      wx.login({
        success: function (res) {

          let data = {
            companyId: wx.getStorageSync("companyId"),
            code: res.code,
            mobile: that.data.registData.phoneNum,
            messageCode: that.data.registData.phoCode,
          }
          app.agriknow2.getRegistSubmitApi(data).then(res => {
            cancelLoading();
            clearTimeout(timer);
            if(res.code==0){
              showToastWay('注册成功');
              wx.setStorage({ key: 'userPhone', data: that.data.registData.phoneNum})
              
              wx.switchTab({ url: '../user-detail/userdetail' }); // 跳转到首页
            }else{
              showToastWay('注册失败');
            }
          });
        }
      })
    }else{
      showToastWay("请输入或获取正确的验证码")
    }
  
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
    }
    return {
      title: '石城巴士小程序',
      path: 'pages/i_sel_site/index1',
      success: function (res) {
        // 转发成功
      },
      fail: function (res) {
        // 转发失败
      }
    }
  }
})

/**
 * 提示框
 */
function showToastWay(msg){
  wx.showToast({
    title: msg,
    icon: 'none',
    duration: 1500
  })
}

/**
*  加载等待提示框
*/
function showLoading(msg) {
  wx.showToast({
    title: '加载中',
    icon: 'loading'
  });
}
/**
*  取消等待提示框
*/
function cancelLoading() {
  wx.hideToast();
}

/**
*  手机号码验证
*/
function phoneRegWay(phone){
  if (phone==null||phone==''){
    showToastWay('请输入手机号')
    return false;
  }
  var phoneReg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
  if (!phoneReg.test(phone)) {
    showToastWay('手机号有误！')
    return false;
  }
  return true;
}