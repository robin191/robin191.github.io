// pages/message_list/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

    // 组件所需的参数
    nvabarData: {
      showCapsule: 0, //是否显示左上角图标   1表示显示    0表示不显示
      title: '项目', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    nowPage: 1,
    hasData: -1, // -1 初始化   1 有数据  0 无数据
    isLoading: 1, // -1 初始化   1 加载    0 隐藏

    projectStatu: 0, // 1 有项目  -1 无项目   -2 项目首页-用户  
    array1: ['全部项目', '进行中项目', '已关闭项目', '已退出项目'],
    index1: 0,

    dateTime: "项目时间",

    lineTypeList: [{
        typeName: '全部项目',
        idx: '1',
        typeNo: '1'
      }, {
        typeName: '全部地点',
        idx: '2',
        typeNo: '2'
      },
      {
        typeName: '项目时间',
        idx: '3',
        typeNo: '3'
      }
    ], // 公交线路类型
    proList: [],

    addressListOld: [], // 原始数据
    addressListNew: ['全部地点'], // 页面绑定数据
    addressIndx: 0, // 选中地址下表
    addressVal: '', // 所选中的地址值
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      noshow: wx.getStorageSync('noshow')
    })
    // let dates = new Date();
    // let month = parseInt(dates.getMonth() + 1) + ''
    // let nowDate = dates.getFullYear() + '-' + (month > 9 ? month : ('0' + month)) + '-' + (dates.getDate() > 9 ? dates.getDate() : ('0' + dates.getDate()))
    // this.setData({ dateTime: nowDate });
  },


  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.getAddress(); // 地址列表
    this.proListOne(); // 项目列表
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    // 显示顶部刷新图标  
    wx.showNavigationBarLoading();
    this.proListOne('pull');
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    if (this.data.hasData == 1) {
      this.proList(); // 获取信息列表
    }
  },

  // 第一次加载
  proListOne(type) {
    if (wx.getStorageSync('noRole')) {
      this.setData({
        projectStatu: -2,
      });
    } else {
      this.setData({
        nowPage: 1
      });
      let that = this;
      that.setData({
        isLoading: 1
      });
      let cityd = undefined;
      let addressListOld = that.data.addressListOld;
      let addressListNew = that.data.addressListNew;

      if (that.data.addressIndx !== 0) {
        for (var item in addressListOld) {
          if (addressListOld[item].addrName === addressListNew[that.data.addressIndx]) {
            cityd = addressListOld[item].addrCode
          }
        }
      }

      let params = {
        "page": that.data.nowPage + '',
        "limit": "10",
        // "hospitalCode": wx.getStorageSync('hosCode'),//医院编码 必传

        "city": cityd, //地点查询条件（城市编码） 非必传
        "projectState": parseInt(that.data.index1) //全部项目下拉框 0：全部项目 1：进行中项目 2：已关闭项目 3：已退出项目
      };
      if (that.data.dateTime != '项目时间') {
        params.createTime = that.data.dateTime
      }
      app.agriknow2.queryMyProject(params, 'noloading').then(res => {
        that.setData({
          isLoading: 0
        })
        if (type === 'pull') {
          // 隐藏导航栏加载框  
          wx.hideNavigationBarLoading();
          // 停止下拉动作  
          wx.stopPullDownRefresh();
        }
        if (res.code === 0) {
          let data = res.page.list;
          for (var item in data) {
            let time = data[item].createTime ? data[item].createTime.substring(5, 7) : data[item].createTime;
            data[item].data = time;
          }

          if (data.length >= 1) {
            that.setData({
              projectStatu: 1,
            });
          } else {
            that.setData({
              projectStatu: -1,
            });
          }

          if (data.length >= 10) {
            that.setData({
              hasData: 1
            });
          } else {
            that.setData({
              hasData: -1,
              nowPage: that.data.nowPage + 1
            });
          }


          for (var item in data) {
            let time = data[item].createTime ? data[item].createTime.substring(5, 7) : data[item].createTime;
            data[item].data1 = time;

          }
          that.setData({
            proList: data
          })
        }
      })
    }

  },


  // 项目列表
  proList() {
    var that = this;
    let cityd = undefined;
    that.setData({
      isLoading: 1
    })
    let addressListOld = that.data.addressListOld;
    let addressListNew = that.data.addressListNew;

    if (that.data.addressIndx !== 0) {
      for (var item in addressListOld) {
        if (addressListOld[item].addrName === addressListNew[that.data.addressIndx]) {
          cityd = addressListOld[item].addrCode
        }
      }
    }

    let params = {
      "page": that.data.nowPage + '',
      "limit": "10",
      "hospitalCode": wx.getStorageSync('hosCode'), //医院编码 必传
      // "createTime": that.data.dateTime,//时间搜索条件 非必传
      "city": cityd, //地点查询条件（城市编码） 非必传
      "projectState": parseInt(that.data.index1) //全部项目下拉框 0：全部项目 1：进行中项目 2：已关闭项目 3：已退出项目
    };
    if (that.data.dateTime != '项目时间') {
      params.createTime = that.data.dateTime
    }
    app.agriknow2.queryMyProject(params).then(res => {
      that.setData({
        isLoading: 0
      })
      let data = res.page.list;
      if (data.length > 0) {
        that.setData({
          hasData: 1,
          nowPage: parseInt(that.data.nowPage) + 1,
        });
      } else {
        that.setData({
          hasData: 0,
        });
      }

      for (var item in data) {
        let time = data[item].createTime ? data[item].createTime.substring(5, 7) : data[item].createTime;
        data[item].data = time;
      }
      that.setData({
        proList: that.data.proList.concat(data)
      })

    })
  },


  // 获取项目地点
  getAddress() {
    let that = this;
    let params = {
      page: "1",
      limit: "30"
    };
    app.agriknow2.queryMyProjectRegionList(params).then(res => {
      if (res.code === 0) {
        let data = res.page.list;
        let newArr = ['全部地点'];
        for (var item in data) {
          newArr.push(data[item].addrName);
        }
        that.setData({
          addressVal: data[0].data,
          addressListOld: data,
          addressListNew: newArr
        });
      }
    })
  },

  // 时间选择
  bindDateChange: function(e) {
    this.setData({
      dateTime: e.detail.value
    });
    this.proListOne();
  },

  // 确定取消方法
  bindcancel(e) {
    this.setData({
      dateTime: '项目时间'
    });
    this.proListOne();
  },

  // 地址选择
  addressChange(e) {
    let idx = e.detail.value;
    this.setData({
      addressIndx: e.detail.value
    })
    let selVal = this.data.addressListNew[idx];
    for (var item in this.data.addressListOld) {
      if (this.data.addressListOld[item].addrName === selVal) {
        this.setData({
          addressVal: this.data.addressListOld[item].addrCode
        });
      }
    }
    this.proListOne();

  },




  // 查看详情
  checkDetail(e) {
    // e.target.dataset
    let code = e.currentTarget.dataset.projectCode;
    console.log('开始查看详情-----', code)
    app.projectCode = code;
    wx.navigateTo({
      url: '../project_list_detail/index',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },

  // 添加项目
  addProjectBtn() {
    wx.navigateTo({
      url: '../project_add/index',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },

  bindPickerChange1(e) {
    this.setData({
      index1: e.detail.value
    })
  },

  bindPickerChange2(e) {
    this.setData({
      index1: e.detail.value
    })
    this.proListOne();
  },

  bindTimeChange(e) {
    this.setData({
      time: e.detail.value
    })
    this.proListOne();
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },



  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})