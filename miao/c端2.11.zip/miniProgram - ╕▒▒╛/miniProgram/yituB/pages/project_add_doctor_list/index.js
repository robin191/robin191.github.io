// miniprogram/pages/login-user/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '医好康', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    isSelType:0, // 选择一个
    doctorList:[
    ],
    isSelDoctor:[],// 所选择的
    array1: ['全部项目', '项目1', '项目3', '项目4'],
    index1: 0,
    hispitalInfo:{},

    selGuanli:[], // 已选择的管理者
    selDoc:[], // 已选择的医生团队

    isAdd:1,
    
     remarkName: '',
    keshiList: ['全部科室'], // 科室列表
    keshiOldList: [], // 科室列表
    keshiIdx: 0, // 科室列表
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    this.setData({ isSelType: options.type})  ;
    console.log('load',this.data.isSelType, this.data.isSelType === 0)
    if (this.data.isSelType === 0){
      this.setData({ selGuanli: app.createProInfo.selGuanli})
    }else{
      this.setData({ selDoc: app.createProInfo.selDoc })
    }

    this.setData({ hispitalInfo: app.createProInfo.selHospitalInfo }); // 医院数据
    this.queryDoctorByHospitalById(app.createProInfo.selGuanli, app.createProInfo.selDoc);// 医生列表
    this.getDepartmentVosByHospitalCode(); // 科室列表 
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  // 科室列表
  getDepartmentVosByHospitalCode() {
    var that = this;
    app.agriknow2.hospitaldepartmentLists({
      "hospitalCode": that.data.hispitalInfo.code || app.createProInfo.selHospitalInfo.hospitalCode,//医院编码
      
      }).then(res => {
      if (res.code === 0) {
        let data = res.page.list;
        let arr = [];
        for (var item in data) {
          arr.push(data[item].departmentName || '暂无数据');
        }
        that.setData({ keshiList: that.data.keshiList.concat(arr), keshiOldList: data });
      }
    })
  },

  // 搜索输入
  remarkNameInput(e) {
    this.setData({
      remarkName: e.detail.value
    })
    
  },


  keshiChange(e) {
    this.setData({
      keshiIdx: e.detail.value
    })
    this.queryDoctorByHospitalById();
  },

  // 医生列表
  queryDoctorByHospitalById(selGuanli, selDoc) {
    var that = this;

    let noDoc = []; // 不可被选的医生  如果为 0 去除普通医生， 如果为1去除管理员医生
    if (that.data.isSelType == 1) { // 普通医生   0 管理者 1 普通医生成员
      noDoc = selGuanli;
    } else { // 管理者医生
      noDoc = selDoc;
    }

    let isSel = []; // 已选中的医生
    if (that.data.isSelType == 0) { // 普通医生  如果已选择过   0 管理者被选中  1 普通医生成员被选中
      isSel = selGuanli;
    } else { // 管理者医生
      isSel = selDoc;
    }

    let code = undefined;
    if (that.data.keshiIdx >= 1) {
      let old = that.data.keshiOldList;
      for (var item in old) {
        if (old[item].departmentName === that.data.keshiList[that.data.keshiIdx]) {
          code = old[item].departmentCode
        }
      }
    }
    let params = {
      
      "hospitalCode": that.data.hispitalInfo.code || app.createProInfo.selHospitalInfo.hospitalCode,//医院编码必传
      "departmentCode": code,//科室编码 非必传
      "remarkName": that.data.remarkName//医生备注名 非必传
    }
    app.agriknow2.addHospitalDoctorList(params).then(res => {
      let data = res.page.list;
      let newDoc = []; // 从医生列表中去除已选过的医生
      // 去除 已被对立面选中过的医生
      for (var item in data){
        let blg = true;
        for (var i2 in noDoc){ // 不可被选的医生
          if (data[item].doctorCode === noDoc[i2].doctorCode){
            blg = false
          }
        }
        if(blg){
          data[item].stu = 0;
          newDoc.push(data[item])
        }
      }
      // 默认选中
      let newData2 = [];
      for (var item in newDoc) { // 不可被选的医生
        let blg = false;
        for (var i2 in isSel){
          if (newDoc[item].doctorCode === isSel[i2].doctorCode) {
            blg = true;
          }
        }
        newDoc[item].stu = blg ? 1 : 0
        newData2.push(newDoc[item])
        
      }
      that.setData({ doctorList: newData2 })
    })
  },

  // 选择医生列表
  selBtn(e){
    
    let index = e.currentTarget.dataset.idx
    let doctorList = this.data.doctorList;
    if (this.data.isSelType == 1){ // 选择多个
      doctorList[index].stu = doctorList[index].stu ? 0 : 1;
    }else{ // 选择一个
      for (var item in doctorList){
        doctorList[item].stu = 0;
      }
      doctorList[index].stu = 1;
    }
    
    this.setData({ doctorList: doctorList});
    console.log(this.data.doctorList)
    let isSelDoctor = [];
    for (var item in doctorList){
      if (doctorList[item].stu === 1){
        isSelDoctor.push(doctorList[item]); 
      }
    }

    this.setData({ isSelDoctor: isSelDoctor});
    
  },

  // 确定
  addBtn(){
    if (this.data.isSelType == 33) { // 医生详情，进行添加成员
      this.addMembersPro();
    }else{
      if (this.data.isSelType == 1) { // 普通医生
        app.createProInfo.selDoc = this.data.isSelDoctor;
        wx.navigateBack({ delta: 1 })
      } else { // 管理者医生
        app.createProInfo.selGuanli = this.data.isSelDoctor;
        wx.navigateBack({ delta: 1 })
      }
    }
  },

  // 项目详情中， 将为选中成员加到医生列表
  addMembersPro() {
    let that = this;
    let isSelDoctor = that.data.isSelDoctor;
    let params = [];
    for (var item in isSelDoctor){
      params.push({
        "doctorCode": isSelDoctor[item].doctorCode,
        "projectCode": app.projectCode
      })
    }
    app.agriknow2.addMembersPro(params).then(res => {
      if (res.code === 0) {
        wx.showToast({
          title: '添加成功',
          icon: 'success',
          duration: 2000
        })
        wx.navigateBack({ delta: 1 })
      }
    })
  },



  bindPickerChange1(e) {
    this.setData({
      index1: e.detail.value
    })
 },

  // 删除输入关键字
  clearBtn() {
    this.setData({ remarkName: '' });
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})