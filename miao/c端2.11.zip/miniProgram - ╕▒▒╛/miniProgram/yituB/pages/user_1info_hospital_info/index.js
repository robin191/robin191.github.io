// miniprogram/pages/user_1info_hospital/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '我的医院', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    longitude: '120.123218',
    latitude: '30.263964',
    markers: [{
      id: 0,
      iconPath: "../../images/start.png",
      latitude: 23.099994,
      longitude: 113.324520,
      width: 50,
      height: 50
    }],

    tabList: [{
        name: '医院信息',
        val: 0
      },
      {
        name: '项目清单',
        val: 1
      },
    ], // tab选项
    tabIndex: 0,

    proList: [{
      name: '项目名称1'
    }, {
      name: '项目名称1'
    }, {
      name: '项目名称1'
    }, ],


    hospitalCode: 'YY002',
    hospitalInfo: {}, // 项目详情
    proList: [], // 项目清单
  },
  toGuide(){
    wx.openLocation({
      latitude: this.data.latitude,
      longitude: this.data.longitude,
      scale: 18,
      name: '',
      address: this.data.hospitalInfo.address
    })  
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let hospitalCode = options.hospitalCode;
    if (hospitalCode) {
      this.setData({
        hospitalCode: hospitalCode
      })
    }
    this.getHospitalDetailApi();
    this.queryMyProjectApi();


  },

  // 退出医院
  signOut() {
    let that = this
    wx.showModal({
      title: '提示',
      content: '确定退出该机构吗？',
      success: function(r) {
        if (r.confirm) {
          app.agriknow2.quitHospital({
            code: that.data.hospitalCode
          }).then(res => {
            if (res.code == 0) {
              console.log(res)
              wx.showToast({
                title: '退出成功',
                icon: 'none'
              })
              setTimeout(function() {
                wx.navigateBack({

                })
              }, 1500)
            } else {
              wx.showToast({
                title: res.msg,
                icon: 'none'
              })
            }
          })
        }
      }
    })
  },


  // 我的-我的医院-医院信息 api
  getHospitalDetailApi() {
    let that = this;
    let params = {
      hospitalCode: that.data.hospitalCode
    };
    app.agriknow2.getHospitalDetailHo(params).then(res => {
      if (res.code === 0) {
        that.setData({
          hospitalInfo: res.hospitalDetail
        });

        if (!that.data.hospitalInfo.latNum && !that.data.hospitalInfo.lngNum) {
          wx.getLocation({
            type: "wgs84",
            success: function(res) {
              var latitude = res.latitude;
              var longitude = res.longitude;
              that.setData({
                latitude: res.latitude,
                longitude: res.longitude,
                markers: [{
                  latitude: res.latitude,
                  longitude: res.longitude
                }]
              })
            }
          })
        } else {
          that.setData({
            latitude: that.data.hospitalInfo.latNum,
            longitude: that.data.hospitalInfo.lngNum,
            markers: [{
              latitude: that.data.hospitalInfo.latNum,
              longitude: that.data.hospitalInfo.lngNum
            }]
          })
        }


      }
    })
  },

  // 我的-我的医院-项目清单 api
  queryMyProjectApi() {
    let that = this;
    let params = {
      hospitalCode: that.data.hospitalCode,
      "page": "1",
      "limit": "100",
    };
    app.agriknow2.queryMyProjectHo(params).then(res => {
      if (res.code === 0) {
        that.setData({
          proList: res.page.list
        });
      }
    })
  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  // 标题选择
  selTypeLine(e) {
    this.setData({
      tabIndex: e.currentTarget.dataset.idx
    });
  },

  // 去项目详情
  toProDetailBtn(e) {
    let code = e.currentTarget.dataset.projectCode;
    app.projectCode = code;
    wx.navigateTo({
      url: '../project_list_detail/index',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})