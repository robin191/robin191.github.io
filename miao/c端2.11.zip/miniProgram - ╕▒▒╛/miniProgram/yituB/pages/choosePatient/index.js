// pages/choosePatient/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '选择患者', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    array1: ['全部病患', '推荐中病患', '已就诊病患'],
    index1: 0,
    array2: [{
      addrName: '全部地区'
    }],
    index2: 0,
    array3: ['当前页全选', '全不选'],
    index3: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },
  bindPickerChange1(e) {
    this.setData({
      index1: e.detail.value
    })
    if(app.globalData.mysend){
      this.queryDoctorSendmessagePatients()
    }else{
      this.getHuanzheList()
    }
   
  },
  bindPickerChange2(e) {
    this.setData({
      index2: e.detail.value
    })
    if (app.globalData.mysend) {
      this.queryDoctorSendmessagePatients()
    } else {
      this.getHuanzheList()
    }
  },
  bindPickerChange3(e) {
    
    let huanzhelist = this.data.huanzhelist
    if(e.detail.value==0){
      for(var i in huanzhelist){
        huanzhelist[i].choose = !0
      }
    }else{
      for (var i in huanzhelist) {
        huanzhelist[i].choose = !1
      }
    }
    this.setData({
      index3: e.detail.value,
      huanzhelist: huanzhelist
    })

  },
  confirmChoose(){
    let t = 0,arr = []
    let huanzhelist = this.data.huanzhelist
    for (var i in huanzhelist) {
      if(huanzhelist[i].choose){
        t++
        arr.push(huanzhelist[i].openId)
      }
    }
    wx.setStorageSync('choosePatient', {
      num:t,
      ids:arr
    })
    wx.navigateBack({
      
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
  
    console.log(app.globalData.mysend)
    if (app.globalData.mysend){
      this.queryDoctorSendmessagePatients()
      this.queryMyselfPatientRegionList()
    }else{
      this.getHuanzheList()
      this.getAreaList()
    }
  },

  queryDoctorSendmessagePatients(){
    let that = this
    app.agriknow2.queryDoctorSendmessagePatients({
      "patientType": parseInt(this.data.index1) + 1,//患者类型 1：全部病患 2：推荐中病患 3：已就诊病患
      "levelType": this.data.array2[this.data.index2].levelType,//地区级别 1：省 2：市
      "areaCode": this.data.array2[this.data.index2].addrCode//地区编码
    }).then(res=>{
      if (res.code == 0) {
        for (var i in res.page.list) {
          res.page.list[i].choose = !1
        }
        that.setData({
          huanzhelist: res.page.list
        })
      }
    })
  },

  queryMyselfPatientRegionList() {
    let that = this
    app.agriknow2.queryMyselfPatientRegionList({
      "page": "1",
      "limit": "100"
    }).then(res => {
      console.log(res)
      if (res.code == 0) {
        that.setData({
          array2: that.data.array2.concat(res.page.list)
        })
      }
    })
  },



  getHuanzheList() {
    let that = this
    app.agriknow2.queryHospitalSendmessagePatients({
      "patientType": parseInt(this.data.index1) + 1,
      "levelType": this.data.array2[this.data.index2].levelType,
      "areaCode": this.data.array2[this.data.index2].addrCode
    }).then(res => {
      console.log(res)
      if (res.code == 0) {
        for (var i in res.page.list) {
          res.page.list[i].choose = !1
        }
        that.setData({
          huanzhelist: res.page.list
        })
      }
    })
  },
  getAreaList() {
    let that = this
    app.agriknow2.queryMyPatientRegionList({
      "page": "1",
      "limit": "100"
    }).then(res => {
      console.log(res)
      if (res.code == 0) {
       
        that.setData({
          array2: that.data.array2.concat(res.page.list)
        })
      }
    })
  },

  chooseHuan(e){
    let huanzhelist = this.data.huanzhelist,index=e.currentTarget.dataset.index
    huanzhelist[index].choose = !huanzhelist[index].choose
    this.setData({
      huanzhelist: huanzhelist
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})