// miniprogram/pages/user_1info_hospital/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '科室', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    keshiList: ['全部科室', '科室1'],
    keshiOld: [], // 科室类型原始数据
    keshiIdx: 0,

    hospital1: [
    ],
    hospital2: [],

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },
  keyword(e){
    this.setData({
      keyword:e.detail.value
    })
  },
  search(){
    this.keshiApi(this.data.keshiList[this.data.keshiIdx],this.data.keyword)
  },
  clearKeyword(){
    this.setData({
      keyword:''
    })
  },
  selBtn(e){
    let index = e.currentTarget.dataset.index
    let idx = e.currentTarget.dataset.idx
    console.log(e,index,idx)
    wx.navigateTo({
      url: '/pages/manage_keshi_edit/index?mes=' + JSON.stringify(this.data.hospital1[index].list[idx]),
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.keshiApi({}); // 科室列表
    this.keshiTypeApi(); // 科室类型
  },

  // 科室类型
  keshiTypeApi() {
    let that = this;
    app.agriknow2.queryDepartmentTypelist({
      "hospitalCode": wx.getStorageSync('hosCode') || 'YY0001'//医院编码
    }).then(res => {
      if (res.code === 0) {
        that.setData({
          keshiList: res.hospitalDepartmentTypes
        })
      }
    })
  },

  // 科室列表
  keshiApi(e,s) {
    let that = this;
    // let data = {
    //   "departmentName": "口腔",//科室名称 非必填
    //   "departmentType": 1//科室类型编码 非必填
    // }
    app.agriknow2.getDepartmentVosByHospitalCode({
      departmentName: s,
      departmentType: e.departmentType == 0 ? '' : e.departmentType
    }).then(res => {
      console.log(res)
      if (res.code === 0) {
        var list = res.hospitalDepartmentList,arr = [],cc=[]
        for(let i in list){  //获取科室分类长度
          if (cc.indexOf(list[i].departmentType) < 0){
            console.log(cc.indexOf(list[i].departmentType))
            cc.push(list[i].departmentType)
            arr.push({
              type: list[i].departmentType,
              name: list[i].departmentTypeName,
              list:[]
            })
            console.log(cc, arr)
          }
        }
       
        for(let i in arr){
          for(let j in list){
            if (list[j].departmentType == arr[i].type){
              arr[i].list.push(list[j])
            }
          }
        }
        console.log(arr)
        that.setData({
          hospital1 : arr
        })
      }else{
        wx.showToast({
          title: res.msg,
          icon:'none'
        })
      }
    })
  },

  // 科室选择
  bindPickerChange1(e) {
    console.log(this.data.keshiList[e.detail.value])
    this.setData({
      keshiIdx: e.detail.value
    })
    this.keshiApi(this.data.keshiList[e.detail.value], this.data.keyword)
  },


  returnBtn() {
    wx.navigateBack({ //返回
      delta: 1
    })
  },

  // 新增科室
  addProjectBtn() {
    wx.navigateTo({
      url: '../manage_keshi_add/index'
    }); // 患者信息
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})