// miniprogram/pages/project_list_detail_ memo_add/index.js
const app = getApp();
var uploadImage = require('../../utils/uploadFile.js');
var util = require('../../utils/util.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '事件详情', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    isBtn: false,
    nowPage: 1,
    hasData: -1, // -1 初始化   1 有数据  0 无数据
    isLoading: 1, // -1 初始化   1 加载    0 隐藏

    imgUrl: [],
    videoUrl: [],
    imgUrlGetApi: [], // 从后台获取到地址，保存到数据库
    imgUrlData: [], // 后台获取到的数据

    userInfo: {
      "eventCode": "",
      "patientName": "",
      "sex": 1,
      "idNumber": "",
      "birthday": "",
      "weight": "",
      "isAllergy": 1,
      "allergyDetail": "",
      "disease": "",
      "diseaseDetail": "",
      "versionNo": "",
      mobilePhone:'',
    },
    mobilePhoneStu:true,



    array1: [],
    index1: 0,

    sexArr: ['男', '女'],
    sexIdx: 0,

    guominArr: ['否', '是'],
    guominIdx: 0,

    userNameStu: true,//昵称
    idNumberStu: true,//身份证

    diseaseType: 0,
    userDetail: { yiyuan: { type: 0 }, zhensuo: {} },

    isShowKeshi: 1, // 1 显示  0 不显示



    zhenduan:'',
    guomin:'',
    detail:'',

    names:'',
    toastTitle: '',
    toastInfo: '',
    toastIsStu: false,

    saoNoUser:1, // 1 显示  0 隐藏
    mobelStu: 0,  // 输入手机号  1 弹  0 隐藏
    messageInfo:undefined,
    messageInfo2: {  },


    memoList: [],   // 移交与备注列表
    memoIndex:0,
    index2: 0,
    time: '请选择具体时间',

      // 项目移交
    removeProStu: 0, // 移交项目长弹框  1 弹  0 隐藏
    removeProStuMemo:0, // 添加备注

    eventCode: "YY000100170002", // YY00300020002 YY00200350004
    projectCode:'', // 项目code
    incidentDetail:{}, // 事件详情



    userList: [], // 成员
    teamList:[], //移交对象列表
    teamOldList:[], // 原始数据
    teamIdx:0, // 移交对象下标
    executorContent:'', // 移交 备注

    // 备注说明
    content:'',
    contentStu:true,

    imgUrl: [],
    videoUrl: [],
    imgUrlGetApi: [], // 从后台获取到地址，保存到数据库
    imgUrlData:[], // 后台获取到的数据
    isOperation: false, // 确认提交
    isShowBtn: false, //  移交

    huanzhe:{},
    noBtn:false, // 不可操作
    info: {},

    isMe:false,
    isCompletes:false
  },
  gomes(){
    app.globalData.gomes = !0
    wx.navigateBack({
      
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if(options){
      let info = JSON.parse(options.info);
      if (info.isExecutor == 1 && info.isComplete == 0) { // 可进行添加日程
        this.setData({ isOperation: true });
      }

      if (info.isExecutor == 1){
        this.setData({ isMe: true });
      }
      if (info.isComplete == 0) {
        this.setData({ isCompletes: true });
      }

      if (info.isExecutor == 1) { // 可进行添加日程
        this.setData({ isShowBtn: true });
      }
      this.setData({ info: info, eventCode: info.eventCode, projectCode: info.projectCode });
    }
    if (wx.getStorageSync('zhenduan')) {
      wx.removeStorageSync('zhenduan')
    }
    if (wx.getStorageSync('guomin')) {
      wx.removeStorageSync('guomin')
    }
    if (wx.getStorageSync('detail')) {
      wx.removeStorageSync('detail')
    }
    this.readMessage();
    this.getEventBaseInfo(); // 事件信息 详情
    this.queryPatientInfoByEvent(); // 患者详情
    this.queryFilesByEventCode();  // 详情图片列表
    this.queryIsRead(); // 团队成员
    this.eventremarksListOne();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  delImgBtn(e) {
    let idx = e.currentTarget.dataset.idx;
    let img = this.data.imgUrl;
    img.splice(idx, 1);
    this.setData({ imgUrl: img });

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

    if (wx.getStorageSync('zhenduan')) {
      this.setData({ ['userInfo.disease']: wx.getStorageSync('zhenduan') })
    }
    if (wx.getStorageSync('guomin')) {
      this.setData({ ['userInfo.allergyDetail']: wx.getStorageSync('guomin') })
    }
    if (wx.getStorageSync('detail')) {
      this.setData({ ['userInfo.diseaseDetail']: wx.getStorageSync('detail') })
    }

  },

  /**
  * 页面相关事件处理函数--监听用户下拉动作
  */
  onPullDownRefresh: function () {
    // 显示顶部刷新图标
    wx.showNavigationBarLoading();
    this.eventremarksListOne('pull');
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.hasData >= 1) {
      this.eventremarksList();
    }
  },

  // 备注与移交列表
  eventremarksListOne(type) {
    this.setData({ nowPage: 1 });
    let that = this;

    let params = { "page": that.data.nowPage + '', "limit": "10", "eventCode": that.data.eventCode, };
    app.agriknow2.eventremarksList(params).then(res => {

      if (res.code === 0) {
        let data = res.page.list;
        for (var item in data) {
          data[item].createTime = data[item].createTime ? data[item].createTime.substring(5, 16) : data[item].createTime;
        }
        if (data.length >= 10) {
          that.setData({ hasData: 1 });
          this.setData({ nowPage: parseInt(that.data.nowPage) + 1 })
        } else {
          that.setData({ hasData: -1 });
        }
        if (type === 'pull') {
          // 隐藏导航栏加载框
          wx.hideNavigationBarLoading();
          // 停止下拉动作
          wx.stopPullDownRefresh();
        }
        that.setData({ memoList: data});
      }
    })
  },

  // 备注与移交列表
  eventremarksList() {
    let that = this;
    let params = { "page": that.data.nowPage + '', "limit": "10", "eventCode": that.data.eventCode, };
    app.agriknow2.eventremarksList(params).then(res => {
      if (res.code === 0) {
        let data = res.page.list;
        for (var item in data) {
          data[item].createTime = data[item].createTime ? data[item].createTime.substring(5, 16) : data[item].createTime;
        }
        if (data.length >= 10) {
          this.setData({ nowPage: parseInt(that.data.nowPage) + 1 })
          that.setData({ hasData: 1 });
        } else {
          that.setData({ hasData: -1 });
        }
        that.setData({ memoList: that.data.memoList.concat(data) });
      }
    })
  },


  // 患者详情
  queryPatientInfoByEvent() {
    let that = this;
    let params = { "eventCode": that.data.eventCode, };
    app.agriknow2.queryPatientInfoByEvent(params).then(res => {
      if (res.code === 0) {

        that.setData({ userInfo: res.projectPatient, sexIdx: parseInt(res.projectPatient.sex)-1});
      }
    })
  },

  // 身份证
  idNumberBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name !== '' && name.length === 18) {
      that.setData({ idNumberStu: true })
    } else {
      that.setData({ idNumberStu: false })
    }
    that.setData({
      ['userInfo.idNumber']: name,
    })
  },

  // 手机号
 mobilePhoneBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name !== '' && name.length === 11) {
      that.setData({ mobilePhoneStu: true })
    } else {
      that.setData({ mobilePhoneStu: false })
    }
    that.setData({
      ['userInfo.mobilePhone']: name,
    })
  },

  // 姓名
  userNameBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name.length > 1) {
      that.setData({ userNameStu: true })
    } else {
      that.setData({ userNameStu: false })
    }
    that.setData({
      ['userInfo.patientName']: name,
    })
  },


  // 性别选择
  bindSexChange(e) {
    this.setData({
      sexIdx: e.detail.value
    })
  },
  previewImage: function (e) {
    wx.previewImage({
      current: e.currentTarget.id, // 当前显示图片的http链接
      urls: this.data.imgUrl // 需要预览的图片http链接列表
    })
  },

   // 过敏史
  bindGuominChange(e) {
    this.setData({
      guominIdx: e.detail.value,
    })
if(e.detail.value==0){
  this.setData({
    ['userInfo.allergyDetail']: ''
  })
}
   
  },

  //上传图片 从云服务取到地址
  updloadWay1: function () {
    let that = this;

    if (!that.data.userInfo.patientName || that.data.userInfo.patientName.length <= 1){
      wx.showToast({
        title: '请填写患者姓名',
        icon:'none'
      })
      return;
    }
    if (!phoneRegWay(that.data.userInfo.mobilePhone)) {
      return;
    }



    if (!phoneRegWay2(that.data.userInfo.idNumber)) {
      return;
    }
    if (that.data.guominIdx == 0){
      that.setData({ [' userInfo.allergyDetail']:''});
    }
    var nowTime = util.formatTime(new Date());
    let data = this.data.imgUrl;

    that.setData({ noBtn:true});
    let n = -1;
    if (data.length > 0){
      for (var item in data) {

        let typeArr = data[item].split('.');

        let type = typeArr[typeArr.length - 2] + '.' + typeArr[typeArr.length - 1];

        uploadImage(type, data[item], 'img/' + nowTime + '/',
          function (result) {
            n++;
            that.setData({ imgUrlGetApi: that.data.imgUrlGetApi.concat(result) })
            if (n == data.length - 1 && item == data.length - 1) {
              that.uploadImageTemplateWay(); // 保存到数据库
            }
          }, function (result) {
          }
        )
      }
    }else{
      that.uploadImageTemplateWay(); // 保存到数据库
    }

  },

  // 首页-事件提交-患者信息模板
  uploadImageTemplateWay() {
    var that = this;
    that.setData({
      ['userInfo.sex']: parseInt(that.data.sexIdx) + 1,
      ['userInfo.isAllergy']: parseInt(that.data.guominIdx),
      ['userInfo.eventCode']: that.data.eventCode
    })
    let fileInfos = [];
    let imgUrlGetApi = that.data.imgUrlGetApi;
    for (var item in imgUrlGetApi) {
      var namearr = imgUrlGetApi[item].split('/');
      var name = namearr[namearr.length - 1];
      let data = {
        "eventCode": that.data.eventCode,
        "fileName": name,
        "path": imgUrlGetApi[item],
        "projectCode": that.data.projectCode,
        "size": 30
      };
      fileInfos.push(data);
    }

    let params = {
      fileInfos: fileInfos,
      projectPatient: that.data.userInfo
    }

    console.log('提交数据--------------')

    app.agriknow2.commitPatientInfoWithFiles(params, 'noloading').then(res => {
      if (res.code === 0) {
        that.toastSetWay('', '提交成功', true);
        wx.navigateBack({
          data: 1
        })
      } else {
        that.toastSetWay('', '提交失败', true)
      }
    })
  },




  // 跳转输入内容
  disease(e) {
    this.setData({ diseaseType: e.currentTarget.dataset.type })
    wx.navigateTo({
      url: '/pages/manage_keshi_disease/index?type=' + e.currentTarget.dataset.type,
    })
  },

  // 详情图片列表
  queryFilesByEventCode() {
    let that = this;
    let params = { "eventCode": that.data.eventCode, };
    app.agriknow2.queryFilesByEventCode(params).then(res => {
      if (res.code === 0) {
        let data = res.fileInfoList;
        let arr = [];
        for(var item in data){
          arr.push(data[item].path);
        }
        that.setData({ imgUrlData: arr});
      }
    })
  },


  // 图片选择
  chooseImage: function (e) {
    var that = this;

    wx.chooseImage({
      count:9-that.data.imgUrl.length,
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        that.setData({
          imgUrl: that.data.imgUrl.concat(res.tempFilePaths)
        });
      }
    })
  },



 // 移交处理人列表
  queryProjectTeamsPro() {
    let that = this;
    that.opeanYiJiaoBtn(); // 打开移交窗口
    let params = { "eventCode": that.data.eventCode, };
    app.agriknow2.queryProjectTeamsPro(params).then(res => {
      if (res.code === 0) {
        let data = res.projectTeamList;
        let arr = [];
        for (var item in data){
          arr.push(data[item].remarkName || '暂无名称');
        }
        that.setData({ teamList: arr, teamOldList:data});
        // teamList: [], //移交对象列表
        //   teamOldList: [], // 原始数据
      }
    })
  },

  // 移交事件
  changeEventExecutor() {
    let that = this;
    let teamOldList = that.data.teamOldList;
    let executor = '';
    for (var item in teamOldList){
      if (teamOldList[item].remarkName == that.data.teamList[that.data.teamIdx]){
        executor = teamOldList[item].doctorCode
      }
    }
    let params = {
      "code": that.data.eventCode,//事件编码
      "content": that.data.executorContent,//备注内容
      "executor": executor//接收人编码
    };
    that.setData({ isBtn: true })
    app.agriknow2.changeEventExecutor(params).then(res => {
      that.setData({ isBtn: false })
      if (res.code === 0) {
        that.setData({ isOperation: false });
        wx.showToast({
          icon: 'none',
          title: '移交成功',
        })
        that.closeYiJiaoBtn();
        that.setData({ content:''})
        that.eventremarksListOne();
      }else{
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },

  // 事件信息 详情
  getEventBaseInfo() {
    let that = this;
    let params = { "code": that.data.eventCode, };
    app.agriknow2.getEventBaseInfo(params).then(res => {
      if (res.code === 0) {
        res.eventInfo.data1 = res.eventInfo.createTime ? res.eventInfo.createTime.substring(5, 7) : res.eventInfo.createTime;
        res.eventInfo.createTime = res.eventInfo.createTime ? res.eventInfo.createTime.substring(5, 16) : res.eventInfo.createTime
        if (res.eventInfo.executor == wx.getStorageSync('docCode')){
          that.setData({
            isExecutor:!0
          })
        }else{
          that.setData({
            isExecutor: !1
          })
        }
        that.setData({ incidentDetail: res.eventInfo, projectCode: res.eventInfo.projectCode });
      }
    })
  },

  // 项目进行已读
  readMessage() {
    let that = this;
    let params = {
      "messageId": that.data.info.messageId //消息ID 必填
    };
    app.agriknow2.readMessage(params).then(res => {
      if (res.code === 0) {
      }
    })
  },

  // 团队成员查看状态
  queryIsRead() {
    let that = this;
    let params = { "eventCode": that.data.eventCode, };
    app.agriknow2.queryIsRead(params).then(res => {
      if (res.code === 0) {
        that.setData({ userList: res.messageReceiverRelationVos});
      }
    })
  },


  // 添加备注
  addEventRemark() {
    let that = this;
    if (that.data.content.length < 3){
      wx.showToast({
        title: '请填写备注说明（至少3个字）',
        icon: 'none'
      })
      return;
    }
    let params = {
      "eventCode": that.data.eventCode,
      "content": that.data.content//备注内容 必填
    };
    that.setData({ isBtn: true })
    app.agriknow2.addEventRemark(params).then(res => {

      that.setData({ isBtn: false })
      if (res.code === 0) {

        wx.showToast({
          icon: 'none',
          title: '添加成功',
        })
        that.closeMemoBtn();
        that.setData({ content: '' })
        that.eventremarksListOne();
      }else{
        wx.showToast({
          icon: 'none',
          title: res.msg,
        })
      }
    })
  },

  /**
     *  移交备注信息验证
     */
  executorContentBlur(e) {
    var that = this;
    let executorContent = e ? e.detail.value : e;
    // if (content.length > 1 && content.length <= 15) {
    //   that.setData({ contentStu: true })
    // } else {
    //   that.setData({ contentStu: false })
    // }
    that.setData({
      executorContent: executorContent,
    })
  },

  /**
   *  备注信息验证
   */
  contentBlur(e) {
    var that = this;
    let content = e ? e.detail.value : e;
    if (content.length > 1 && content.length <= 15) {
      that.setData({ contentStu: true })
    } else {
      that.setData({ contentStu: false })
    }
    that.setData({
      content: content,
    })
  },





  // 图片放大
  previewImage: function (e) {
    wx.previewImage({
      current: e.currentTarget.id, // 当前显示图片的http链接
      urls: this.data.imgUrl // 需要预览的图片http链接列表
    })
  },

  // 移交人选择
  teamChange(e) {
    this.setData({
      teamIdx: e.detail.value
    })
  },


  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({ toastTitle: title, toastInfo: info, toastIsStu: stu });
    if (stu){
      var time = setInterval(function () {
        that.setData({ toastTitle: title, toastInfo: info, toastIsStu: false });
        clearInterval(time);
      }, 3000);
    }

  },


  sureBtn(){
        wx.navigateTo({ url: '../index_message_list/index' }); // 跳转到售票页面
  },

  // 打开移交窗口
  opeanYiJiaoBtn() {
    this.setData({ removeProStu: 1 });
  },

  // 关闭移交窗口
  closeYiJiaoBtn() {
    this.setData({ removeProStu: 0 });
  },

  // 打开备注窗口
  opeanMemoBtn() {
    this.setData({ removeProStuMemo: 1 });
  },

  // 关闭备注窗口
  closeMemoBtn() {
    this.setData({ removeProStuMemo: 0 });
  },

  // 新增事件
  addProjectBtn(){
    app.getProjectInfo = this.data.projectCode;
    wx.navigateTo({ url: '../project_add_incident/index' }); // 跳转到售票页面
  },

  // 时间选择
  bindTimeChange(e) {
    this.setData({
      time: e.detail.value
    })
  },

  // 打开移交窗口
  opeanMobelBtn() {
    this.setData({ mobelStu: 1 });
  },

  // 关闭移交窗口
  closeMobelBtn() {
    this.setData({ mobelStu: 0 });
    wx.reLaunch({
      url: '../index_message_list/index',
    })
  },

  // 确认到诊
  toDetailDiagonsis(){
    wx.navigateTo({
      url: '../index_message_detail_diagnosis/index',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})

/**
 * 提示框
 */
function showToastWay(msg) {
  wx.showToast({
    title: msg,
    icon: 'none',
    duration: 1500
  })
}



/**
*  身份证验证
*/
function phoneRegWay2(phone) {
  if (phone == null || phone == '') {
    showToastWay('请输入身份证号')
    return false;
  }
  var reg = /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/;

  if (!reg.test(phone)) {
    showToastWay('请输入有效身份证号！')
    return false;
  }
  return true;
}

/**
*  手机号码验证
*/
function phoneRegWay(phone) {
  if (phone == null || phone == '') {
    showToastWay('请输入手机号')
    return false;
  }
  var phoneReg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
  if (!phoneReg.test(phone)) {
    showToastWay('请输入有效手机号！')
    return false;
  }
  return true;
}
