// miniprogram/pages/project_list_detail_ memo_add/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '查看信息', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    saoNoUser: 1, // 1 显示  0 隐藏
    mobelStu: 0, // 输入手机号  1 弹  0 隐藏
    messageInfo: undefined,
    // messageInfo: { stu: '4', time: '9月', times: '09.10 14:00', tltle: '欢迎来到医好康', info: '欢迎您登录到医好康。外面专注于为医疗机构提供2B2C的SAAS系统服务，协助医疗机构进行专家资源管理、医疗服务过程管理、病患关系管理。如果您对产品有任何建议，可以到我的“意见反馈”中提交信息。谢谢'},
    messageInfo2: 1212,
    type: 1,

    datasInfo: {},
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

    let datas = JSON.parse(options.info)
    this.setData({
      datasInfo: datas
    })

    this.setData({
      type: datas.messageType
    });
    console.log(datas);

    datas.date1 = datas.createTime ? datas.createTime.substring(5, 7) : datas.createTime;

    if (this.data.type == 2) {
      this.setData({
        messageInfo: datas
      });
    } else {
      this.setData({
        messageInfo2: datas
      });
    }
    this.readMessage(datas);
    this.queryClientUserinfo()
  },
  queryClientUserinfo() {
    let that = this
    app.agriknow2.queryClientUserinfo({
      "openId": this.data.datasInfo.eventCode
    }).then(res => {
      console.log(res)
      that.setData({
        huanzhemes: res.clientUserinfo
      })
    })
  },
  // 删除
  delBtn() {

    let that = this;
    wx.showModal({
      title: '提示',
      content: '是否删除此消息吗？',
      success: function(res) {
        if (res.confirm) {
          let params = [that.data.datasInfo.messageId];
          app.agriknow2.deleteMyMessage(params).then(res => {
            if (res.code === 0) {
              wx.showToast({
                title: '删除成功',
                icon: 'none'
              })
              setTimeout(
                wx.navigateBack({
                  data: 1
                }), 3000)

            } else {
              wx.showToast({
                title: res.msg,
              })
            }
          })
        } else if (res.cancel) {
          wx.showToast({
            title: '您已取消',
            icon: 'none'
          })
        }
      }
    });


  },



  // 消息变为已读
  readMessage(datas) {
    let that = this;
    let params = {
      messageId: datas.messageId
    };
    app.agriknow2.readMessage(params).then(res => {
      if (res.code === 0) {}
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  // 打开移交窗口
  opeanMobelBtn() {
    this.setData({
      mobelStu: 1
    });
  },

  // 关闭移交窗口
  closeMobelBtn() {
    this.setData({
      mobelStu: 0
    });
  },
  setUserName(e) {
    this.setData({
      tel: e.detail.value
    })
  },
  confirmTel() {
    let tel = this.data.tel
    let myreg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/;
    if (!tel) {
      wx.showToast({
        title: '手机号为空',
        icon: 'none'
      })
      return false;
    }
    if (!myreg.test(tel)) {
      wx.showToast({
        title: '手机号格式不正确',
        icon: 'none'
      })
      return false;
    }
    app.globalData.hexiaoCode = null
    wx.navigateTo({
      url: '/pages/index_message_detail_diagnosis/index?tel=' + tel,
    })
  },
  // 确认到诊
  toDetailDiagonsis() {

    wx.scanCode({
      success(res) {
        console.log(res.result)
       
        if (res.errMsg == "scanCode:ok") {
          app.globalData.hexiaoCode = res.result
          wx.navigateTo({
            url: '../index_message_detail_diagnosis/index'
          })
        }

      }
    })
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})