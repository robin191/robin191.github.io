// miniprogram/pages/login-user/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '医好康', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    toastTitle: '',
    toastInfo: '',
    toastIsStu: false,

    isSelType: 0, // 选择一个
    doctorList: [],
    isSelDoctor: [],// 所选择的
    hispitalInfo: {

    },

    selGuanli: [], // 已选择的管理者
    selDoc: [], // 已选择的医生团队

    isAdd: 1,
    hospitalCode: wx.getStorageSync('hosCode'),
    remarkName: '',
    keshiList: ['全部科室'], // 科室列表
    keshiOldList: [], // 科室列表
    keshiIdx: 0, // 科室列表

    type :0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let isSel = [];
   if(options.type){
     isSel = JSON.parse(wx.getStorageSync('isSelDoctor'));
     this.setData({ type: 1, isSelDoctor: JSON.parse(wx.getStorageSync('isSelDoctor'))})
   }
    let hosCode = wx.getStorageSync('hosCode')
    this.setData({ hospitalCode: hosCode }); // 医院数据
    this.getDepartmentVosByHospitalCode(); // 科室列表 
    this.queryDoctorByHospitalById(isSel);// 医生列表
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },
  // 医生列表
  queryDoctorByHospitalById(isSelData) {
    var that = this;
    let code = undefined;
    if (that.data.keshiIdx >= 1) {
      let old = that.data.keshiOldList;
      for (var item in old) {
        if (old[item].departmentName === that.data.keshiList[that.data.keshiIdx]) {
          code = old[item].departmentCode
        }
      }
    }

    let params = {
      "departmentCode": code,//科室编码 非必传
      "remarkName": that.data.remarkName//医生备注名 非必传
    }
    app.agriknow2.myHospitalDoctorList(params).then(res => {
      if (res.code === 0) {
        let data = res.page.list;
        console.log('-------------', data)
        console.log('-------------', isSelData)
        for (var item in data) {
          for (var i in isSelData) {
            if (data[item].doctorCode == isSelData[i].doctorCode) {
              data[item].stu = 1;
            }
          }
        }
        console.log('最后在方法===========',data)
        that.setData({ doctorList: data })
      }
    })
  },

  // 科室列表
  getDepartmentVosByHospitalCode() {
    var that = this;
    app.agriknow2.getDepartmentVosByHospitalCode({}).then(res => {
      if (res.code === 0) {
        let data = res.hospitalDepartmentList;
        let arr = [];
        for (var item in data) {
          arr.push(data[item].departmentName);
        }
        that.setData({ keshiList: that.data.keshiList.concat(arr), keshiOldList: data });
      }
    })
  },

  // 搜索输入
  remarkNameInput(e) {
    this.setData({
      remarkName: e.detail.value
    })
  },

  keshiChange(e) {
    this.setData({
      keshiIdx: e.detail.value
    })
    this.queryDoctorByHospitalById();
  },

 



  // 选择医生列表
  selBtn(e) {

    let index = e.currentTarget.dataset.idx
    let doctorList = this.data.doctorList;
    doctorList[index].stu = doctorList[index].stu ? 0 : 1;

    this.setData({ doctorList: doctorList });
    let isSelDoctor = [];
    for (var item in doctorList) {
      if (doctorList[item].stu === 1) {
        isSelDoctor.push(doctorList[item]);
      }
    }

    this.setData({ isSelDoctor: isSelDoctor });

  },


  // 选择医生列表
  removeBtn(e){
    let index = e.currentTarget.dataset.idx;
  },

  // 去详情
  toDetail(e){
    let info = e.currentTarget.dataset.info;
    wx.navigateTo({
      url: '../manage_doctor_upd/index?info=' + JSON.stringify(info),
    })
  },

  // 确定
  addBtn(){
    wx.setStorageSync('isSelDoctor', JSON.stringify(this.data.isSelDoctor));
   wx.navigateBack({
     data:1
   })
  },

  bindPickerChange1(e) {
    this.setData({
      index1: e.detail.value
    })
 },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})