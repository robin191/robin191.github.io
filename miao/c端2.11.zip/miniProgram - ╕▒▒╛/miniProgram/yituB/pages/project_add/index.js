// miniprogram/pages/project_add/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '项目名称', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    status: 1, // 1 添加项目名称   2 创建团队   3 创建成功弹框提示   4 建立事件
    array1: [],
    index1: 0,

    proName: '', // 项目名称
    proNameStu: true,

    hosptitalInfo: {
      name: ''
    }, // 项目医院 {hosId:'', hosName:''}
    hosptitalInfoStu: true,

    selGuanli: [], // 管理者医生
    selDoc: [], // 普通医生
    huanzhe: [],
    selDocShowStu: 0, // 1 超出显示全部， 0 只显示2个

    toastTitle: '',
    toastInfo: '',
    toastIsStu: false,

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    app.createProInfo = {
      proInfo: {},
      huanzhe: [],
      selHospitalInfo: {},
      selGuanli: [],
      selDoc: []
    }

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.setData({
      hosptitalInfo: app.createProInfo.selHospitalInfo, // 医院
      selGuanli: app.createProInfo.selGuanli, // 管理者
      selDoc: app.createProInfo.selDoc, // 医生
      huanzhe: app.createProInfo.huanzhe, // 患者
    });

  },

  // 只显示2个成员
  showAll() {
    if (this.data.selDocShowStu == 1) {
      this.setData({
        selDocShowStu: 0
      })
    } else {
      this.setData({
        selDocShowStu: 1
      })
    }

  },

  // 添加项目
  createPro() {
    var that = this;
    let blg = false;

    // 医生循环
    let doc = that.data.selDoc;
    let team = [];
    for (var item in doc) {
      team.push({
        doctorCode: doc[item].doctorCode
      })
    }
    let doctorCode = undefined;
    for (var item in that.data.selGuanli) {
      doctorCode = {
        "doctorCode": that.data.selGuanli[item].doctorCode
      }
    }

    let params = {
      // 项目信息
      projectInfo: {
        cuserMobilePhone: that.data.huanzhe.length > 0 ? that.data.huanzhe[0].mobilePhone : null,
        cuserOpenId: that.data.huanzhe.length > 0 ? that.data.huanzhe[0].openId : null,
        hospitalCode: that.data.hosptitalInfo.code,
        name: app.createProInfo.proInfo.proName
      },
      projectTeams: team
    }
    // 管理者
    if (doctorCode) {
      params.projectAdmin = doctorCode
    }
    // 患者
    // if (that.data.huanzhe[0]){
    //   params.cuserMobilePhone = that.data.huanzhe[0].mobilePhone;
    //   params.cuserOpenId = that.data.huanzhe[0].openId
    // }

    console.log(JSON.stringify(params))

    app.agriknow2.createProject(params).then(res => {
      console.log(blg)
      if (res.code == 0) {
        blg = true;
        app.getProjectInfo = res.projectInfo; // 项目创建成功， 获取项目信息进行建立事件
        app.projectInfo = res.projectInfo;
        app.projectCode = res.projectInfo.code;

        // wx.setNavigationBarTitle({
        //   title: '新增项目'
        // })
        that.setData({
          status: that.data.status + 1,
          nvabarData: {
            showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
            title: '新增项目', //导航栏 中间的标题
          },
        });
      } else {
        that.toastSetWay('', res.msg, true);
      }

    })
  },



  /**
   *  项目名称 验证
   */
  proNameBlur(e) {
    var that = this;
    let proName = e ? e.detail.value : e;
    if (proName.length > 1 && proName.length <= 15) {
      that.setData({
        proNameStu: true
      })
    } else {
      // that.toastSetWay('', '请输入项目名称（不超过15个字符，支持中英文数字）', true);
      that.setData({
        proNameStu: false
      })
    }
    that.setData({
      proName: proName,
    })
  },

  proNameBlur2(e) {
    var that = this;
    let proName = e ? e.detail.value : e;
    if (proName.length > 1 && proName.length <= 15) {
      that.setData({
        proNameStu: true
      })
    } else {
      that.setData({
        proNameStu: false
      })
    }
    that.setData({
      proName: proName,
    })
  },

  /**
   *  医院名称 验证
   */
  hosptitalBlur() {
    if (this.data.hosptitalInfo.name) {
      this.setData({
        hosptitalInfoStu: true
      })
    } else {
      this.setData({
        hosptitalInfoStu: false
      })
    }
  },


  // 创建项目验证
  isOkAdd1() {
    let blg = true;
    if (!this.data.proNameStu) {
      blg = false;
      this.toastSetWay('', '请输入项目名称（不超过15个字符，支持中英文数字）', true);
    } else if (!this.data.hosptitalInfoStu) {
      this.toastSetWay('', '请选择医院', true);
      blg = false;
    }

    return blg;
  },

  // 下一步
  nextBtn() {

    if (this.data.status === 3) {
      // wx.setNavigationBarTitle({
      //   title: '项目创建成功'
      // });
      app.createProInfo = {
        proInfo: {},
        huanzhe: [],
        selHospitalInfo: {},
        selGuanli: [],
        selDoc: []
      }
      this.setData({
        status: this.data.status + 1,
        nvabarData: {
          showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
          title: '项目创建成功', //导航栏 中间的标题
        },
      });

    } else if (this.data.status == 2) {
      // if (this.data.selGuanli.length <= 0 ){
      //   this.toastSetWay('','请选择项目管理者',true);
      //   return
      // }
      // if ( this.data.selDoc.length <= 0 ){
      //   this.toastSetWay('', '请选择项目成员', true);
      //   return;
      // }
      // if (this.data.huanzhe.length <= 0) {
      //   this.toastSetWay('', '请添加患者', true);
      //   return;
      // }
  
      this.createPro()


    } else if (this.data.status == 1) { // 项目创建
      this.proNameBlur({
        detail: {
          value: this.data.proName
        }
      }); // 项目名称 验证
      this.hosptitalBlur(); // 医院名称 验证
      if (!this.isOkAdd1()) return // 验证都不通过就断
      app.createProInfo.proInfo.proName = this.data.proName;
      // wx.setNavigationBarTitle({
      //   title: '项目名称'
      // })
      this.setData({
        status: this.data.status + 1,
        nvabarData: {
          showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
          title: '项目名称', //导航栏 中间的标题
        },
      });

    } else if (this.data.status == 4) {
      // wx.setNavigationBarTitle({
      //   title: '建立事件'
      // })
      this.setData({
        status: this.data.status + 1,
        nvabarData: {
          showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
          title: '建立事件', //导航栏 中间的标题
        },
      });

    }
   
  },


  // 选择医院
  selHospitalBtn() {
    wx.navigateTo({
      url: '../project_add_hospital_list/index'
    }); // 选择医院
  },

  // 建立事件
  addIncidentBtn() {
    wx.navigateTo({
      url: '../project_add_incident/index'
    }); // 建立事件
  },

  // 选择项目管理者
  selDoctorBtn() {
    wx.navigateTo({
      url: '../project_add_doctor_list/index?type=0'
    }); // 选择主管医生
  },

  // 选择医生
  selDoctorBtn1() {
    wx.navigateTo({
      url: '../project_add_doctor_list/index?type=1'
    }); // 选择医生
  },

  // 选择患者
  selUserBtn1() {
    wx.navigateTo({
      url: '../project_add_user_list/index'
    }); // 选择患者
  },


  // 添加事件
  addProjectBtn() {
    this.setData({
      status: 4,
      nvabarData: {
        showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
        title: '建立事件', //导航栏 中间的标题
      },
    });

    // wx.setNavigationBarTitle({
    //   title: '建立事件' //页面标题为路由参数
    // })
  },

  // 等等再说
  clearProjectBtn() {
    this.setData({
      status: 2,
      nvabarData: {
        showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
        title: '新增项目', //导航栏 中间的标题
      },
    });
    // wx.setNavigationBarTitle({
    //   title: '新增项目' //页面标题为路由参数
    // });
    wx.navigateBack({
      data: 1
    })
  },

  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({
      toastTitle: title,
      toastInfo: info,
      toastIsStu: true
    });
    var time = setInterval(function() {
      that.setData({
        toastTitle: title,
        toastInfo: info,
        toastIsStu: false
      });
      clearInterval(time);
    }, 3000);
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})