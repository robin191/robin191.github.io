// pages/manage_keshi_disease/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '擅长疾病', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    type:1,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if(options){
      this.setData({
        disease: options.con
      })
      if (options.type){
        this.setData({ type: options.type})
        if (options.type == 2){
          // wx.setNavigationBarTitle({ title: '个人简介' })
          this.setData({
            nvabarData: {
              showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
              title: '个人简介', //导航栏 中间的标题
            },
          })

        } else if (options.type == 3) {
          // wx.setNavigationBarTitle({ title: '医院简介' })
          this.setData({
            nvabarData: {
              showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
              title: '个人简介', //导航栏 中间的标题
            },
          })
        } else if (options.type == 'guomin') {
          // wx.setNavigationBarTitle({ title: '过敏信息' })
          this.setData({
            nvabarData: {
              showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
              title: '过敏信息', //导航栏 中间的标题
            },
          })
        } else if (options.type == 'zhenduan') {
          // wx.setNavigationBarTitle({ title: '诊断描述' })
          this.setData({
            nvabarData: {
              showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
              title: '诊断描述', //导航栏 中间的标题
            },
          })
        } else if (options.type == 'detail') {
          // wx.setNavigationBarTitle({ title: '病情详情' })
          this.setData({
            nvabarData: {
              showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
              title: '病情详情', //导航栏 中间的标题
            },
          })
        } 
      }
    }
  },
  disease(e){
    this.setData({
      disease:e.detail.value
    })
  },
  save(){
    
    console.log('过敏---------', this.data.type, this.data.disease)
    if (this.data.type == 'guomin') {
     
      wx.setStorageSync('guomin', this.data.disease)
    } else if (this.data.type == 'zhenduan') {
      wx.setStorageSync('zhenduan', this.data.disease)
    } else if (this.data.type == 'detail') {
      wx.setStorageSync('detail', this.data.disease)
    }else{
      wx.setStorageSync('disease', this.data.disease)
    }

    

    wx.navigateBack({data:1})
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})