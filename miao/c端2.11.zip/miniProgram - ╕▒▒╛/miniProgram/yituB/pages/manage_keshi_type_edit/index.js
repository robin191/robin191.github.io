// miniprogram/pages/user_1info_hospital/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {


    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '科室类型删除', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  deleteSeries(e){
    let that =this
    wx.showModal({
      title: '提示',
      content: '确定要删除此科室类型吗？',
      success(re){
        if(re.confirm){
          let index = e.currentTarget.dataset.index
          console.log(index, that.data.doctorList[index].departmentType)
          let data = {
            departmentType: that.data.doctorList[index].departmentType,//科室类型编码 必填
            hospitalCode: wx.getStorageSync('hosCode')//医院编码 必填
          }
          app.agriknow2.deleteDepartmentType(data).then(res => {
            if (res.code == 0) {
              console.log(res)
              that.getMyCooperationHospital()
            } else {
              wx.showToast({
                title: res.msg,
                icon: 'none'
              })
            }
          })
        }
      }
    })

 
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getMyCooperationHospital()
  },

  // 医生列表
  getMyCooperationHospital() {
    var that = this;
    app.agriknow2.queryDepartmentTypelist({
      hospitalCode: wx.getStorageSync('hosCode')
    }).then(res => {
      console.log(res);
      let data = res.hospitalDepartmentTypes;
      that.setData({ doctorList: data })
    })
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})