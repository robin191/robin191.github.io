// miniprogram/pages/project_list_detail_ memo_add/index.js
const app = getApp();
var uploadImage = require('../../utils/uploadFile.js');
var util = require('../../utils/util.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {

    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '查看详情', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    isBtn: false,
    noBtn: false, // 不可操作
    toastTitle: '',
    toastInfo: '',
    toastIsStu: false,

    saoNoUser: 1, // 1 显示  0 隐藏
    mobelStu: 0, // 输入手机号  1 弹  0 隐藏
    messageInfo: undefined,
    messageInfo2: {},


    memoList: [], // 移交与备注列表
    memoIndex: 0,
    index2: 0,
    time: '请选择具体时间',

    // 项目移交
    removeProStu: 0, // 移交项目长弹框  1 弹  0 隐藏
    removeProStuMemo: 0, // 添加备注

    eventCode: "YY000100010009", // YY00300020002 YY00200350004
    projectCode: '', // 项目code
    incidentDetail: {}, // 事件详情



    userList: [], // 成员
    teamList: [], //移交对象列表
    teamOldList: [], // 原始数据
    teamIdx: 0, // 移交对象下标
    executorContent: '', // 移交 备注

    // 备注说明
    content: '',
    contentStu: true,

    imgUrl: [],
    videoUrl: [],
    imgUrlGetApi: [], // 从后台获取到地址，保存到数据库
    imgUrlData: [], // 后台获取到的数据
    isOperation: false, // 确认提交 
    isShowBtn: false, //  移交

    nowPage: 1,
    hasData: -1, // -1 初始化   1 有数据  0 无数据
    isLoading: 1, // -1 初始化   1 加载    0 隐藏
    info: {},
    updImgNum: 9,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    if (options) {
      let info = JSON.parse(options.info);
      if (info.isExecutor == 1 && info.isComplete == 0) { // 可进行添加日程
        this.setData({
          isOperation: true
        });
      }
      if (info.isExecutor == 1) { // 可进行添加日程
        this.setData({
          isShowBtn: true
        });
      }
      this.setData({
        info: info,
        eventCode: info.eventCode,
        projectCode: info.projectCode
      });
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  addIncidentBtn(){
    app.globalData.gomes = !0
    wx.navigateBack({
      
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.getEventBaseInfo(); // 事件信息 详情
    this.readMessage();
    this.queryFilesByEventCode(); // 详情图片列表
    this.queryIsRead(); // 团队成员
    this.eventremarksList(); // 备注与移交列表
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    // 显示顶部刷新图标  
    wx.showNavigationBarLoading();
    this.eventremarksListOne('pull');
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    if (this.data.hasData >= 1) {

      this.eventremarksList();
    }
  },
  // 备注与移交列表
  eventremarksListOne(type) {
    this.setData({
      nowPage: 1
    });
    let that = this;

    let params = {
      "page": that.data.nowPage + '',
      "limit": "10",
      "eventCode": that.data.eventCode,
    };
    app.agriknow2.eventremarksList(params).then(res => {

      if (res.code === 0) {
        let data = res.page.list;
        for (var item in data) {
          data[item].createTime = data[item].createTime ? data[item].createTime.substring(11, 16) : data[item].createTime;
        }
        if (data.length >= 10) {
          that.setData({
            hasData: 1
          });
          this.setData({
            nowPage: parseInt(that.data.nowPage) + 1
          })
        } else {
          that.setData({
            hasData: -1
          });
        }
        if (type === 'pull') {
          // 隐藏导航栏加载框  
          wx.hideNavigationBarLoading();
          // 停止下拉动作  
          wx.stopPullDownRefresh();
        }
        that.setData({
          memoList: data
        });
      }
    })
  },

  // 备注与移交列表
  eventremarksList() {
    let that = this;
    let params = {
      "page": that.data.nowPage + '',
      "limit": "10",
      "eventCode": that.data.eventCode,
    };
    app.agriknow2.eventremarksList(params).then(res => {
      if (res.code === 0) {
        let data = res.page.list;
        for (var item in data) {
          data[item].createTime = data[item].createTime ? data[item].createTime.substring(11, 16) : data[item].createTime;
        }
        if (data.length >= 10) {
          this.setData({
            nowPage: parseInt(that.data.nowPage) + 1
          })
          that.setData({
            hasData: 1
          });
        } else {
          that.setData({
            hasData: -1
          });
        }
        that.setData({
          memoList: that.data.memoList.concat(data)
        });
      }
    })
  },


  // 详情图片列表
  queryFilesByEventCode() {
    let that = this;
    let params = {
      "eventCode": that.data.eventCode,
    };
    app.agriknow2.queryFilesByEventCode(params).then(res => {
      if (res.code === 0) {

        let data = res.fileInfoList;
        let arr = [];
        for (var item in data) {
          arr.push(data[item].path);
        }
        that.setData({
          imgUrlData: arr
        });
      }
    })
  },


  // 图片选择
  chooseImage: function(e) {
    var that = this;
    if (that.data.imgUrl.length >= 9) {
      wx.showToast({
        title: '图片只可上传9张',
      })
      return;
    }

    wx.chooseImage({
      count: 9 - that.data.imgUrl.length,
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function(res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        that.setData({
          imgUrl: that.data.imgUrl.concat(res.tempFilePaths)
        });
      }
    })
  },

  //上传图片 从云服务取到地址
  updloadWay1: function() {
    var nowTime = util.formatTime(new Date());
    let data = this.data.imgUrl;
    let that = this;
    let n = -1;
    let arr = []
    if (data.length > 0) {
      for (var item in data) {
        let typeArr = data[item].split('.');
        let type = typeArr[typeArr.length - 2] + '.' + typeArr[typeArr.length - 1];
        uploadImage(type, data[item], 'img/' + nowTime + '/',
          function(result) {
            n++;
            arr = arr.concat(result)
            if (n == data.length - 1 && item == data.length - 1) {
              that.uploadImageTemplateWay(arr); // 保存到数据库
            }
          },
          function(result) {}
        )
      }
    } else {
      wx.showToast({
        title: '请选择上传的图片',
        icon: 'none'
      })
    }

  },

  // 保存到数据库
  uploadImageTemplateWay: function(result) {
    var that = this;
    let params = []
    for (var i in result) {
      var namearr = result[i].split('/');
      var name = namearr[namearr.length - 1];
      let data = {
        "eventCode": that.data.eventCode,
        "fileName": name,
        "path": result[i],
        "projectCode": that.data.projectCode,
        "size": 30
      };
      params.push(data);
    }
    app.agriknow2.uploadImageTemplate(params, 'noloading').then(res => {
      if (res.code === 0) {
        wx.showToast({
          title: result.length + '个上传成功',
          icon: 'success',
          duration: 1000,
        })
        that.setData({
          isOperation: false
        })


      }
    })
  },



  // 移交处理人列表
  queryProjectTeamsPro() {
    let that = this;

    that.opeanYiJiaoBtn(); // 打开移交窗口
    let params = {
      "eventCode": that.data.eventCode,
    };
    app.agriknow2.queryProjectTeamsPro1(params).then(res => {
      if (res.code === 0) {
        let data = res.projectTeamList;
        let arr = [];
        for (var item in data) {
          arr.push(data[item].remarkName || '暂无名称');
        }
        that.setData({
          teamList: arr,
          teamOldList: data
        });
        // teamList: [], //移交对象列表
        //   teamOldList: [], // 原始数据
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },

  // 移交事件
  changeEventExecutor() {
    let that = this;
    let teamOldList = that.data.teamOldList;
    let executor = '';
    for (var item in teamOldList) {
      if (teamOldList[item].remarkName == that.data.teamList[that.data.teamIdx]) {
        executor = teamOldList[item].doctorCode
      }
    }
    let params = {
      "code": that.data.eventCode, //事件编码
      "content": that.data.executorContent, //备注内容
      "executor": executor //接收人编码
    };
    that.setData({
      isBtn: true
    })
    app.agriknow2.changeEventExecutor(params).then(res => {
      that.setData({
        isBtn: false
      })
      if (res.code === 0) {
        that.setData({
          isOperation: false
        });
        wx.showToast({
          icon: 'none',
          title: '移交成功',
        })
        that.closeYiJiaoBtn();
        that.setData({
          content: ''
        });
        that.eventremarksListOne(); // 备注与移交列表
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },

  // 事件信息 详情
  getEventBaseInfo() {
    let that = this;
    let params = {
      "code": that.data.eventCode,
    };
    app.agriknow2.getEventBaseInfo(params).then(res => {
      if (res.code === 0) {
        res.eventInfo.data1 = res.eventInfo.createTime ? res.eventInfo.createTime.substring(5, 7) : res.eventInfo.createTime;
        res.eventInfo.createTime = res.eventInfo.createTime ? res.eventInfo.createTime.substring(5, 16) : res.eventInfo.createTime;
        that.setData({
          incidentDetail: res.eventInfo,
          projectCode: res.eventInfo.projectCode
        });
      }
    })
  },

  // 项目进行已读
  readMessage() {
    let that = this;
    let params = {
      "messageId": that.data.info.messageId, //消息ID 必填
    };
    app.agriknow2.readMessage(params).then(res => {
      if (res.code === 0) {}
    })
  },

  // 团队成员查看状态 
  queryIsRead() {
    let that = this;
    let params = {
      "eventCode": that.data.eventCode,
    };
    app.agriknow2.queryIsRead(params).then(res => {
      if (res.code === 0) {
        that.setData({
          userList: res.messageReceiverRelationVos
        });
      }
    })
  },


  // 添加备注
  addEventRemark() {
    let that = this;
    if (that.data.content.length < 3) {
      wx.showToast({
        title: '请填写备注说明（至少3个字）',
        icon: 'none'
      })
      return;
    }
    let params = {
      "eventCode": that.data.eventCode,
      "content": that.data.content //备注内容 必填
    };
    that.setData({
      isBtn: true
    })
    app.agriknow2.addEventRemark(params).then(res => {
      that.setData({
        isBtn: false
      })
      if (res.code === 0) {
        wx.showToast({
          icon: 'none',
          title: '添加成功',
        })
        that.closeMemoBtn();
        that.setData({
          content: ''
        });
        that.eventremarksListOne(); // 备注与移交列表
      } else {
        wx.showToast({
          icon: 'none',
          title: res.msg,
        })
      }
    })
  },

  /**
   *  移交备注信息验证
   */
  executorContentBlur(e) {
    var that = this;
    let executorContent = e ? e.detail.value : e;
    // if (content.length > 1 && content.length <= 15) {
    //   that.setData({ contentStu: true })
    // } else {
    //   that.setData({ contentStu: false })
    // }
    that.setData({
      executorContent: executorContent,
    })
  },

  /**
   *  备注信息验证
   */
  contentBlur(e) {
    var that = this;
    let content = e ? e.detail.value : e;
    if (content.length > 1 && content.length <= 15) {
      that.setData({
        contentStu: true
      })
    } else {
      that.setData({
        contentStu: false
      })
    }
    that.setData({
      content: content,
    })
  },



  // 删除
  delImgBtn(e) {
    let idx = e.currentTarget.dataset.idx;
    let img = this.data.imgUrl;
    img.splice(idx, 1);
    this.setData({
      imgUrl: img
    });
  },


  // 图片放大
  previewImage122: function(e) {
    wx.previewImage({
      current: e.currentTarget.id, // 当前显示图片的http链接
      urls: this.data.imgUrlData // 需要预览的图片http链接列表
    })
  },

  // 图片放大
  previewImage: function(e) {
    wx.previewImage({
      current: e.currentTarget.id, // 当前显示图片的http链接
      urls: this.data.imgUrl // 需要预览的图片http链接列表
    })
  },

  // 移交人选择
  teamChange(e) {
    this.setData({
      teamIdx: e.detail.value
    })
  },


  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({
      toastTitle: title,
      toastInfo: info,
      toastIsStu: stu
    });
    if (stu) {
      var time = setInterval(function() {
        that.setData({
          toastTitle: title,
          toastInfo: info,
          toastIsStu: false
        });
        clearInterval(time);
      }, 3000);
    }

  },


  sureBtn() {
    wx.navigateTo({
      url: '../index_message_list/index'
    }); // 跳转到售票页面
  },

  // 打开移交窗口
  opeanYiJiaoBtn() {
    this.setData({
      removeProStu: 1
    });
  },

  // 关闭移交窗口
  closeYiJiaoBtn() {
    this.setData({
      removeProStu: 0
    });
  },

  // 打开备注窗口
  opeanMemoBtn() {
    this.setData({
      removeProStuMemo: 1
    });
  },

  // 关闭备注窗口
  closeMemoBtn() {
    this.setData({
      removeProStuMemo: 0
    });
  },

  // 新增事件
  addProjectBtn() {
    app.getProjectInfo = this.data.projectCode;
    wx.navigateTo({
      url: '../project_add_incident/index'
    }); // 跳转到售票页面
  },

  // 时间选择
  bindTimeChange(e) {
    this.setData({
      time: e.detail.value
    })
  },

  // 打开移交窗口
  opeanMobelBtn() {
    this.setData({
      mobelStu: 1
    });
  },

  // 关闭移交窗口
  closeMobelBtn() {
    this.setData({
      mobelStu: 0
    });
    wx.reLaunch({
      url: '../index_message_list/index',
    })
  },

  // 确认到诊
  toDetailDiagonsis() {
    wx.navigateTo({
      url: '../index_message_detail_diagnosis/index',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },



  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})