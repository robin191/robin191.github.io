// miniprogram/pages/user_register/index.js
const app = getApp();
let timer = null;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '新增医生', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    toastTitle: '',
    toastInfo: '',
    toastIsStu: false,

    saoNoUser:-1, // -1 用户添加 1 有用户  0 无用户
    isBtn: false,
    // 用户所填数据 
    registData: {
      companyId: wx.getStorageSync("companyId"),//  String	是	公司ID 
      phoneNum: '',	//	String	是	手机号码 17888211416
      phoCode: '',      // 验证码 
    },

    selType:['本机构医生','外机构医生'],
    selTypeIdx:1,
    
    //  数据验证是否填写正确
    registEreg: {
      phoneNum: true,	 //	  String	是	手机号码
      phoCode: false   //   验证码是否填写正确
    },

    codeTime: -1,   // 验证码失效时间设置
    phoCodeApi: '', // 后台返回的验证码

    doctorInfo:{
      hospitalCode: "",
      nickName: "",
      avatarUrl: "",
      mobilePhone: "",
      openId: ""

    }, // 患者信息
    openId:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(JSON.parse(options.info))
    if (JSON.parse(options.info)) {
      console.log(1233)
      this.setData({ doctorInfo: JSON.parse(options.info) });
      this.setData({ saoNoUser: 1 });
    }
  },

  /**
  *  新增医生
  */
  registinfoWay: function () {
    let that = this;
    let d = {}
    // 验证手机号
    if(this.data.openid){
      d= {
        openId: this.data.openid
      }
    }else{
      if (!phoneRegWay(that.data.registData.phoneNum)) {
        return;
      }else{
        d={
          mobilePhone: that.data.registData.phoneNum || undefined,
        }
      }
    }
    
    // openId: that.data.openId || undefined 
    app.agriknow2.addHospitalDoctor(d).then(res => {
      if (res.code === 0){
        if (res.doctorInfo){
          that.setData({ doctorInfo: res.doctorInfo });
          that.setData({ saoNoUser: 1 });
        }else{
          that.setData({ saoNoUser: 0 });
        }
      }else{
        // that.setData({ saoNoUser: 0 });
        that.toastSetWay('',res.msg,true);
      }
    })
  },


  // 确认
  returnPage() {
    let that = this;
    let params = {
      "doctorCode": that.data.doctorInfo.openId,//医生编码
      "relationship": that.data.selTypeIdx,//与医院关系 1：隶属（本机构） 2：合作（外机构）
      "hospitalCode": that.data.doctorInfo.hospitalCode//医院编码
    }
    app.agriknow2.addHospitalDoctorConfirm(params).then(res => {
      if (res.code === 0) {
        // that.toastSetWay('', res.msg, true);
        wx.navigateTo({
          url: '/pages/manage_doctor_upd/index?info=' + JSON.stringify(res.doctorInfo),
        })
      }else{
        that.toastSetWay('', res.msg, true);
      }
    })
   
  },

  returnPages(){
    wx.navigateBack({
      delta: 1
    })
  },

  selType(e){
    this.setData({ selTypeIdx: e.currentTarget.dataset.type});
  },

  returnPage1(){
    this.setData({ saoNoUser:-1});
  },

  returnPage2() {
    app.createProInfo.huanzhe = this.data.huanzheInfo
    wx.navigateBack({
      delta: 1
    })
  },


  // 扫描 
  saoBtn(){
    let that=this
    wx.scanCode({
      success(res){
        console.log(res)
        that.setData({
          openid: res.result
        })
        that.registinfoWay()
      }
    })
    
  },


  /**
   *  获取界面手机号
   */
  phoneNumBlur(e){
    this.setData({['registData.phoneNum']: e.detail.value})
    if (this.data.registData.phoneNum !== '' && this.data.registData.phoneNum.length === 11) {
      this.setData({ ['registEreg.phoneNum']: true });
    } else {
      this.setData({ ['registEreg.phoneNum']: false });
    }
  },
  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({ toastTitle: title, toastInfo: info, toastIsStu: true });
    var time = setInterval(function () {
      that.setData({ toastTitle: title, toastInfo: info, toastIsStu: false });
      clearInterval(time);
    }, 3000);
  },
  

 
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
    }
    return {
      title: '石城巴士小程序',
      path: 'pages/i_sel_site/index1',
      success: function (res) {
        // 转发成功
      },
      fail: function (res) {
        // 转发失败
      }
    }
  }
})

/**
 * 提示框
 */
function showToastWay(msg){
  wx.showToast({
    title: msg,
    icon: 'none',
    duration: 1500
  })
}

/**
*  加载等待提示框
*/
function showLoading(msg) {
  wx.showToast({
    title: '加载中',
    icon: 'loading'
  });
}
/**
*  取消等待提示框
*/
function cancelLoading() {
  wx.hideToast();
}

/**
*  手机号码验证
*/
function phoneRegWay(phone){
  if (phone==null||phone==''){
    showToastWay('请输入手机号')
    return false;
  }
  var phoneReg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
  if (!phoneReg.test(phone)) {
    showToastWay('手机号有误！')
    return false;
  }
  return true;
}