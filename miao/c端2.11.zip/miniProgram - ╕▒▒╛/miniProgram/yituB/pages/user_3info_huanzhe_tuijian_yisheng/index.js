// miniprogram/pages/user_1info_hospital/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '推荐医生', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    tabList: [
      { name: '附近的医院', val: 0 },
      { name: '合作过的遗言', val: 1 },
    ], // tab选项
    tabIndex:0,
    selIndex:0,
    doctorList:[],
    zhensuo:{},

    remarkName: '',
    keshiList: ['全部科室'], // 科室列表
    keshiOldList: [], // 科室列表
    keshiIdx: 0, // 科室列表
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if(options.types){
      this.setData({
        types: options.types
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({ zhensuo: app.tuijianPatients.zhensuo});
    if (this.data.zhensuo.name){
      this.getByHospitalCode();
      this.getDepartmentVosByHospitalCode(); // 科室列表 
    }else{
      wx.showToast({
        title: '请先选择诊所',
      })
    }
  },

  // 科室列表
  getDepartmentVosByHospitalCode() {
    var that = this;
    app.agriknow2.getDepartmentVosByHospitalCode({}).then(res => {
      if (res.code === 0) {
        let data = res.hospitalDepartmentList;
        let arr = [] ;
        for (var item in data) {
          arr.push(data[item].departmentName);
        }
        that.setData({ keshiList: that.data.keshiList.concat(arr), keshiOldList: data });
      }
    })
  },

  // 搜索输入
  remarkNameInput(e) {
    this.setData({
      remarkName: e.detail.value
    })
  },

  keshiChange(e) {
    this.setData({
      keshiIdx: e.detail.value
    })
    this.getByHospitalCode();
  },


  // 医生列表
  getByHospitalCode() {
    var that = this;
    let code = undefined;
    if (that.data.keshiIdx >= 1) {
      let old = that.data.keshiOldList;
      for (var item in old) {
        if (old[item].departmentName === that.data.keshiList[that.data.keshiIdx]) {
          code = old[item].departmentCode
        }
      }
    }
    let params = {}
    if (this.data.types != 2){
      console.log(123456)
      params = {
        "hospitalCode": this.data.zhensuo.code,
        "recommendDoctorCode": wx.getStorageSync('docCode'),
        "recommenderType": 1,
        "userName": this.data.remarkName
      }
    }else{
      params = {
        "hospitalCode": this.data.zhensuo.code,
        "recommendHospitalCode": wx.getStorageSync('hosCode'),
        "recommenderType": 2,
        "userName": this.data.remarkName
      }
      
    }
    
    app.agriknow2.clinicDoctorsCooperationDesc(params).then(res => {
      if (res.code === 0) {
        console.log(res)
        that.setData({ doctorList: res.list })
      }
    })
  },

  // 删除输入关键字
  clearBtn() {
    this.setData({ remarkName: '' });
  },
  getMyCooperationHospital(){
    this.getByHospitalCode()
  },
  // 进行选择内容
  selBtn(e){
    this.setData({ selIndex: e.currentTarget.dataset.idx});
  },

  // 确定返回
  sureBtn(){
    app.tuijianPatients.doctor = this.data.doctorList[this.data.selIndex]
    wx.navigateBack({ delta: 1 })
  },

  // 地区选择
  bindPickerChange1(e) {
    this.setData({
      index1: e.detail.value
    })
  },


  // 标题选择
  selTypeLine(e) {
    console.log(e.currentTarget.dataset.idx);
    this.setData({ tabIndex: e.currentTarget.dataset.idx });

  },

  returnBtn(){
    wx.navigateBack({//返回
      delta: 1
    })
  },

  // 新增患者
  addHuanzheBtn(){
    wx.navigateTo({ url: '../project_add_user_list/index' }); // 患者信息
  },

  // 发送消息
  sendInfo(){
    wx.navigateTo({ url: '../project_add_user_list/index' }); // 患者信息
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})