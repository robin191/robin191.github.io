// miniprogram/pages/user_1info_hospital/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    keshiList: [{ departmentName:'全部科室'}],
    keshiOld: [], // 科室类型原始数据
    keshiIdx: 0,

    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '科室', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    tabList: [
      { name: '附近的医院', val: 0 },
      { name: '合作过的遗言', val: 1 },
    ], // tab选项
    tabIndex:0,
    selIndex:-1,
    oneIndex:-1,
    hospital1: [
      {
        ke: '科室1', dataList: [
          { title: '医生11', num: '1534545442' },
          { title: '诊所1', num: '115345454422' }, { title: '诊所1', num: '115345454422' }, { title: '诊所1', num: '12' }, { title: '诊所1', num: '115345454422' },
        ]},
      {
        ke: '科室2', dataList: [
          { title: '医生11', num: '1534545442' },
          { title: '诊所1', num: '115345454422' }, { title: '诊所1', num: '115345454422' }, { title: '诊所1', num: '12' }, { title: '诊所1', num: '115345454422' },
        ]
      }
      

    ],
    // hospital1:[],
    // hospital2:[{title:'医院1',num:'12'},
    //   { title: '医院1', num: '12' }, { title: '医院1', num: '12' }, { title: '医院1', num: '12' }, { title: '医院1', num: '12' },
    // ],
    hospital2:[],

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },
  sel_btn(){
    this.keshiApi(null,this.data.keyword)
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  getkeyword(e){
    this.setData({
      keyword:e.detail.value
    })
  },
  delKeyword(){
    this.setData({
      keyword: ''
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    app.tuijianPatients.yiyuan.code == "YY00000002"
    this.keshiApi({});
    this.keshiTypeApi(); // 科室类型
  },

  // 科室类型
  keshiTypeApi() {
    let that = this;
    app.agriknow2.queryDepartmentTypelist({
      "hospitalCode": app.tuijianPatients.yiyuan.code || "YY00000002" //医院编码
    }).then(res => {
      if (res.code === 0) {
        that.setData({
          keshiList: that.data.keshiList.concat(res.hospitalDepartmentTypes)
        })
      }
    })
  },

  // 科室选择
  bindPickerChange1(e) {
    console.log(this.data.keshiList[e.detail.value])
    this.setData({
      keshiIdx: e.detail.value
    })
    this.keshiApi(this.data.keshiList[e.detail.value], this.data.keyword)
  },


  keshiApi(e, s) {
    let that = this;
    // let data = {
    //   "departmentName": "口腔",//科室名称 非必填
    //   "departmentType": 1//科室类型编码 非必填
    // }


    app.agriknow2.getDepartmentsByHospitalCode({
      departmentType: that.data.keshiList[that.data.keshiIdx].departmentType,
      departmentName: s,
      hospitalCode: app.tuijianPatients.yiyuan.code || "YY00000002"
    }).then(res => {
      console.log(res)
      if (res.code === 0) {
        var list = res.hospitalDepartmentList, arr = [], cc = []
        for (let i in list) {  //获取科室分类长度
          if (cc.indexOf(list[i].departmentType) < 0) {
            console.log(cc.indexOf(list[i].departmentType))
            cc.push(list[i].departmentType)
            arr.push({
              type: list[i].departmentType,
              name: list[i].departmentTypeName,
              list: []
            })
            console.log(cc, arr)
          }
        }

        for (let i in arr) {
          for (let j in list) {
            if (list[j].departmentType == arr[i].type) {
              arr[i].list.push(list[j])
            }
          }
        }
        console.log(arr)
        that.setData({
          hospital1: arr
        })
      }else{
        wx.showToast({
          title: res.msg,
          icon:'none'
        })
      }
    })
  },



  selBtn(e){
    let index1 = e.currentTarget.dataset.idx
    let index2 = e.currentTarget.dataset.index
    console.log(index1,index2)
    this.setData({
      oneIndex:index1,
      selIndex:index2
    })
    app.tuijianPatients.yiyuan
  },
  addrichengBtn(){
    if(this.data.oneIndex>=0){
      app.tuijianPatients.keshi = this.data.hospital1[this.data.oneIndex].list[this.data.selIndex]
    }
  
    wx.navigateBack({
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})