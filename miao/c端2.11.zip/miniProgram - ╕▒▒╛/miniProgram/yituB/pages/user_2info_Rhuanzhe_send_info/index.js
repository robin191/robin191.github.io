// miniprogram/pages/user_1info_hospital/index.js
const app = getApp();
var uploadImage = require('../../utils/uploadFile.js');
var util = require('../../utils/util.js');
Page({

    /**
     * 页面的初始数据
     */
    data: {
      // 组件所需的参数
      nvabarData: {
        showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
        title: '发送消息', //导航栏 中间的标题
      },
      height: app.globalDatas.height * 2 + 20,
        address: '',
        sexArr: ['男', '女'],
        sexIdx: 1,
        imgUrl:[]
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
      wx.removeStorageSync('choosePatient')
    },
    setUserName(e) {
        this.setData({
            mes: e.detail.value
        })
    },
  bindTextAreaBlur(e){
    this.setData({
      feedback:e.detail.value
    })
  },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },
  previewImage(e){
    wx.previewImage({
      current:e.currentTarget.dataset.item,
      urls: this.data.imgUrl
    })
  },
  
    choosePatient(){
      wx.navigateTo({
        url: '/pages/choosePatient/index',
      })
    },

    add_pho() {
        let that = this
        console.log(this.data.imgUrl.length)
        if(this.data.imgUrl.length>=9){
            wx.showToast({
                title: '最多上传九张',
                icon:'none'
            })
            return false;
        }

        wx.chooseImage({
            count: 9-this.data.imgUrl.length,
            sizeType: ['original', 'compressed'],
            sourceType: ['album', 'camera'],
            success: function (res) {
                console.log(res)
                that.setData({
                    imgUrl: that.data.imgUrl.concat(res.tempFilePaths)
                });
                if(that.data.imgUrl.length>=9){
                  that.setData({
                    isFull: !0
                  });
                }else{
                  that.setData({
                    isFull: !1
                  });
                }
            },
        })
    },
    deleteImg(e){
        let that =this,imglist = this.data.imgUrl
        wx.showModal({
            title: '提示',
            content: '您要删除这张图片吗?',
            success(res){
                if(res.confirm){
                    imglist.splice(e.currentTarget.dataset.index,1)
                    that.setData({
                        imgUrl:imglist
                    })
                  if (that.data.imgUrl.length >= 9) {
                    that.setData({
                      isFull: !0
                    });
                  } else {
                    that.setData({
                      isFull: !1
                    });
                  }
                }
            }
        })
    },
    updloadWay1: function () {
        var nowTime = util.formatTime(new Date());
        let data = this.data.imgUrl;
        let that = this;
        let arr = [],n=-1
        if(data.length>0){
          for (var item in data) {
            let typeArr = data[item].split('.');

            let type = typeArr[typeArr.length - 2] + '.' + typeArr[typeArr.length - 1];
            console.log(item, data.length)
            uploadImage(type, data[item], 'img/' + nowTime + '/',
              function (result) {
                arr.push(result)

                n++;
                console.log(item, data.length - 1, n)
                if (item == data.length - 1 && item == n) {
                  console.log('------------')
                  that.uploadImageTemplateWay(arr); // 保存到数据库
                }
              }, function (result) {
              }
            )
          }
        }else{
          this.uploadImageTemplateWay(); // 保存到数据库
        }
        
    },
    // 保存到数据库
    uploadImageTemplateWay: function (result, item) {
        console.log(result)
        var that = this;
        let params = []
        if(result){
          for (var i in result) {
            var namearr = result[i].split('/');
            var name = namearr[namearr.length - 1];

            var data = {
              "fileName": name,
              "path": result[i],
              "size": 300
            };
            params.push(data);
          }
        }
        
        let d = {
            "content": this.data.feedback,
            "files": params,
            "clientReciverCodes":this.data.patientmes.ids,
          "senderCode": wx.getStorageSync('hosCode')
        }
        console.log(params)

        if(app.globalData.mysend){
          app.agriknow2.doctorSendToPatient(d, 'noloading').then(res => {
            if (res.code === 0) {
              wx.showToast({
                title: '发送成功',
                icon: 'none'
              })
              setTimeout(function () {
                wx.navigateBack({

                })
              }, 1500)
            } else {
              wx.showToast({
                title: res.msg,
                icon: 'none'
              })
            }
          })
        }else{
          app.agriknow2.hospitalSendToPatient(d, 'noloading').then(res => {
            if (res.code === 0) {
              wx.showToast({
                title: '发送成功',
                icon: 'none'
              })
              setTimeout(function () {
                wx.navigateBack({

                })
              }, 1500)
            } else {
              wx.showToast({
                title: res.msg,
                icon: 'none'
              })
            }
          })
        }
      
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
      let mes = wx.getStorageSync('choosePatient')
      console.log(mes)
      this.setData({
        patientmes:mes
      })
    },

    // 性别选择
    bindSexChange(e) {
        this.setData({
            sexIdx: e.detail.value
        })
    },

    // 添加日程
    addProjectBtn() {
        wx.reLaunch({
            url: '../user-detail/userdetail',
        })
    },


    // 选择上传站点
    mapAddress() {
        var that = this;
        wx.chooseLocation({
            success: function (res) {
                // success
                that.setData({
                    // hasLocation: true,
                    // longitude: res.longitude,
                    // latitude: res.latitude,
                    address: res.name,
                    name: res.name
                })
                app.selUserSite = {type: 1, address: res.name, addressCompany: that.data.addressCompany}
            },
            fail: function () {
                // fail
            },
            complete: function () {
                // complete
            }
        })
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})
