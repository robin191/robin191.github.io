// miniprogram/pages/project_list_detail_useradd/index.js
const app = getApp();
var uploadImage = require('../../utils/uploadFile.js');
var util = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '医好康', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    toastTitle: '',
    toastInfo: '',
    toastIsStu: false,

    eventCode:'',
    projectCode:'',
    userInfo: {
      "projectCode": "",
      "patientName": "",
      "sex": 1,
      "idNumber": "",
      "birthday": "",
      "weight": "",
      "isAllergy": 1,
      "allergyDetail": "",
      "disease": "",
      "diseaseDetail": "",
      "versionNo": "001",
      mobilePhone:''
    },
    sexArr: ['男', '女'],
    sexIdx: 0,

    guominArr: ['否', '是'],
    guominIdx: 0,

    userNameStu: true,//昵称
    idNumberStu: true,//身份证
    mobilePhoneStu:true,
    imgUrl: [],
    videoUrl: [],
    imgUrlGetApi: [], // 从后台获取到地址，保存到数据库
    imgUrlData: [], // 后台获取到的数据
    imgUrlDataOld: [], // 后台获取到的数据

    delImgIdx:[], // 原始数据
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // app.projectCode = 'YY00010027'
    this.setData({ projectCode: app.projectCode });
    this.getProHuanzhe(); // api - 患者信息
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (wx.getStorageSync('zhenduan')) {
      this.setData({ ['userInfo.disease']: wx.getStorageSync('zhenduan') })
    }
    if (wx.getStorageSync('guomin')) {
      this.setData({ ['userInfo.allergyDetail']: wx.getStorageSync('guomin') })
    }
    if (wx.getStorageSync('detail')) {
      this.setData({ ['userInfo.diseaseDetail']: wx.getStorageSync('detail') })
    }
  },

  // 时间选择
  bindDateChange: function (e) {
    this.setData({
      ['userInfo.birthday']: e.detail.value
    });
  },

  // 确定取消方法
  bindcancel(e) {
    this.setData({
      ['userInfo.birthday']: ''
    });
  },

  // 删除
  delImgBtn(e){
    let idx = e.currentTarget.dataset.idx;
    let img = this.data.imgUrl;
    img.splice(idx, 1);
    this.setData({ imgUrl: img });

  },

  // 删除
  delImgBtn1(e) {
    let idx = e.currentTarget.dataset.idx;

    this.setData({ delImgIdx: this.data.delImgIdx.concat(this.data.imgUrlData[idx]) })

    let img = this.data.imgUrlData;
    img.splice(idx, 1);
    this.setData({ imgUrlData: img });
  },

  // 首页-事件提交-患者信息模板
  uploadImageTemplateWay() {
    var that = this;
    if (that.data.guominIdx == 0 ){
      that.setData({
        ['userInfo.allergyDetail']:'',
      })
    }
    that.setData({
      ['userInfo.sex']: parseInt(that.data.sexIdx) + 1,
      ['userInfo.isAllergy']: parseInt(that.data.guominIdx)
    })
    let deleteIds = [];
    let imgUrlDataOld = that.data.imgUrlDataOld;
    let delImgIdx = that.data.delImgIdx;
    for (var item in imgUrlDataOld){
      for (var i in delImgIdx){
        if (imgUrlDataOld[item].path == delImgIdx[i]){
          deleteIds = deleteIds.concat(imgUrlDataOld[item].id)
        }
      }
    }
    
    let fileInfos = [];
    let imgUrlGetApi = that.data.imgUrlGetApi;
    for (var item in imgUrlGetApi) {

      var namearr = imgUrlGetApi[item].split('/');
      var name = namearr[namearr.length - 1];
      let data = {
        "eventCode": that.data.eventCode,
        "fileName": name,
        "path": imgUrlGetApi[item],
        "projectCode": that.data.projectCode,
        "size": 300
      };
      fileInfos.push(data);
    }
    if (!that.data.userInfo.projectCode){
      that.setData({ ['userInfo.projectCode']: that.data.projectCode})
    }
    let params = {
      deleteIds: deleteIds,
      fileInfos: fileInfos,
      projectPatient: that.data.userInfo
    }
    app.agriknow2.updatePatientInfoWithFilesPro(params, 'noloading').then(res => {
      if (res.code === 0) {
        that.toastSetWay('', '提交成功', true);
        wx.navigateBack({ data: 1 })
      } else {
        that.toastSetWay('', '提交失败', true)
      }
    })
  },

  // api - 患者信息  'YY0020023'
  getProHuanzhe() {
    let that = this;
    let params = { projectCode: that.data.projectCode };
    app.agriknow2.queryPatientInfoByProject(params).then(res => {
      if (res.code === 0) {
        let data = res.projectPatient
        that.setData({ userInfo: data, sexIdx: parseInt(data.sex) - 1 || 0, guominIdx: parseInt(data.isAllergy) || 0 })
        if (res.projectPatient.eventCode) {
          that.setData({ eventCode: data.eventCode})
          that.getProHuanzheImg(data.eventCode); // 患者图片
        }
      }
    })
  },

  // api - 患者信息 图片  that.data.projectCode 'YY0020023'
  getProHuanzheImg(eventCode) {
    let that = this;
    let params = { eventCode: eventCode };
    app.agriknow2.queryFilesByEventCode(params).then(res => {
      if (res.code === 0) {
        let data = res.fileInfoList;
        that.setData({ imgUrlDataOld: data})
        let arr = [];
        for (var item in data) {
          arr.push(data[item].path);
        }
        that.setData({ imgUrlData: arr });
      }
    })
  },

  

  // 图片放大
  previewImage: function (e) {
    wx.previewImage({
      current: e.currentTarget.id, // 当前显示图片的http链接
      urls: this.data.imgUrl // 需要预览的图片http链接列表
    })
  },
  // 图片放大
  previewImage1: function (e) {
    wx.previewImage({
      current: e.currentTarget.id, // 当前显示图片的http链接
      urls: this.data.imgUrlData // 需要预览的图片http链接列表
    })
  },

  // 跳转输入内容
  disease(e) {
    this.setData({ diseaseType: e.currentTarget.dataset.type })
    wx.navigateTo({
      url: '/pages/manage_keshi_disease/index?type=' + e.currentTarget.dataset.type,
    })
  },


  // 身份证
  idNumberBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name !== '' && name.length === 18) {
      that.setData({ idNumberStu: true })
    } else {
      that.setData({ idNumberStu: false })
    }
    that.setData({
      ['userInfo.idNumber']: name,
    })
  },

  // 手机号
  mobilePhoneBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name !== '' && name.length === 11) {
      that.setData({ mobilePhoneStu: true })
    } else {
      that.setData({ mobilePhoneStu: false })
    }
    that.setData({
      ['userInfo.mobilePhone']: name,
    })
  },


  // 姓名
  userNameBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name.length > 1) {
      that.setData({ userNameStu: true })
    } else {
      that.setData({ userNameStu: false })
    }
    that.setData({
      ['userInfo.patientName']: name,
    })
  },

  weightBlur(e){
    let name = e.detail.value;
    this.setData({
      ['userInfo.weight']: name,
    })
  },

  // 性别选择
  bindSexChange(e) {
    this.setData({
      sexIdx: e.detail.value
    })
  },


  // 过敏史
  bindGuominChange(e) {
    this.setData({
      guominIdx: e.detail.value
    })
  },

  //上传图片 从云服务取到地址
  updloadWay1: function () {
    if (!this.data.userInfo.patientName || this.data.userInfo.patientName.length <= 1) {
      this.toastSetWay('', '请填写患者名称', true);
      return;
    }

    if (!this.data.userInfo.mobilePhone || this.data.userInfo.mobilePhone.length !== 11) {
      this.toastSetWay('', '请填写有效的手机号', true);
      return;
    }


    if (!phoneRegWay2(this.data.userInfo.idNumber)) {
      return;
    }

    var nowTime = util.formatTime(new Date());
    let data = this.data.imgUrl;
    let that = this;

    let n = -1
    if (data.length > 0){
      for (var item in data) {
        let typeArr = data[item].split('.');
        let type = typeArr[typeArr.length - 2] + '.' + typeArr[typeArr.length - 1];
        uploadImage(type, data[item], 'img/' + nowTime + '/',
          function (result) {
            n++;
            that.setData({ imgUrlGetApi: that.data.imgUrlGetApi.concat(result) })
            if (n == data.length - 1 && item == data.length - 1) {
              that.uploadImageTemplateWay(); // 保存到数据库
            }
          }, function (result) {
          }
        )
      }
    }else{
      that.uploadImageTemplateWay(); // 保存到数据库
    }
    

  },

  // 患者 图片选择
  chooseImage: function (e) {
    var that = this;
    if (that.data.imgUrl.length > 9) {
      return;
    }
    wx.chooseImage({
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        that.setData({
          imgUrl: that.data.imgUrl.concat(res.tempFilePaths)
        });
      }
    })
  },

  // 显示加载动画
  showLoading: function () {
    wx.showLoading({
      title: '加载中...',
      icon: 'loading'
    })
  },


  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({ toastTitle: title, toastInfo: info, toastIsStu: true });
    var time = setInterval(function () {
      that.setData({ toastTitle: title, toastInfo: info, toastIsStu: false });
      clearInterval(time);
    }, 3000);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
  
})

/**
*  身份证验证
*/
function phoneRegWay2(phone) {
  if (phone == null || phone == '') {
    showToastWay('请输入身份证号')
    return false;
  }
  var reg = /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/;

  if (!reg.test(phone)) {
    showToastWay('请输入有效身份证号！')
    return false;
  }
  return true;
}
/**
 * 提示框
 */
function showToastWay(msg) {
  wx.showToast({
    title: msg,
    icon: 'none',
    duration: 1500
  })
}