// miniprogram/pages/user_add_QR/index.js
var QR = require("../../utils/qrcode.js");//绘制二维码工具库
const app = getApp()
const getRatio = () => {

  let w = 0

  wx.getSystemInfo({

    success: function (res) {

      w = res.windowWidth / 375; //按照750的屏宽

    },

  })

  return w
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '我的二维码', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    mobelStu:0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      userinfo: JSON.parse(wx.getStorageSync('userInfo'))
    })
    this.drawposter()
  },

  // 打开移交窗口
  opeanMobelBtn() {
    this.setData({ mobelStu: 1,shares:!0 });

    this.createQrCode()
  },
  createQrCode(){
    console.log(getRatio())
    let docCode = wx.getStorageSync('docCode')
    QR.qrApi.draw('B=='+docCode, "myCanvas", 375 * getRatio()/2, 375 * getRatio()/2, null, '')
  },
  // 关闭移交窗口
  closeMobelBtn() {
    this.setData({ mobelStu: 0 ,shares:!1});
    this.drawposter()
  },
  closeMobelBtn1() {
    // this.setData({ mobelStu: 0 });
    this.saveImg()
  },
  saveImg: function () {
    var that = this
    wx.canvasToTempFilePath({
      x: 0,
      y: 0,
      width: 375 * getRatio(),
      height: 375 * getRatio(),
      canvasId: 'myCanvas',
      success: function (res) {
        console.log(res.tempFilePath);
        /* 这里 就可以显示之前写的 预览区域了 把生成的图片url给image的src */
        that.setData({
          imageUrl: res.tempFilePath
        })
        that.saveTophoto();
      },
      fail: function (res) {
        console.log(res)
      }
    }, this)
  },

  saveTophoto: function () {
    var that = this;
    console.log(that.data.imageUrl)
    wx.saveImageToPhotosAlbum({
      filePath: that.data.imageUrl,
      success(res) {
        console.log(2) 
        wx.showModal({
          content: '图片已保存到相册，赶紧晒一下吧~',
          showCancel: false,
          confirmText: '好的',
          confirmColor: '#333',
          success: function (res) {
            if (res.confirm) {
              that.setData({
                sharezz: !1,
                mobelStu:0
              })
              that.drawposter()
            }
          }
        })
      }
    })
  },
  drawposter(){
    console.log('执行了')
    let docCode = wx.getStorageSync('docCode')
    QR.qrApi.draw('B==' + docCode, "myCanvas1", 570 * getRatio() / 2, 570 * getRatio() / 2, null, '')
   
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})