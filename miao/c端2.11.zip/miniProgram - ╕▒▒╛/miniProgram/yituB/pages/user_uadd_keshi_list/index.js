// miniprogram/pages/user_1info_hospital/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '科室', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    keshiList: ['全部科室', '科室1'],
    keshiOld: [], // 科室类型原始数据
    keshiIdx: 0,

    hospital1: [
    ],
    hospital2: [],
    idx1:0,
    idx2:0,

    toastTitle: '',
    toastInfo: '',
    toastIsStu: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },
  keyword(e){
    this.setData({
      keyword:e.detail.value
    })
  },
  search(){
    this.keshiApi(this.data.keshiList[this.data.keshiIdx],this.data.keyword)
  },
  clearKeyword(){
    this.setData({
      keyword:''
    })
  },

  selBtn(e){
    let idx1 = e.currentTarget.dataset.idx1;
    let idx2 = e.currentTarget.dataset.idx2;
    this.setData({idx1:idx1, idx2:idx2})
    
  },

  // 返回到个人信息
  sureBtn() {
    app.userDetailInfo.keshi = this.data.hospital1[this.data.idx1].list[this.data.idx2];
    wx.navigateBack({ delta: 1 })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    if (!app.userDetailInfo.yiyuan) {
      wx.showToast({
        title: '选择医院',
      })
      return;
    }
    this.keshiApi({}); // 科室列表
    this.keshiTypeApi(); // 科室类型
  },

  // 科室类型
  keshiTypeApi() {
    let that = this;
    console.log(wx.getStorageSync('hosCode'))
    app.agriknow2.queryDepartmentTypelist({
      "hospitalCode": wx.getStorageSync('hosCode') //医院编码 app.userDetailInfo.yiyuan.code
    }).then(res => {
      if (res.code === 0) {
        that.setData({
          keshiList: res.hospitalDepartmentTypes
        })
      }else{
        that.toastSetWay('', res.msg,true)
      }
    })
  },

  // 科室列表
  keshiApi(e,s) {
    let that = this;
    // let data = {
    //   "departmentName": "口腔",//科室名称 非必填
    //   "departmentType": 1//科室类型编码 非必填
    // }
    app.agriknow2.myHospitaldepartmentList({
      "hospitalCode": wx.getStorageSync('hosCode'),//医院编码
      departmentName: s,
      departmentType: e.departmentType == 0 ? '' : e.departmentType
    }).then(res => {
      if (res.code === 0) {
        var list = res.page.list,arr = [],cc=[];
        for(let i in list){  //获取科室分类长度
          if (cc.indexOf(list[i].departmentType) < 0){
            cc.push(list[i].departmentType)
            arr.push({
              type: list[i].departmentType,
              name: list[i].departmentName,
              list:[]
            })
          }
        }
       
        for(let i in arr){
          for(let j in list){
            if (list[j].departmentType == arr[i].type){
              arr[i].list.push(list[j])
            }
          }
        }
        that.setData({
          hospital1 : arr
        })
      }else{
        that.toastSetWay('', res.msg, true)
      }
    })
  },

  // 科室选择
  bindPickerChange1(e) {
    console.log(this.data.keshiList[e.detail.value])
    this.setData({
      keshiIdx: e.detail.value
    })
    this.keshiApi(this.data.keshiList[e.detail.value], this.data.keyword)
  },


  returnBtn() {
    wx.navigateBack({ //返回
      delta: 1
    })
  },
  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({ toastTitle: title, toastInfo: info, toastIsStu: true });
    var time = setInterval(function () {
      that.setData({ toastTitle: title, toastInfo: info, toastIsStu: false });
      clearInterval(time);
    }, 3000);
  },
 

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})