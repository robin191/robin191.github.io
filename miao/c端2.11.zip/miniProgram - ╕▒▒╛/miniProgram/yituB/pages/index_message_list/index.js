// pages/message_list/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
//     EVENT_TYPE_PATIENT_INFO  患者信息模板      
//  EVENT_TYPE_IMAGE_UPLOAD  图片上传模板       
// EVENT_TYPE_SCHEDULE_TEMPELE  设定日程模板
//  EVENT_TYPE_FILE_UPLOAD  文件上传模板 
// EVENT_TYPE_VIDEO_UOLOAD 视频上传模板 
// EVENT_TYPE_SET_TIME  设定时间模板 
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '医好康', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    eventArr:[
      'EVENT_TYPE_PATIENT_INFO',      
      'EVENT_TYPE_IMAGE_UPLOAD',   
      'EVENT_TYPE_SCHEDULE_TEMPELE',   
      'EVENT_TYPE_FILE_UPLOAD',    
      'EVENT_TYPE_VIDEO_UOLOAD',   
      'EVENT_TYPE_SET_TIME',    
    ],

    projectStatu:1, // 是否有项目   1 有 -1 无
    messageList: [
      // {stu:'1', time: '9月', times: '09.10 14:00',tltle:'确定会诊具体时间', info:'李医生，需要麻烦您去顶一下关于王建的会诊时间。'},
      // { stu: '2', time: '8月', times: '09.10 12:00', tltle: '今日待办',  info: '购买一张周六去绍兴的火车票' },
      // { stu: '1', time: '5月', times: '09.10 04:00', tltle: '向您推荐了一名患者',  info: '王贤明医生向您推荐了一名患者。' },
      // { stu: '3', time: '9月', times: '09.10 24:00', tltle: '准备相关资料', info: '请准备一份心脏病的资料' },
      // { stu: '4', time: '9月', times: '09.10 24:00', tltle: '欢迎来到医好康',  info: '请准备一份心脏病的资料' },
      ],



    text: "欢迎您登录到医好康。我们专注于为医疗机构提供2B2C...",
    step: 1, //滚动速度
    distance: 0, //初始滚动距离
    space: 30,
    interval: 20, // 时间间隔

    nowPage:1,
    hasData:-1, // -1 初始化   1 有数据  0 无数据
    isLoading:-1, // -1 初始化   1 加载    0 隐藏
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      noshow: wx.getStorageSync('noshow')
    })
    if (!wx.getStorageSync('userInfoPho')) { // 当缓存清除之后，重写进行登录
      wx.reLaunch({
        url: '../user-login/index',
      })
    }
   
  
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.oneWay(); // 获取信息列表
    // this.fontScrollling();// 字幕滚动
    
    // this.getHighestRoleLevelByUserCode(); // 医生角色权限 
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    // 显示顶部刷新图标  
    wx.showNavigationBarLoading();  
    this.oneWay('pull');
  },

  // 第一次加载
  oneWay(type){
    this.setData({ nowPage: 1 });
    let that = this;
    let params = {
      "page": that.data.nowPage + '',
      "limit": "10",
      "isRead": 0
    };
    app.agriknow2.listMessage(params, 'noloading').then(res => {
      if (type === 'pull'){
        // 隐藏导航栏加载框  
        wx.hideNavigationBarLoading();
        // 停止下拉动作  
        wx.stopPullDownRefresh();
      }
      if (res.code === 0) {
        let data = res.page.list;
        if (data.length >= 1) {
          that.setData({ projectStatu: 1});
        } else {
          that.setData({ projectStatu: -1});
        }
        if (data.length >= 10) {
          that.setData({ hasData: 1 });
        } else {
          that.setData({ hasData: -1, nowPage: that.data.nowPage + 1,});
        }
        for (var item in data) {
          let time = data[item].createTime ? data[item].createTime.substring(5, 7) : data[item].createTime;
          data[item].data1 = time;
          data[item].createTime = data[item].createTime ? data[item].createTime.substring(5, 16) : data[item].createTime
        }
        that.setData({ messageList: data })
      }
    })
  },


  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.hasData == 1){
      this.listMessage(); // 获取信息列表
    }
  },



  // 信息列表 未读
  listMessage() {
    let that = this;
    let params = {
      "page": that.data.nowPage +'',
      "limit": "10",
      "isRead": 0
    };
    that.setData({ isLoading: 1 });
    app.agriknow2.listMessage(params).then(res => {
      that.setData({ isLoading: 0 });
      if (res.code === 0) {
        let data = res.page.list;
        if (data.length < 10) {
          that.setData({ hasData: 0 });
        } else {
          that.setData({ hasData: 1, nowPage: that.data.nowPage + 1, });
        }
        for(var item in data){
          let time = data[item].createTime ? data[item].createTime.substring(5, 7) : data[item].createTime;
          data[item].data1 = time;
          data[item].createTime = data[item].createTime ? data[item].createTime.substring(5, 16) : data[item].createTime
        }
        that.setData({ messageList: that.data.messageList.concat(data) })
      }
    })
  },

  // 进入详情
  checkDetail(e) {
    let item = e.currentTarget.dataset.item;
    let stu = e.currentTarget.dataset.messageType;
    let url = '../index_message_detail/index?info=' + JSON.stringify(item); // 系统消息 推荐


    if (stu === 1) { // 事件详情
      if (item.messageSubclass == this.data.eventArr[0]) { // 患者信息模板 
        url = '../index_message_detail_incident_huanzhe/index?info=' + JSON.stringify(item);
      } else if (item.messageSubclass == this.data.eventArr[1]) { // 图片上传模板  
        url = '../index_message_detail_incident_img/index?info=' + JSON.stringify(item);
      } else if (item.messageSubclass == this.data.eventArr[2]) { // 设定日程模板
        url = '../index_message_detail_incident_schedule/index?info=' + JSON.stringify(item);
      } else if (item.messageSubclass == this.data.eventArr[3]) { // 文件上传模板 
        url = '../index_message_detail_incident_file/index?info=' + JSON.stringify(item);
      } else if (item.messageSubclass == this.data.eventArr[4]) { // 视频上传模板 
        url = '../index_message_detail_incident_video2/index?info=' + JSON.stringify(item);
      } else if (item.messageSubclass == this.data.eventArr[5]) { // 设定时间模板 
        url = '../index_message_detail_incident_schedule/index?info=' + JSON.stringify(item);
      }

    } else if (stu === 3) { // 日程
      url = '../index_message_detail_incident_check/index'
    }
    wx.navigateTo({
      url: url,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  // // 医生角色权限 
  // getHighestRoleLevelByUserCode() {
  //   let that = this;
  //   app.agriknow2.getHighestRoleLevelByUserCode('','noloading').then(res => {
  //     if (res.code === 0) {
  //       let data = res.doctorHospitalRelation;
  //       wx.setStorageSync('hosCode', data.hospitalCode); // 医院code
  //       wx.setStorageSync('docCode', data.doctorCode); // 医生code
  //       wx.setStorageSync('roleLevel', data.roleLevel); // 权限
  //       wx.setStorageSync('docInfo', data.roleCode)

  //       // 超级管理员 管理员 没有患者推荐功能
  //       // 导诊员  只有 推荐患者 推荐报表
  //       // 普通医生没有管理权限
  //       // 诊所，没有科室管理

  //       // 医院角色 - 超级管理员 HOSPITAL_ROLE_SUPER_ADMIN
  //       // 医院角色-管理员 HOSPITAL_ROLE_ADMIN
  //       // 医院角色-导诊员HOSPITAL_ROLE_GUIDE
  //       // 医院角色-医生 HOSPITAL_ROLE_DOCTOR

  //       // 诊所角色-超级管理员 CLINIC_ROLE_SUPER_ADMIN
  //       // 诊所角色-管理员 CLINIC_ROLE_ADMIN
  //       // 诊所角色-医生 CLINIC_ROLE_DOCTOR

  //     }
  //   })
  // },

  // 走马灯
  fontScrollling(){
    // 滚动字幕 开始
    var that = this;
    var query = wx.createSelectorQuery();
    //选择id
    query.select('#mjltest').boundingClientRect()
    query.exec(function (res) {
      var length = res[0].width;
      var windowWidth = wx.getSystemInfoSync().windowWidth; // 屏幕宽度

      that.setData({
        length: length,
        windowWidth: windowWidth,
        space: windowWidth
      });
      that.scrollling(); // 第一个字消失后立即从右边出现
    });
     // 滚动字幕 结束
  },



  // 去详情
  toDetailBtn(e){
    let stu = e.currentTarget.dataset.stu;
    let url = '../index_message_detail/index'
    if (stu === '4') {
      url = '../index_message_detail_incident/index'
    } else if(stu === '3') {
      url = '../index_message_detail_incident_check/index'
    }
    wx.navigateTo({
      url: url,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  // 查看所有信息
  checkAll(){
    wx.navigateTo({
      url: '../index_message_list_all/index',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },

  scrollling: function () {
    var that = this;
    var length = that.data.length; //滚动文字的宽度
    var windowWidth = that.data.windowWidth; //屏幕宽度
    var interval = setInterval(function () {
      var maxscrollwidth = length + that.data.space;
      var left = that.data.distance;
      if (left < maxscrollwidth) { //判断是否滚动到最大宽度
        that.setData({
          distance: left + that.data.step
        })
      } else {
        that.setData({
          distance: 0 // 直接重新滚动
        });
        clearInterval(interval);
        that.scrollling();
      }
    }, that.data.interval);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
