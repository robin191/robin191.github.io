// miniprogram/pages/project_list_detail_ memo_add/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '查看信息', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    saoNoUser:1, // 1 显示  0 隐藏
    mobelStu: 0,  // 输入手机号  1 弹  0 隐藏
    messageInfo:undefined,
    // messageInfo: { stu: '4', time: '9月', times: '09.10 14:00', tltle: '欢迎来到医好康', info: '欢迎您登录到医好康。外面专注于为医疗机构提供2B2C的SAAS系统服务，协助医疗机构进行专家资源管理、医疗服务过程管理、病患关系管理。如果您对产品有任何建议，可以到我的“意见反馈”中提交信息。谢谢'},
    messageInfo2: { stu: '3', time: '10月', times: '09.10 14:00', tltle: '确定会诊具体时间',title2: '绍兴会诊项目',shijian:{name:'确定会诊具体时间', ren:'张芳芳', ren2:'李合法',memo:'李医生，需要麻烦您确定一下关于王建的会诊时间。李医生，需要麻烦您确定一下关注王建的会诊时间。' } },
  
    memoList:[
      {name:'阿发放',info:'发发士大夫四大所发生的',time:'14:30'},
      { name: '阿发放', info: '发发士大夫四大所发生的', time: '14:30' },
      { name: '阿发放', info: '发发士大夫四大所发生的', time: '14:30' },
      { name: '阿发放', info: '发发士大夫四大所发生的', time: '14:30' },
    ], // 移交与备注列表
    memoIndex:1,
    index2: 0,
    time: '请选择具体时间',


    userList: [
      { img:'../../images/xiangmu/huanzhe.jpg',stu:0, name:'张三'},
      { img: '../../images/xiangmu/huanzhe.jpg', stu: 1, name: '李发' },
      { img: '../../images/xiangmu/huanzhe.jpg', stu: 1, name: '网店' },
      { img: '../../images/xiangmu/huanzhe.jpg', stu: 0, name: '大幅度' },

      ],


    removeProStuMemo: 0, // 添加备注
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  // 新增事件
  addProjectBtn() {
    wx.navigateTo({ url: '../project_add_incident/index' }); // 跳转到售票页面
  },

  // 打开备注窗口
  opeanMemoBtn() {
    this.setData({ removeProStuMemo: 1 });
  },

  // 关闭备注窗口
  closeMemoBtn() {
    this.setData({ removeProStuMemo: 0 });
  },


  // 时间选择
  bindTimeChange(e) {
    this.setData({
      time: e.detail.value
    })
  },

  // 打开移交窗口
  opeanMobelBtn() {
    this.setData({ mobelStu: 1 });
  },

  // 关闭移交窗口
  closeMobelBtn() {
    this.setData({ mobelStu: 0 });
    wx.reLaunch({
      url: '../index_message_list/index',
    })
  },

  // 确认到诊
  toDetailDiagonsis(){
    wx.navigateTo({
      url: '../index_message_detail_diagnosis/index',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})