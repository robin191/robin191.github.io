// miniprogram/pages/user-detail/userdetail.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 0, //是否显示左上角图标   1表示显示    0表示不显示
      title: '管理', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,
    userInfo: {},
    hasUserInfo: undefined,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    windowHeight: wx.getSystemInfoSync().windowHeight + 50,
    nowUserInfo: { 
      'balance':0,
      'cardName':'普通卡',
      'cardNo':'0',
      'cardType':1,
      'idNo':'',
      'userName':'jj',
      'phoneNumber':''
    },
    phoneNumber:'',
    hasUserInfo: {},
  },

  // 用户信息页面
  userDetail(){
    wx.navigateTo({ url: '../user_use_add/index' }); // 患者信息
  },
  onLoad:function(){
    this.setData({
      noshow: wx.getStorageSync('noshow')
    })
    let userInfo = JSON.parse(wx.getStorageSync('userInfoPho') );
    this.setData({ hasUserInfo: userInfo});
    this.initWay();
  },
 
  /**
   * 生命周期函数--监听页面加载
   */
  onShow: function (options) {

    let roleCode = wx.getStorageSync('docInfo')

    this.setData({
      roleCode: roleCode
    })

    // this.userIsRegister();
    console.log('========', app.globalData);
    if (app.globalData.userInfo) {
      this.setData({
        hasUserInfo: app.globalData.userInfo,
      })

    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      // app.userInfoReadyCallback = res => {
      //   this.setData({
      //     userInfo: res.userInfo,
      //     hasUserInfo: true
      //   })
      // }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      // wx.getUserInfo({
      //   success: res => {
      //     app.globalData.userInfo = res.userInfo
      //     this.setData({
      //       userInfo: res.userInfo,
      //       hasUserInfo: true
      //     })
      //   }
      // })
    }
    this.initWay();
  },

  getUserInfoWays(){
    wx.getUserInfo({
      success: function (res) {
        console.log(res);
        // var avatarUrl = 'userInfo.avatarUrl';
        // var nickName = 'userInfo.nickName';
        // that.setData({
        //   [avatarUrl]: res.userInfo.avatarUrl,
        //   [nickName]: res.userInfo.nickName,
        // })
      }
    })
  },

  onGotUserInfo: function (e) {
    this.setData({ hasUserInfo: e.detail.userInfo});
    app.globalData.userInfo = e.detail.userInfo;
    console.log(e.detail.errMsg)
    console.log(e.detail.userInfo)
    console.log(e.detail.rawData)
  },

  
  // 绑定手机号
  toUserPhone(){
    wx.navigateTo({
      url: '../user_register/index',
    })
  },
  // 获取用户是否注册过
  userIsRegister(){
    var that = this;
    var data = { companyId: wx.getStorageSync("companyId"), openId: wx.getStorageSync("userOpenId")};
      app.agriknow2.userIsRegister(data).then(res => {
        if (res.code == 0) {
          that.setData({ phoneNumber: res.content});
          wx.getStorageSync({ key: 'userPhone',data: res.content,})
        } else {
        }
      }).catch(err => { // 数据请求失败;
      });
  },

  // 初始化数据
  initWay() {
   
    // this.getUserInfoWay();

  },

  // 获取当前用户信息
  getUserInfoWay() {
    var that = this;
    wx.login({
      success(res) {
        if (res.code) {
          // var data = { companyId: app.agriknow._companyId, code: res.code };
          // app.agriknow.getuserinfoApi(data).then(res => {
          //   var data = JSON.parse(res.content);
          //   that.setData({ nowUserInfo: JSON.parse(res.content) })
          //   that.setData({
          //     ['nowUserInfo.balance']: data.balance,
          //     ['nowUserInfo.cardName']: data.cardName,
          //     ['nowUserInfo.cardNo']: data.cardNo,
          //     ['nowUserInfo.cardType']: data.cardType,
          //     ['nowUserInfo.idNo']: data.idNo,
          //     ['nowUserInfo.userName']: data.userName
          //   });
          // }).catch(err => { // 数据请求失败;

          // });
        }
      }
    });
  },

  toTickets(){
    app.ticketsSelIdx = 1;
    // wx.switchTab({
    //   url: '../ticketsDetail/index'  
    // }); 
  },

  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '浦江行',
      path: 'pages/i_sel_site/index1',
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  },

  // 获取用户信息
  getUserInfoInit() {
    console.log('获取用户信息')
    wx.getUserInfo({
      success: res => {
        app.globalData.userInfo = res.userInfo
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },

  getUserInfo: function (e) {
    app.globalData.userInfo = e.detail.userInfo;
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },

})