const app = getApp()
Component({
  data: {
    selected: app.tabSelIdx,
    color: "#7A7E83",
    selectedColor: "#08b2c1",

    list: [
      {
        "pagePath": "/pages/i_sel_site/index1",
        "text": "购票",
        "iconPath": "../images/price012.png",
        "selectedIconPath": "../images/price011.png"
      },
      {
        "pagePath": "/pages/ticketsDetail/index",
        "text": "验票",
        "iconPath": "../images/tablist012.png",
        "selectedIconPath": "../images/tablist011.png"
      },
      {
        "pagePath": "/pages/user-detail/userdetail",
        "text": "我的",
        "iconPath": "../images/my011.png",
        "selectedIconPath": "../images/my012.png"
      }
    ]
  },
  attached() {
    console.log('========')
    this.setData({ selected: app.tabSelIdx})
  },
  
  methods: {
    switchTab(e) {
      const data = e.currentTarget.dataset
      app.tabSelIdx = data.index;
      // this.setData({
      //   selected: data.index
      // })
     
      const url = data.path
      wx.switchTab({ url })
      

    }
  }
},

)