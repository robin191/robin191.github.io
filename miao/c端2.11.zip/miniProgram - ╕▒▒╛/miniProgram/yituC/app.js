
import agriknow2 from './apis/agriknow2.js'
const updateManager = wx.getUpdateManager()

updateManager.onCheckForUpdate(function (res) {
  // 请求完新版本信息的回调
  console.log('res.hasUpdate----',res.hasUpdate)
})


updateManager.onUpdateReady(function () {
  // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
  wx.showModal({
    title: '更新提示',
    content: '新版本已经准备好，是否重启应用？',
    success: function (res) {
      if (res.confirm) {        // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
        updateManager.applyUpdate()
      }
    }
  })
  // updateManager.applyUpdate()
})

updateManager.onUpdateFailed(function () {
  // 新的版本下载失败
})

App({
  onLaunch: function (options) {
    // 判断是否由分享进入小程序
    if (options.scene == 1007 || options.scene == 1008) {
      this.globalData.share = true
    } else {
      this.globalData.share = false
    };
    //获取设备顶部窗口的高度（不同设备窗口高度不一样，根据这个来设置自定义导航栏的高度）
    //这个最初我是在组件中获取，但是出现了一个问题，当第一次进入小程序时导航栏会把
    //页面内容盖住一部分,当打开调试重新进入时就没有问题，这个问题弄得我是莫名其妙
    //虽然最后解决了，但是花费了不少时间
    wx.getSystemInfo({
      success: (res) => {
        console.log(res)
        console.log('高度-------------', res.statusBarHeight)
        this.globalDatas.height = res.statusBarHeight;
        this.globalDatas.wheight = res.windowHeight - (res.statusBarHeight*2 + 20) ;
      }
    })

    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        traceUser: true,
      })
    }
    this.globalData = {}
  },

  globalDatas: {
    share: false,  // 分享默认为false
    height: 0,
  },

  // 新建项目开始
  createProInfo: { proInfo:{}, huanzhe:{},  selHospitalInfo: {}, selGuanli: [], selDoc: [] }, // 创建项目时的变量 selHospitalInfo 医院 selGuanli 管理者 selDoc 医生
  createProIncident: { executor: [] }, // 创建事件 executor 执行人
  projectCode:'P-001', // 项目id
  getProjectInfo: {}, // code  创建事件需要的参数 // 项目添加成功之后返回的数据
 // 新建项目结束

 // 列表调转入 详情页 
  projectCode:'YY0020023',
  projectInfos: { projectCode:'YY0020027'}, // 项目id  'YY0020027'
 
 // 项目文档
  projectCodeFile: "YY0020027",

  // 备忘录
  projectCodeMemo:'YY0020027',
  memoInfo:{}, // 备忘录修改时的信息

  // 推荐患者
  tuijianPatients: { huanzhe: {}, zhensuo: {}, doctor: {}, yiyuan: {}, keshi: {} }, // 推荐患者信息 用户模块的 
  managetTuijianPatients: { huanzhe: {}, zhensuo: {}, doctor: {} }, //管理模块的 推荐患者信息


  // 我的 个人中心
  hospitalRole:'', // 医院

  // 我的 个人信息
  userDetailInfo: { yiyuan: {}, keshi: {}, zhichen:{}},

  globalData: {}, // 用户信息

  agriknow2: new agriknow2(),

  addKeshiDoctor:[],
  
  
  sFtv :[
    {
      month: 1,
      day: 1,
      name: "元旦"
    },
    {
      month: 2,
      day: 14,
      name: "情人"
    },
    {
      month: 3,
      day: 8,
      name: "妇女"
    },
    {
      month: 3,
      day: 12,
      name: "植树"
    },
    {
      month: 3,
      day: 15,
      name: "消费者权益日"
    },
    {
      month: 4,
      day: 1,
      name: "愚人"
    },
    {
      month: 5,
      day: 1,
      name: "劳动"
    },
    {
      month: 5,
      day: 4,
      name: "青年"
    },
    {
      month: 5,
      day: 12,
      name: "护士"
    },
    {
      month: 6,
      day: 1,
      name: "儿童"
    },
    {
      month: 7,
      day: 1,
      name: "建党"
    },
    {
      month: 8,
      day: 1,
      name: "建军"
    },
    {
      month: 9,
      day: 10,
      name: "教师"
    },
    {
      month: 9,
      day: 28,
      name: "孔子诞辰"
    },
    {
      month: 10,
      day: 1,
      name: "国庆"
    },
    {
      month: 10,
      day: 6,
      name: "老人"
    },
    {
      month: 10,
      day: 24,
      name: "联合国日"
    },
    {
      month: 12,
      day: 24,
      name: "平安夜"
    },
    {
      month: 12,
      day: 25,
      name: "圣诞"
    }
  ],
 
})
