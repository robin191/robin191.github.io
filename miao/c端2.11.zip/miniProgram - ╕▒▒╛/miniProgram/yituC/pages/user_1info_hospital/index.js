// miniprogram/pages/user_1info_hospital/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '我的医院', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20, 

    tabList: [
      { name: '所有医院', val: 0 },
      { name: '项目医院', val: 1 },
      { name: '推荐医院', val: 1 },
    ], // tab选项
    tabIndex:0,
    
    hospital1:[],
    hospital2:[],
    hospital3:[],
    nowPage:1,
    messageList:[],

    nowPage: 1,
    hasData: -1, // -1 初始化   1 有数据  0 无数据
    isLoading: -1, // -1 初始化   1 加载    0 隐藏
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.oneWay();
    // this.queryAllHospitalHos(); // 所有
    // this.queryRecomendHospitalHos(); // 我的-正在合作中的医院 api
    // this.queryProjectHospitalHos(); // 我的-历史合作的医院 api
    
  },

  /**
  * 页面相关事件处理函数--监听用户下拉动作
  */
  onPullDownRefresh: function () {
    // 显示顶部刷新图标  
    wx.showNavigationBarLoading();
    this.oneWay('pull');
  },

  /**
 * 页面上拉触底事件的处理函数
 */
  onReachBottom: function () {
    if (this.data.hasData == 1) {
      this.listMessage(); // 获取信息列表
    }
  },

  // 第一次加载 医院信息
  oneWay(type) {
    this.setData({ nowPage: 1 });
    let that = this;
    let params = {
      "page": that.data.nowPage + '',
      "limit": "10"
    };
    app.agriknow2.queryRecomendHospitalHos(params, that.data.tabIndex).then(res => {
      if (type === 'pull') {
        // 隐藏导航栏加载框  
        wx.hideNavigationBarLoading();
        // 停止下拉动作  
        wx.stopPullDownRefresh();
      }
      if (res.code === 0) {
        let data = res.page.list;
        if (data.length >= 1) {
          that.setData({ projectStatu: 1 });
        } else {
          that.setData({ projectStatu: -1 });
        }
        if (data.length >= 10) {
          that.setData({ hasData: 1 });
        } else {
          that.setData({ hasData: -1, nowPage: that.data.nowPage + 1, });
        }
        for (var item in data) {
          let time = data[item].createTime ? data[item].createTime.substring(5, 7) : data[item].createTime;
          data[item].data1 = time;
          data[item].createTime = data[item].createTime ? data[item].createTime.substring(5, 16) : data[item].createTime
        }
        that.setData({ messageList: data })
      }
    })
  },






  // 医院信息 
  listMessage() {
    let that = this;
    let params = {
      "page": that.data.nowPage + '',
      "limit": "10"
    };
    that.setData({ isLoading: 1 });
    app.agriknow2.queryRecomendHospitalHos(params, that.data.tabIndex).then(res => {
      that.setData({ isLoading: 0 });
      if (res.code === 0) {
        let data = res.page.list;
        if (data.length < 10) {
          that.setData({ hasData: 0 });
        } else {
          that.setData({ hasData: 1, nowPage: that.data.nowPage + 1, });
        }
        for (var item in data) {
          let time = data[item].createTime ? data[item].createTime.substring(5, 7) : data[item].createTime;
          data[item].data1 = time;
          data[item].createTime = data[item].createTime ? data[item].createTime.substring(5, 16) : data[item].createTime
        }
        that.setData({ messageList: that.data.messageList.concat(data) })
      }
    })
  },


  // 我的医院-推荐医院 api
  queryRecomendHospitalHos() {
    let that = this;
    let params = { page: that.data.nowPage + '', "limit": "10",}
    app.agriknow2.queryRecomendHospitalHos({}).then(res => {
      if (res.code === 0) {
        that.setData({ hospital1: res.myCooperationHospitaList});
      }
    })
  },

  //我的-我的医院-项目医院 api
  queryProjectHospitalHos() {
    let that = this;
    app.agriknow2.queryProjectHospitalHos({}).then(res => {
      if (res.code === 0) {
        that.setData({ hospital2: res.myHistoryHospitaList });
      }
    })
  },

  //我的医院-所有医院 api
  queryAllHospitalHos() {
    let that = this;
    app.agriknow2.queryAllHospitalHos({}).then(res => {
      if (res.code === 0) {
        that.setData({ hospital3: res.myHistoryHospitaList });
      }
    })
  },


  // 查看医院信息
  toHospitalDetail(e){
    let hospitalCode = e.currentTarget.dataset.item.hospitalCode;
    wx.navigateTo({ url: '../user_1info_hospital_info/index?hospitalCode=' + hospitalCode }); // 医院信息
  },

  // 标题选择
  selTypeLine(e) {
    this.setData({ tabIndex: e.currentTarget.dataset.idx });
    this.oneWay();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
      * 用户点击右上角分享
      */
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '医好康',
      path: 'pages/index_message_list/index',
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  },
})