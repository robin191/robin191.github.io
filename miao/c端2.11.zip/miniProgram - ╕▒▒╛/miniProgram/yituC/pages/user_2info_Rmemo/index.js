// miniprogram/pages/user_1info_hospital/index.js
const app = getApp();
var uploadImage = require('../../utils/uploadFile.js');
var util = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '意见反馈', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20, 
    address:'',
    imgUrl:[]

  },
  setUserName(e){
    this.setData({
      address:e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  updloadWay1: function () {
    var nowTime = util.formatTime(new Date());
    let data = this.data.imgUrl;
    let that = this;
    let arr = [], n = -1
    for (var item in data) {
      let typeArr = data[item].split('.');
      let type = typeArr[typeArr.length - 2] + '.' + typeArr[typeArr.length - 1];
      console.log(item, data.length)
      uploadImage(type, data[item], 'img/' + nowTime + '/',
        function (result) {
          arr.push(result)
          n++;
          console.log(item, data.length - 1, n)
          if (item == data.length - 1 && item == n) {
            that.uploadImageTemplateWay(arr); // 保存到数据库
          }
        }, function (result) {
        }
      )
    }
  },
  // 保存到数据库
  uploadImageTemplateWay: function (result, item) {
    console.log(result)
    var that = this;
    let params = []
    for (var i in result) {
      var namearr = result[i].split('/');
      var name = namearr[namearr.length - 1];

      var data = {

        // "createBy": "o7buL5SNEZs6hmgPv12f-tCAvaT4",
        // "createTime": '',
        // "deleteFlag": 1,
        "fileName": name,
        "path": result[i]


        // "fileName": name,
        // "path": result[i],
        // "size": 300
      };
      params.push(data);
    }
    let d = {
      "problem": this.data.address,
      "imgUrlList": params
    }
    console.log(params)
    app.agriknow2.uploadFeedback(d, 'noloading').then(res => {
      if (res.code === 0) {
        wx.showToast({
          title: '反馈成功',
          icon: 'none'
        })
        setTimeout(function () {
          wx.navigateBack({

          })
        }, 1500)
      }else{
        wx.showToast({
          title: res.msg,
          icon:'none'
        })
      }
    })
  },

  add_pho(){
    let that = this
    console.log(this.data.imgUrl.length)
    if (this.data.imgUrl.length >= 9) {
      wx.showToast({
        title: '最多上传九张',
        icon: 'none'
      })
      return false;
    }
    wx.chooseImage({
      count: 9 - this.data.imgUrl.length,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function(res) {
        console.log(res)
        that.setData({
          imgUrl: that.data.imgUrl.concat(res.tempFilePaths)
        });
      },
    })
  },
  deleteImg(e){
    let that =this,imglist = this.data.imgUrl
    wx.showModal({
      title: '提示',
      content: '您要删除这张图片吗?',
      success(res){
        if(res.confirm){
          imglist.splice(e.currentTarget.dataset.index,1)
          that.setData({
            imgUrl:imglist
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  // 图片放大
  previewImage: function (e) {
    wx.previewImage({
      current: e.currentTarget.id, // 当前显示图片的http链接
      urls: this.data.imgUrl // 需要预览的图片http链接列表
    })
  },

 

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
      * 用户点击右上角分享
      */
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '医好康',
      path: 'pages/index_message_list/index',
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  },
})