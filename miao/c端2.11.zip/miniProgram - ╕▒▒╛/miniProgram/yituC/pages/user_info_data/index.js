// miniprogram/pages/user_order_list/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '完善个人信息', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20, 
    userInfo: { userName:'', idNumber:''},

    userNameStu: true,//昵称
    idNumberStu: true,//身份证

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },


  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  // 身份证
  idNumberBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name !== '' && name.length === 18) {
      that.setData({ idNumberStu: true })
    } else {
      that.setData({ idNumberStu: false })
    }
    that.setData({
      ['userInfo.idNumber']: name,
    })
  },

  // 姓名
  userNameBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name.length > 1 && name.length < 15) {
      that.setData({ userNameStu: true })
    } else {
      that.setData({ userNameStu: false })
    }
    that.setData({
      ['userInfo.userName']: name,
    })
  },


  // 个人信息 修改api
  updateMyDoctorInfo() {
    let that = this;
    if (that.data.userInfo.userName.length <= 1 || that.data.userInfo.userName.length > 15) {
      wx.showToast({
        title: '请填写用户姓名(15个字符)',
        icon: 'none'
      })
      return;
    }
    if (!phoneRegWay(that.data.userInfo.idNumber)) {
      return;
    }
    
    let params = { userName: that.data.userInfo.userName, idCardNo: that.data.userInfo.idNumber};
    app.agriknow2.perfectClientInfo(params).then(res => {
      if (res.code == 0) {
        wx.setStorageSync('openId', res.data.openId)
        wx.showToast({
          title: '添加成功',
          icon: 'none'
        })
        setTimeout(function () {
          wx.reLaunch({
            url: '../index_message_list/index',
          })
        }, 1500)

       
      }else{
        wx.showToast({
          title: res.msg,
          icon:'none'
        })
      }
    })
  },

 
  
  // 显示加载动画
  showLoading: function () {
    wx.showLoading({
      title: '加载中...',
      icon: 'loading'
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },



  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
      * 用户点击右上角分享
      */
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '医好康',
      path: 'pages/index_message_list/index',
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  },
})

/**
*  身份证验证
*/
function phoneRegWay(phone) {
  if (phone == null || phone == '') {
    showToastWay('请输入身份证')
    return false;
  }
  var reg = /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/;
  if (!reg.test(phone)) {
    showToastWay('请输入有效身份证！')
    return false;
  }
  return true;
}

/**
 * 提示框
 */
function showToastWay(msg) {
  wx.showToast({
    title: msg,
    icon: 'none',
    duration: 1500
  })
}