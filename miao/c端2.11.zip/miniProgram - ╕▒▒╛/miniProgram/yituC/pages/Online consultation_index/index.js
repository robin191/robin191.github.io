// pages/Online consultation/Online_consultation_index.js
const plugin = requirePlugin("WechatSI")
const manager = plugin.getRecordRecognitionManager();  
Page({
  
  /**
   * 页面的初始数据
   */
  data: {
    Height: "0px",
    scrollHeight: "0px",
    isDown: false,
    problem: "",
    voiceState: "",
    photosList: [],
    current: 0,
    isShowPhoto: false,

    hospitalInfo: {},
    hideFlag: true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options, "跳转带参");
    this.initRecord()
    uni.$on("onCheckedHospital", (backRes) => {
      console.log(backRes);
      this.hospitalInfo = backRes || {};
    })
  },

  onDownBT() {
    console.log("down");
    this.isDown = true;
    manager.start({
      duration: 60000,
      lang: "zh_CN"
    });
  },
  onUpBT() {
    console.log("up");
    this.isDown = false;
    uni.showToast({
      title: "正在转译。。。",
      duration: 2000
    })
    manager.stop();
  },
  initRecord() {
    const that = this;
    manager.onStart = function (res) {
      console.log(res, 111111111111)
      that.voiceState = "正在录音"
    };
    //有新的识别内容返回，则会调用此事件  
    manager.onRecognize = (res) => {
      console.log(res, 22222222)
      that.voiceState = res.result;
    }

    // 识别结束事件  
    manager.onStop = (res) => {
      console.log(res, 333333333);
      that.voiceState = "正在录音"

      if (that.problem.length >= 200) {
        uni.showToast({
          title: "文字不能超过200",
          icon: "none",
          duration: 2000,
        });
      } else {
        that.problem = that.problem + res.result;
      }
    }

    // 识别错误事件  
    manager.onError = (res) => {
      wx.showToast({
        title: "网络错误，请重新录入",
        icon: "none",
        duration: 2000
      })

    }
  },
  onCheckHospital() {
    wx.navigateTo({
      url: "/pages/wode/myProblem/mycheckhospital?info=" + JSON.stringify(this.hospitalInfo),
      fail(err) {
        console.log(err)
      }
    })
  },
  onTextareaInput(res) {
    console.log(res, "textarea");
    if (this.problem.length >= 200) {
      wx.nextTick(function () {
        this.problem = res.detail.value.slice(0, 200)
      })
      wx.showToast({
        title: "文字不能超过200",
        icon: "none",
        duration: 2000,
      });
      return
    } else {
      this.problem = res.detail.value;
    }

  },
  onOpenPropup() {
    // 需要在 popup 组件，指定 ref 为 popup
   
  },
  onClosePropup() {
    
  },
  onOpenPhoto(imgSrc, imgIndex) {
    this.isShowPhoto = true;
    this.current = imgIndex;
  },
  onClosePhoto() {
    console.log("guanbi")
    this.isShowPhoto = false;
  },
  onDelete(index) {
    this.photosList.splice(index, 1);
  },
  onOpenCamera() {
    console.log("打开摄像机");
    const that = this;
    wx.chooseImage({
      count: 1,
      sourceType: ['camera'],
      success: (res) => {
        console.log(res, "打开相机");
        // this.photosList.push(res.tempFilePaths);
        uni.uploadFile({
          url: this.$baseUrl + "/app/image/upload",
          filePath: res.tempFilePaths[0],
          name: "file",
          success(uploadFileRes) {
            console.log(uploadFileRes.data);
            let data = JSON.parse(uploadFileRes.data)
            if (data.code === 0) {
              that.photosList.push(data.url)
            }

          },
          fail(err) {
            console.log(err)
          }
        });
        this.onClosePropup()
      }
    })
  },
  onOpenfile() {
    console.log("从手机相册选取");
    const that = this;
    uni.chooseImage({
      count: 1, //默认9
      sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album'], //从相册选择
      success: (res) => {
        uni.uploadFile({
          url: this.$baseUrl + "/app/image/upload",
          filePath: res.tempFilePaths[0],
          name: "file",
          success(uploadFileRes) {
            let data = JSON.parse(uploadFileRes.data)
            if (data.code === 0) {
              that.photosList.push(data.url)
            }
          }
        });
        this.onClosePropup()
      }
    });
  },
  onSave() {
    console.log("save");
    const that = this;
    let files = [];
    for (let item of this.photosList) {
      files.push({
        path: item
      })
    };
    if (!this.hospitalInfo.hospitalCode) {
      uni.showToast({
        title: "请选择医院",
        icon: "none",
        duration: 2000
      })
      return false;
    };
    if (!this.problem) {
      uni.showToast({
        title: "问题描述不能为空",
        icon: "none",
        duration: 2000
      })
      return false;
    };
    let DATA = {
      hospitalCode: this.hospitalInfo.hospitalCode,
      content: this.problem,
      fileList: files
    };
    this.$http_post("/app/problem/submitProblem", { data: DATA })
      .then(res => {
        console.log(res);
        if (res.code === 0) {
          uni.showModal({
            title: "提示",
            content: "发送成功",
            showCancel: false,
            confirmText: "好的",
            success(modalRes) {
              modalRes.confirm && that.onNavBack();
            }
          })
        } else {
          uni.showModal({
            title: "提示",
            content: "网络异常，请稍后重试。",
            showCancel: false,
            confirmText: "好的",
            success(modalRes) {

            }
          })
        }

      }).catch(err => {
        console.log(err)
      })
  },
  onNavBack() {
    uni.navigateBack({
      delta: 1,
      animationType: 'pop-out',
      animationDuration: 200
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})