// miniprogram/pages/login-user/index.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '医好康', //导航栏 中间的标题
    },

    // 此页面 页面内容距最顶部的距离
    height: app.globalDatas.height * 2 + 20,   


    dataStu: 0,
    toastTitle: '',
    toastInfo: '',
    toastIsStu: false,
    hasUserInfo:{},
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // console.log(wx.getStorageSync('userInfo'))
    // console.log(wx.getStorageSync('userInfo'), (!wx.getStorageSync('userInfo')));
    // console.log(wx.getStorageSync('userInfoPho'), (!wx.getStorageSync('userInfoPho')));
    if (!wx.getStorageSync('userInfo')) {
      this.setData({ dataStu: 0 });
    } else if (!wx.getStorageSync('userInfoPho')) {
      this.setData({ dataStu: 1 });
    }
  },

  // 完善个人信息
  toUser(){
    wx.navigateTo({
      url: '../user_info_data/index',
    })
  },
  // 初始化数据
  initWay() {

  },



  // 获取用户微信信息
  getUserInfo: function (e) {
    app.globalData.userInfo = e.detail.userInfo;
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },




  // 根据code获取微信用户的openId等信息
  getAppId(userInfo) {
    var that = this;
    wx.login({
      success: function (res) {
        let code = res.code;
        app.agriknow2.userLogin({ code: code }).then(res => {
          if (res.code === 0) {
            wx.setStorageSync('token', res.token);
            that.getPhoneNumber(userInfo, res.token); // 用户信息解密
          }
        })
      }
    })
  },

  // 获取用户信息
  onGotUserInfo: function (e) {
    var that = this;
    this.setData({ hasUserInfo: e.detail.userInfo });
    app.globalData.userInfo = e.detail.userInfo;
    console.log('=====',e.detail)
    let encryptedData = e.detail.encryptedData;
    let iv = e.detail.iv;
    this.setData({ userInfo: e.detail.userInfo });
    wx.login({
      success: function (res) {
        let code = res.code;
       // 登录 获取 token
        app.agriknow2.userLogin({ code: code }).then(res => {
          let token = res.token;
          let sessionId = res.sessionId;
          if (res.code === 0) {
            wx.setStorageSync('token', res.token); 
            app.agriknow2._defaultHeaderToken.token = token;
            app.agriknow2._urlencodedToken.token = token;
             // 解析用户信息
            app.agriknow2.userAdd({ userInfo: encryptedData, userInfoIv: iv }, token).then(res => {
              if(res.code == 0){
                wx.setStorageSync('userInfo', JSON.stringify(res.data));
                that.setData({ dataStu: 1 });
              }else{
                wx.showToast({
                  title: res.msg,
                  icon: 'none'
                })
              }
            })
          }
        })
      }
    })
  },


  // 获取用户手机号 手机号
  getPhoneNumber: function (e, token) {
    var that = this;
    if (e.detail.errMsg == 'getPhoneNumber:ok') {
      var iv = e.detail.iv;
      var encryptedData = e.detail.encryptedData;
      app.agriknow2.usergetPhoneNumber({ encryptedData: encryptedData, iv: iv }).then(res => {
        wx.setStorageSync('userInfoPho', JSON.stringify(res.data));
        if(res.code == 0){
          // wx.reLaunch({
          //   url: '../index_message_list/index',
          // })
          that.checkPersonInfo(); // 检查个人信息是否完善

        }else{
          wx.showToast({
            title: res.msg,
            icon: 'none'
          })
        }
       
      })
    }
  },


  // 检查个人信息是否完善
  checkPersonInfo() {
    let that = this;
    app.agriknow2.checkPersonInfo().then(res => {
      if (res.code === 0) {
        if (res.data){
          that.queryPersonalInformation();
          
        }else{
          wx.navigateTo({
            url: '../user_info_data/index',
          })
        }
      }else{
        wx.showToast({
          title: res.msg,
          icon:'none'
        })
      }
    })
  },


  // 后台获取用户信息
  queryPersonalInformation() {
    let that = this;
    app.agriknow2.queryPersonalInformation().then(res => {
      if (res.code === 0) {
        wx.setStorageSync('openId', res.data.openId)
        wx.reLaunch({
          url: '../index_message_list/index',
        })
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },





  // 获取用户信息
  getUserInfoInit() {
    wx.getUserInfo({
      success: res => {
        console.log('============', res)
        // app.globalData.userInfo = res.userInfo

      }
    })
  },

  // 显示加载动画
  showLoading: function (name) {
    wx.showLoading({
      title: name,
      icon: 'loading'
    })
  },

  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({ toastTitle: title, toastInfo: info, toastIsStu: true });
    var time = setInterval(function () {
      that.setData({ toastTitle: title, toastInfo: info, toastIsStu: false });
      clearInterval(time);
    }, 3000);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
      * 用户点击右上角分享
      */
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '医好康',
      path: 'pages/index_message_list/index',
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  },
})