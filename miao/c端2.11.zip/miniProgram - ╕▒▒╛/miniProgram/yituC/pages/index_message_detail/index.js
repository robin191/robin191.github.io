// miniprogram/pages/project_list_detail_ memo_add/index.js
var QR = require("../../utils/qrcode.js");//绘制二维码工具库
const app = getApp();
const getRatio = () => {

  let w = 0

  wx.getSystemInfo({

    success: function (res) {

      w = res.windowWidth / 375; 
      // 按照750的屏宽

    },

  })

  return w
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '查看信息', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20,

    saoNoUser:1, // 1 显示  0 隐藏
    mobelStu: 0,  // 输入手机号  1 弹  0 隐藏
    messageInfo: { },
    // date1: '11', createTime: '223', subject: '111', content: '3534'
    // messageInfo: { stu: '4', time: '9月', times: '09.10 14:00', tltle: '欢迎来到医好康', info: '欢迎您登录到医好康。外面专注于为医疗机构提供2B2C的SAAS系统服务，协助医疗机构进行专家资源管理、医疗服务过程管理、病患关系管理。如果您对产品有任何建议，可以到我的“意见反馈”中提交信息。谢谢'},
    messageInfo2:1212,
    type:1,

    datasInfo:{},

    isShowAll:true,
    imgUrl:[],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    let datas = JSON.parse(options.info)
    this.setData({ messageInfo: datas, imgUrl: datas.imgUrlList})

    // this.setData({ type: datas.messageType});
    // console.log(datas);
    
    // datas.date1 = datas.createTime ? datas.createTime.substring(5, 7) : datas.createTime;
    this.queryEventMessage(datas);
    this.readMessage(datas);
    this.drawposter();
  },

  /**
 * 页面相关事件处理函数--监听用户下拉动作
 */
  onPullDownRefresh: function () {
    // 显示顶部刷新图标  
    wx.showNavigationBarLoading();
    this.queryEventMessage(this.data.messageInfo);
    this.readMessage(this.data.messageInfo);
    this.drawposter();
    
    // 隐藏导航栏加载框  
    wx.hideNavigationBarLoading();
    // 停止下拉动作  
    wx.stopPullDownRefresh();
  },

  // 图片放大
  previewImage: function (e) {
    console.log(this.data.imgUrl)
    wx.previewImage({
      current: e.currentTarget.id, // 当前显示图片的http链接
      urls: this.data.imgUrl // 需要预览的图片http链接列表
    })
  },

  showAllBtn(){
    this.setData({ isShowAll:false});
  },

  // 事件信息
  queryEventMessage(datas) {
    let that = this;
    let params = {
      eventCode: datas.eventCode
    };
    app.agriknow2.queryEventMessage(params).then(res => {
      if (res.code === 0) {
      }
    })
  },

  // 消息变为已读
  readMessage(datas) {
    let that = this;
    let params = {
      messageID: datas.messageId
    };
    app.agriknow2.readMessagePro111(params).then(res => {
      if (res.code === 0) {
      }
    })
  },

  drawposter() {
    let openId = wx.getStorageSync('openId')
    QR.qrApi.draw('C==' +openId, "myCanvas1", 570 * getRatio() / 2, 570 * getRatio() / 2, null, '')
    // QR.qrApi.draw('B==' + docCode, "myCanvas1", 570 * getRatio() / 2, 570 * getRatio() / 2, null, '')
  },

  // 查看医院信息
  toHosBtn(){
    wx.navigateTo({
      url: '../user_1info_hospital_info/index?hospitalCode=' + this.data.messageInfo.eventCode,
    })

   
  },


  // 删除
  delBtn(){
    
    let that = this;
    wx.showModal({
      title: '提示',
      content: '是否删除此消息吗？',
      success: function (res) {
        if (res.confirm) {
          let params = [that.data.datasInfo.messageId];
          app.agriknow2.deleteMyMessage(params).then(res => {
            if (res.code === 0) {
              wx.showToast({
                title: '删除成功',
                icon: 'none'
              })
              setTimeout(
                wx.navigateBack({
                  data: 1
                }), 3000)

            } else {
              wx.showToast({
                title: res.msg,
              })
            }
          })
        } else if (res.cancel) {
          wx.showToast({
            title: '您已取消',
            icon: 'none'
          })
        }
      }
    });
  },





  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },



  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  /**
     * 用户点击右上角分享
     */
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '医好康',
      path: 'pages/index_message_list/index',
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  }
})