// miniprogram/pages/user-detail/userdetail.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '我的', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20, 
    userInfo: {},
    hasUserInfo: undefined,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    windowHeight: wx.getSystemInfoSync().windowHeight + 50,
    nowUserInfo: {  },
    phoneNumber:'',
    hasUserInfo: {},
  },

  userQRTo() {
    wx.navigateTo({
      url: '../user_add_QR/index',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  // 用户信息页面
  userDetail() {
    wx.navigateTo({ url: '../user_3info_huanzhe_detail/index' }); // 患者信息
  },
  
  toBtn(e){
    let url = e.currentTarget.dataset.info;
    wx.navigateTo({
      url: url,
    })
  },
  onLoad:function(){
    let userInfo = JSON.parse(wx.getStorageSync('userInfoPho') );
    this.setData({ hasUserInfo: userInfo});
    this.initWay();
  },
 
  /**
   * 生命周期函数--监听页面加载
   */
  onShow: function (options) {
    // this.userIsRegister();
    if (app.globalData.userInfo) {
      this.setData({
        hasUserInfo: app.globalData.userInfo,
      })
    } else if (this.data.canIUse) {
    } else {
    }
    this.initWay();
    // this.getMyHomePageUserInfo(); // 我的-个人信息 api
  },

  // 我的-个人信息 api
  getMyHomePageUserInfo() {
    let that = this;
    app.agriknow2.getMyHomePageUserInfo().then(res => {
      if (res.code === 0) {
        let data = res.myHomePageUserInfo;
        that.setData({ ['hasUserInfo.nickName']: data.userName});
        that.setData({ ['hasUserInfo.avatarUrl']: data.avatarUrl });
        app.hospitalRole = res.myHomePageUserInfo.hospitalRole;
        wx.setStorageSync('docInfo', res.myHomePageUserInfo.hospitalRole)
      }
    })
  },

  getUserInfoWays(){
    wx.getUserInfo({
      success: function (res) {
        console.log(res);
        // var avatarUrl = 'userInfo.avatarUrl';
        // var nickName = 'userInfo.nickName';
        // that.setData({
        //   [avatarUrl]: res.userInfo.avatarUrl,
        //   [nickName]: res.userInfo.nickName,
        // })
      }
    })
  },

  onGotUserInfo: function (e) {
    this.setData({ hasUserInfo: e.detail.userInfo});
    app.globalData.userInfo = e.detail.userInfo;
    console.log(e.detail.errMsg)
    console.log(e.detail.userInfo)
    console.log(e.detail.rawData)
  },

  
  // 绑定手机号
  toUserPhone(){
    wx.navigateTo({
      url: '../user_register/index',
    })
  },
  // 获取用户是否注册过
  userIsRegister(){
    var that = this;
    var data = { companyId: wx.getStorageSync("companyId"), openId: wx.getStorageSync("userOpenId")};
      app.agriknow2.userIsRegister(data).then(res => {
        if (res.code == 0) {
          that.setData({ phoneNumber: res.content});
          wx.getStorageSync({ key: 'userPhone',data: res.content,})
        } else {
        }
      }).catch(err => { // 数据请求失败;
      });
  },

  // 初始化数据
  initWay() {
    wx.setNavigationBarTitle({
      title: '用户详情'
    });
    // this.getUserInfoWay();

  },

  // 获取当前用户信息
  getUserInfoWay() {
    var that = this;
    wx.login({
      success(res) {
        if (res.code) {
          // var data = { companyId: app.agriknow._companyId, code: res.code };
          // app.agriknow.getuserinfoApi(data).then(res => {
          //   var data = JSON.parse(res.content);
          //   that.setData({ nowUserInfo: JSON.parse(res.content) })
          //   that.setData({
          //     ['nowUserInfo.balance']: data.balance,
          //     ['nowUserInfo.cardName']: data.cardName,
          //     ['nowUserInfo.cardNo']: data.cardNo,
          //     ['nowUserInfo.cardType']: data.cardType,
          //     ['nowUserInfo.idNo']: data.idNo,
          //     ['nowUserInfo.userName']: data.userName
          //   });
          // }).catch(err => { // 数据请求失败;

          // });
        }
      }
    });
  },

  toTickets(){
    app.ticketsSelIdx = 1;
    // wx.switchTab({
    //   url: '../ticketsDetail/index'  
    // }); 
  },

  /**
     * 用户点击右上角分享
     */
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '医好康',
      path: 'pages/index_message_list/index',
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  },

  // 获取用户信息
  getUserInfoInit() {
    console.log('获取用户信息')
    wx.getUserInfo({
      success: res => {
        app.globalData.userInfo = res.userInfo
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },

  getUserInfo: function (e) {
    app.globalData.userInfo = e.detail.userInfo;
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },

})