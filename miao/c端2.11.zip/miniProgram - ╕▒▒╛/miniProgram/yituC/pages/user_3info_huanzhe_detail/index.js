// miniprogram/pages/user_order_list/index.js
const app = getApp()
var uploadImage = require('../../utils/uploadFile.js');
var util = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {

    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '患者信息', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20, 
    userInfo:{
      nickName:'',
      mobilePhone:'',
      idNumber:'',

    }, // 用户患者信息
    idNumberStu:true,
    userNameStu:true,
    mobilePhoneStu:true,
    imgUrl:undefined,

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.queryPersonalInformation(); // 后台获取用户信息
  },


  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },
  /**
 * 页面相关事件处理函数--监听用户下拉动作
 */
  onPullDownRefresh: function () {
    this.queryPersonalInformation(); // 后台获取用户信息
  },

  // 后台获取用户信息
  queryPersonalInformation() {
    let that = this;
    app.agriknow2.queryPersonalInformation().then(res => {
      if (res.code === 0) {
        if(res.data){
          that.setData({ userInfo: res.data});
        }
        
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },

  // 图片选择
  chooseImage: function (e) {
    var that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        that.setData({
          imgUrl: res.tempFilePaths
        });
      }
    })
  },

  //上传图片 从云服务取到地址
  updloadWay1: function () {
    var nowTime = util.formatTime(new Date());
    console.log('----', this.data.imgUrl)
   
    let that = this;
    let n = -1;
    let arr = []
    if (this.data.imgUrl) {
      let data = this.data.imgUrl[0];
      let typeArr = data.split('.');
      let type = typeArr[typeArr.length - 2] + '.' + typeArr[typeArr.length - 1];
      uploadImage(type, data, 'img/' + nowTime + '/',
        function (result) {
          arr = arr.concat(result)
          that.uploadImageTemplateWay(arr); // 保存到数据库
        }, function (result) {
        }
      )
    } else {
      that.uploadImageTemplateWay();
    }

  },

  // 保存到数据库
  uploadImageTemplateWay: function (result) {
    var that = this;
    let params = [];
    if (!phoneRegWay(that.data.userInfo.mobilePhone)) {
      return;
    }
    if (!idCardRegWay(that.data.userInfo.idNumber)) {
      return;
    }
    let data = {
      "patientName": that.data.userInfo.nickName,
      "avatarUrl": result ? result[0] : undefined,
      idNumber: that.data.userInfo.idNumber,
      patientPhone: that.data.userInfo.mobilePhone
    };
    app.agriknow2.editPersonalInformatiIon(data, 'noloading').then(res => {
      if (res.code === 0) {
        wx.showToast({
          title:'修改成功',
          icon: 'success',
          duration: 1000,
        })
        setTimeout(function () {
          wx.navigateBack({ })
        }, 1500)

      }else{
        wx.showToast({
          title: res.msg,
        })
      }
    })
  },


  // 进行信息保存
  addSure(){
    let that = this;
    // if (that.data.userInfo.userName.length < 1){
    //   wx.showToast({
    //     title: '请输入患者姓名',
    //     icon:'none'
    //   })
    //   return;
    // }

    if (!phoneRegWay(that.data.userInfo.mobilePhone)) {
      return;
    }
    if (!idCardRegWay(that.data.userInfo.idNumber)) {
      return;
    }
    
  },

  // 身份证
  idNumberBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name !== '' && name.length === 18) {
      that.setData({ idNumberStu: true })
    } else {
      that.setData({ idNumberStu: false })
    }
    that.setData({
      ['userInfo.idNumber']: name,
    })
  },

  // 手机号
  mobilePhoneBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name !== '' && name.length === 11) {
      that.setData({ mobilePhoneStu: true })
    } else {
      that.setData({ mobilePhoneStu: false })
    }
    that.setData({
      ['userInfo.mobilePhone']: name,
    })
  },

  // 姓名
  userNameBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name.length > 1) {
      that.setData({ userNameStu: true })
    } else {
      that.setData({ userNameStu: false })
    }
    that.setData({
      ['userInfo.nickName']: name,
    })
  },

  // 推荐患者
  addHuanzheBtn() {
    wx.navigateTo({ url: '../user_3info_huanzhe_tuijian/index' }); // 患者信息
  },

  // 发送消息
  sendInfo() {
    wx.navigateTo({ url: '../user_2info_Rhuanzhe_send_info/index' }); // 发送消息
  },

  userQRTo(){
    wx.navigateTo({
      url: '../user_add_QR/index',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  // 性别选择
  bindSexChange(e){
    this.setData({
      sexIdx: e.detail.value
    })
  },

  // 事件模板选择
  bindPickerChange1(e) {
    this.setData({
      index1: e.detail.value
    })
  },

  // 执行人选择
  bindPickerChange2(e) {
    this.setData({
      index2: e.detail.value
    })
  },

  // 显示加载动画
  showLoading: function () {
    wx.showLoading({
      title: '加载中...',
      icon: 'loading'
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },



  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
      * 用户点击右上角分享
      */
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '医好康',
      path: 'pages/index_message_list/index',
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  },
})

/**
 * 提示框
 */
function showToastWay(msg) {
  wx.showToast({
    title: msg,
    icon: 'none',
    duration: 1500
  })
}

/**
*  身份证验证
*/
function idCardRegWay(phone) {
  if (phone == null || phone == '') {
    showToastWay('请输入身份证')
    return false;
  }
  var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;

  if (!reg.test(phone)) {
    showToastWay('请输入有效！')
    return false;
  }
  return true;
}

/**
*  手机号码验证
*/
function phoneRegWay(phone) {
  if (phone == null || phone == '') {
    showToastWay('请输入手机号')
    return false;
  }
  var phoneReg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
  if (!phoneReg.test(phone)) {
    showToastWay('请输入有效手机号！')
    return false;
  }
  return true;
}