// miniprogram/pages/user_order_list/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '患者信息', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20, 
    userList: [{ sel: 1 }, { sel: 0 }, { sel: 0},],

    huanzhe:-1,
    imgUrlData:['',''],

    userNameStu: true,//昵称
    idNumberStu: true,//身份证

    nowIdx:0,

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getUserList();
  },

  /**
 * 生命周期函数--监听页面显示
 */
  onShow: function () {
   
  },
  /**
 * 页面相关事件处理函数--监听用户下拉动作
 */
  onPullDownRefresh: function () {
    this.getUserList();
  },

  // 患者列表
  getUserList() {
    let that = this;
    let params = {
      // "relationship": 2 //与患者关系  1：本人 2：亲属 3：朋友
    };
    app.agriknow2.queryClientInfoByAll(params).then(res => {
      if (res.code === 0) {
        let data = res.data.list;
        if (data.length > 0){
          for(var item in data){
            data[item].idx = item;
          }
          that.setData({ huanzhe: 1, userList: data});
        }
      }
    })
  },

  // 内容收缩
  selBtn(e){
    let idx = e.currentTarget.dataset.idx;
    let userList = this.data.userList
      // for(var item in userList){
      //   userList[item].sel = 0;
      // }
    userList[idx].sel = userList[idx].sel ? 0 : 1;
    // userList[idx].sel = 1;
    this.setData({ userList: userList, nowIdx: idx})
  },

  // 图片放大
  previewImage122: function (e) {
    let item = e.currentTarget.dataset.item;
    console.log('----', item.idx)
    let datas = this.data.userList[parseInt(item.idx)].imgPathList;
    wx.previewImage({
      current: e.currentTarget.id, // 当前显示图片的http链接
      urls: datas // 需要预览的图片http链接列表
    })
  },

  userQRTo() {
    wx.navigateTo({
      url: '../user_add_QR/index',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },


  // 显示加载动画
  showLoading: function () {
    wx.showLoading({
      title: '加载中...',
      icon: 'loading'
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },



  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '医好康',
      path: 'pages/index_message_list/index',
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  }
})

/**
 * 提示框
 */
function showToastWay(msg) {
  wx.showToast({
    title: msg,
    icon: 'none',
    duration: 1500
  })
}