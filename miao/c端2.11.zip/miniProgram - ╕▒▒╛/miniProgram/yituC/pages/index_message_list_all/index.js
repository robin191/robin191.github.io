// pages/message_list/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
// pages/message_list/index.js
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '医好康', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20, 

    isStop:false,
    eventArr: [
      'EVENT_TYPE_PATIENT_INFO',
      'EVENT_TYPE_IMAGE_UPLOAD',
      'EVENT_TYPE_SCHEDULE_TEMPELE',
      'EVENT_TYPE_FILE_UPLOAD',
      'EVENT_TYPE_VIDEO_UOLOAD',
      'EVENT_TYPE_SET_TIME',
    ],

    projectStatu: 0,
    leftStu: 0,
    messageList: [ ],

    selDelList: [],
    // 字幕滚动
    text: "欢迎您登录到医好康。我们专注于为医疗机构提供2B2C...",
    step: 1, //滚动速度
    distance: 0, //初始滚动距离
    space: 30,
    interval: 20, // 时间间隔

    // 左滑删除
    delBtnWidth: 88,
    selBtnWidth: 30,
    list: [],
    startX: "",

    nowPage: 1,
    hasData: -1, // -1 初始化   1 有数据  0 无数据
    isLoading: -1, // -1 初始化   1 加载    0 隐藏
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  /**
  * 生命周期函数--监听页面显示
  */
  /**
     * 生命周期函数--监听页面显示
     */
  onShow: function () {
    this.initEleWidth();
   
    // 滚动字幕 开始
    // var that = this;
    // var query = wx.createSelectorQuery();
    // //选择id
    // query.select('#mjltest').boundingClientRect()
    // query.exec(function (res) {
    //   var length = res[0].width;
    //   var windowWidth = wx.getSystemInfoSync().windowWidth; // 屏幕宽度

    //   that.setData({
    //     length: length,
    //     windowWidth: windowWidth,
    //     space: windowWidth
    //   });
    //   that.scrollling(); // 第一个字消失后立即从右边出现
    // });
    // 滚动字幕 结束
    this.oneWay(); // 获取信息列表
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  // 第一次加载
  oneWay(type) {
    this.setData({ nowPage: 1 });
    let that = this;
    let params = {
      "page": that.data.nowPage + '',
      "limit": "10",
      "isRead": "1"
    };
    app.agriknow2.queryMessagesCenter(params, 'noloading').then(res => {
      if (type === 'pull') {
        // 隐藏导航栏加载框  
        wx.hideNavigationBarLoading();
        // 停止下拉动作  
        wx.stopPullDownRefresh();
      }
      if (res.code === 0) {
        let data = res.data.list;
        if (data.length >= 1) {
          that.setData({ projectStatu: 1 });
        } else {
          that.setData({ projectStatu: -1});
        }
        if (data.length >= 10) {
          that.setData({ hasData: 1, nowPage: that.data.nowPage + 1, });
        } else {
          that.setData({ hasData: -1 });
        }
        for (var item in data) {
          let time = data[item].messageDate ? data[item].messageDate.substring(5, 7) : data[item].messageDate;
          data[item].data1 = time;
          data[item].createTime = data[item].messageDate ? data[item].messageDate.substring(5, 16) : data[item].messageDate
        }
        that.setData({ messageList: data })
      }
    })
  },


  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.hasData == 1) {
      this.listMessage(); // 获取信息列表
    }
  },


  // 信息列表 未读
  listMessage() {
    let that = this;
    let params = {
      "page": that.data.nowPage + '',
      "limit": "10",
      "isRead": "1"
    };
    let selBtnWidth = this.data.selBtnWidth;
    let messageList = this.data.messageList;

    let leftStu = this.data.leftStu;
    

    that.setData({ isLoading: 1 });
    app.agriknow2.queryMessagesCenter(params, 'noloading').then(res => {
      that.setData({ isLoading: 0 });
      if (res.code === 0) {
        let data = res.data.list;
        if (data.length < 10) {
          that.setData({ hasData: 0 });
        } else {
          that.setData({ hasData: 1, nowPage: that.data.nowPage + 1, });
        }

        if (leftStu === 1) { // 全部删除已有
          for (var item in data) {
            data[item].txtStyle = "right:-" + selBtnWidth + "px";
            data[item].selDel = 0;
          }
        }else{
          for (var item in data) {
            let time = data[item].messageDate ? data[item].messageDate.substring(5, 7) : data[item].messageDate;
            data[item].data1 = time;
            data[item].createTime = data[item].messageDate ? data[item].messageDate.substring(5, 16) : data[item].messageDate
          }
        } 
       
       
        
        that.setData({ messageList: that.data.messageList.concat(data) })

      }
    })
  },
  
  // 进入详情
  checkDetail(e) {
    let item = e.currentTarget.dataset.item;
    let stu = e.currentTarget.dataset.messageType;
    let url = '../index_message_detail/index?info=' + JSON.stringify(item); // 系统消息 推荐


    if (stu === "1") { // 事件详情
      url = '../index_message_detail_incident_huanzhe/index?info=' + JSON.stringify(item);
    }
    wx.navigateTo({
      url: url,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },


  // 消息删除
  deleteMyMessage(type, data) {
    let that = this;

      let params = [data]; // 单个删除
      let messageList = that.data.messageList;
      if (type === 2) { // 多个删除
        params = [];
        for (var item in messageList) {
          if (messageList[item].selDel === 1) {
            params.push(messageList[item].messageId);
          }
        }
      }
      // 对原数组进行删除
      for (var i in messageList){
        for (var item in params) {
          if (messageList[i].messageId == params[item])
            messageList.splice(i, 1);
        }
      }
     
      that.setData({ messageList: messageList });
      app.agriknow2.deleteMyMessage(params).then(res => {
        if (res.code == 0) {
          wx.showToast({
            title: (params.length) + '条 删除成功',
          })
          if(that.data.messageList.length <= 0){
            that.setData({ projectStatu : -1});
          }
          // that.oneWay(); // 信息列表
        }
      })
      // that.setData({ messageList: messageList})
    
  },

  // 向右滑动 多个删除 左上角删除按钮
  selDelShowBtn() {
    let selBtnWidth = this.data.selBtnWidth;
    let messageList = this.data.messageList;

    let leftStu = this.data.leftStu;
    if (leftStu === 0) {
      for (var item in messageList) {
        messageList[item].txtStyle = "right:-" + selBtnWidth + "px";
      }
      this.setData({ leftStu: 1 });
       for (var item in messageList) {
        messageList[item].selDel = 0;
      }
      this.setData({ messageList: messageList });
    } else if (leftStu === 1) {
      let that = this;
      let isSel = [];
      for (var item in messageList){
        if (messageList[item].selDel == 1){
          isSel.push(messageList[item]);
        }
      }
      if (isSel.length > 0){
        wx.showModal({
          title: '提示',
          content: '是否删除',
          success: function (res) {
            if (res.confirm) {

              that.deleteMyMessage(2, undefined); // 删除api
              for (var item in messageList) {
                messageList[item].txtStyle = "";
              }
              that.setData({ leftStu: 0 });
              that.setData({ messageList: messageList });
            } else if (res.cancel) {
              wx.showToast({
                title: '您已取消',
                icon: 'none'
              })
            }
          }
        });
      }else{
        for (var item in messageList) {
          messageList[item].txtStyle = "";
        }
        that.setData({ leftStu: 0 });
        that.setData({ messageList: messageList });
      }
      

      
    }

 
    // // 重置所选择的， 先进行删除再重置
   
  },

  //点击删除按钮事件
  delItem: function (e) {
    //获取列表中要删除项的下标
    let that = this;
    var index = e.currentTarget.dataset.index;
    var messageList = that.data.messageList;
    wx.showModal({
      title: '提示',
      content: '是否删除',
      success: function (res) {
        if (res.confirm) {
          that.deleteMyMessage(1, messageList[index].messageId); // 删除api
        } else if (res.cancel) {
          messageList[index].txtStyle = "left:-" + 0 + "px";
          that.setData({ messageList: messageList})
            wx.showToast({
              title: '您已取消',
              icon: 'none'
            })
        }
      }
    });

   
    // this.setData({ messageList: this.data.messageList.space(index,1)})
  },

  // 删除 选择
  selDelBtn(e) {
    let index = e.target.dataset.idx;
    let messageList = this.data.messageList;
    messageList[index].selDel = messageList[index].selDel === 1 ? 0 : 1;
    this.setData({ messageList: messageList });
  },


  touchS: function (e) {
    if (this.data.leftStu === 0){
      if (e.touches.length == 1) {
        this.setData({
          //设置触摸起始点水平方向位置
          startX: e.touches[0].clientX
        });
      }
    }
    
  },
  touchM: function (e) {
    if (this.data.leftStu === 0) {
      this.setData({ isStop:true})
      if (e.touches.length == 1) {
        
        var messageList = this.data.messageList;
        for (var item in messageList){
          messageList[item].txtStyle = "left:-" + 0 + "px";
        }

       

        //手指移动时水平方向位置
        var moveX = e.touches[0].clientX;
        //手指起始点位置与移动期间的差值
        var disX = this.data.startX - moveX;
        var delBtnWidth = this.data.delBtnWidth;
        var txtStyle = "";
        if (disX == 0 || disX < 0) {//如果移动距离小于等于0，说明向右滑动，文本层位置不变
          txtStyle = "left:0px";
        } else if (disX > 0) {//移动距离大于0，文本层left值等于手指移动距离
          txtStyle = "left:-" + disX + "px";
          if (disX >= delBtnWidth) {
            //控制手指移动距离最大值为删除按钮的宽度
            txtStyle = "left:-" + delBtnWidth + "px";
          }
        }
        //获取手指触摸的是哪一项
        var index = e.currentTarget.dataset.index;
        messageList[index].txtStyle = txtStyle;
        //更新列表的状态
        this.setData({
          messageList: messageList
        });
      }
    }
  },
  touchE: function (e) {
    if (this.data.leftStu === 0) {
      if (e.changedTouches.length == 1) {
        //手指移动结束后水平位置
        var endX = e.changedTouches[0].clientX;
        //触摸开始与结束，手指移动的距离
        var disX = this.data.startX - endX;
        var delBtnWidth = this.data.delBtnWidth;
        //如果距离小于删除按钮的1/2，不显示删除按钮
        var txtStyle = disX > delBtnWidth / 2 ? "left:-" + delBtnWidth + "px" : "left:0px";
        //获取手指触摸的是哪一项
        var index = e.currentTarget.dataset.index;
        var messageList = this.data.messageList;
        messageList[index].txtStyle = txtStyle;
        //更新列表的状态
        this.setData({
          messageList: messageList
        });
      }
    }
    this.setData({ isStop: false })
  },
  //获取元素自适应后的实际宽度
  getEleWidth: function (w) {
    var real = 0;
    try {
      var res = wx.getSystemInfoSync().windowWidth;
      var scale = (750 / 2) / (w / 2);//以宽度750px设计稿做宽度的自适应
      real = Math.floor(res / scale);
      return real;
    } catch (e) {
      return false;
      // Do something when catch error
    }
  },
  initEleWidth: function () {
    var delBtnWidth = this.getEleWidth(this.data.delBtnWidth);
    this.setData({
      delBtnWidth: delBtnWidth
    });
  },


 

  scrollling: function () {
    var that = this;
    var length = that.data.length; //滚动文字的宽度
    var windowWidth = that.data.windowWidth; //屏幕宽度
    var interval = setInterval(function () {
      var maxscrollwidth = length + that.data.space;
      var left = that.data.distance;
      if (left < maxscrollwidth) { //判断是否滚动到最大宽度
        that.setData({
          distance: left + that.data.step
        })
      } else {
        that.setData({
          distance: 0 // 直接重新滚动
        });
        clearInterval(interval);
        that.scrollling();
      }
    }, that.data.interval);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
     * 用户点击右上角分享
     */
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '医好康',
      path: 'pages/index_message_list/index',
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  }
})