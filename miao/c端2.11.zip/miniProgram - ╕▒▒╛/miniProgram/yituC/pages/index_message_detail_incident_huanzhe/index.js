// miniprogram/pages/project_list_detail_ memo_add/index.js
const app = getApp();
var uploadImage = require('../../utils/uploadFile.js');
var util = require('../../utils/util.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 组件所需的参数
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '查看详情', //导航栏 中间的标题
    },
    height: app.globalDatas.height * 2 + 20, 

    projectStatu:1,
    isBtn: false,
    nowPage: 1,
    hasData: -1, // -1 初始化   1 有数据  0 无数据
    isLoading: 1, // -1 初始化   1 加载    0 隐藏

    imgUrl: [],
    videoUrl: [],
    imgUrlGetApi: [], // 从后台获取到地址，保存到数据库
    imgUrlData: [], // 后台获取到的数据
    incidentDetail:{},
    eventCode:'YY000600420002',
    userInfo: {
      "projectCode": "",
      "eventCode": "",
      "relationship":"" ,//患者关系
      "patientSex": 1, //性别
      "patientCode": "",// 患者编码
      "patientName": "",
      "patientPhone": "", //患者手机号
      "idNumber": "",
      "patientWeight": "", //体重
      "allergyHistory": "",
      "diagnoseIllness": "",
      "detailsOfIllness": "",

isAllergy:1,
      
      // "eventCode": "",
      // "patientName": "",
      // "sex": 1,
      // "idNumber": "",
      // "birthday": "",
      // "weight": "",
      // "isAllergy": 1,
      // "allergyDetail": "",
      // "disease": "",
      // "diseaseDetail": "",
      // "versionNo": "",
      // mobilePhone:'',
    },
    mobilePhoneStu:true,



    array1: [],
    index1: 0,

    relation:['本人','亲属','朋友'],
    relationIdx:0,

    sexArr: ['男', '女'],
    sexIdx: 0,

    guominArr: ['否', '是'],
    guominIdx: 0,

    userNameStu: true,//昵称
    idNumberStu: true,//身份证

    diseaseType: 0,
    userDetail: { yiyuan: { type: 0 }, zhensuo: {} },

    isShowKeshi: 1, // 1 显示  0 不显示



    zhenduan:'',
    guomin:'',
    detail:'',

    names:'',
    toastTitle: '',
    toastInfo: '',
    toastIsStu: false,

    saoNoUser:1, // 1 显示  0 隐藏
    mobelStu: 0,  // 输入手机号  1 弹  0 隐藏
    messageInfo:undefined,
    messageInfo2: {  },
  
   

    imgUrl: [],
    videoUrl: [],
    imgUrlGetApi: [], // 从后台获取到地址，保存到数据库
    imgUrlData:[], // 后台获取到的数据
    isOperation: true, // 确认提交 
    

    huanzhe:{},
    noBtn:false, // 不可操作
    info: { messageId:'1343'},

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if(options){
      let info = JSON.parse(options.info);
      this.setData({ messageInfo: info });
      this.setData({ info: info, eventCode: info.eventCode, projectCode: info.projectCode });
    }

    if (this.data.info.isComplete === '1'){ // 当患者模板执行之后，进行查看患者信息
      this.setData({ isOperation: false }); // 可进行编辑
      this.clientQueryEventDetails(this.data.info);
    }
    this.queryEventMessage(this.data.info); // 患者详情
    this.readMessage(this.data.info); // 消息读取

   
    if (wx.getStorageSync('zhenduan')) {
      wx.removeStorageSync('zhenduan')
    }
    if (wx.getStorageSync('guomin')) {
      wx.removeStorageSync('guomin')
    }
    if (wx.getStorageSync('detail')) {
      wx.removeStorageSync('detail')
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (wx.getStorageSync('zhenduan') && wx.getStorageSync('zhenduan').length > 0) {
      this.setData({ ['userInfo.diagnoseIllness']: wx.getStorageSync('zhenduan') })
    } else {
      this.setData({ ['userInfo.diagnoseIllness']: '' })
    }
    if (wx.getStorageSync('guomin') && wx.getStorageSync('guomin').length > 0) {
      this.setData({ ['userInfo.allergyHistory']: wx.getStorageSync('guomin') })
    } else {
      this.setData({ ['userInfo.allergyHistory']: '' })
    }
    if (wx.getStorageSync('detail') && wx.getStorageSync('detail').length > 0) {
      this.setData({ ['userInfo.detailsOfIllness']: wx.getStorageSync('detail') })
    } else {
      this.setData({ ['userInfo.detailsOfIllness']: '' })
    }

  },

  /**
  * 页面相关事件处理函数--监听用户下拉动作
  */
  onPullDownRefresh: function () {
    // 显示顶部刷新图标  
    wx.showNavigationBarLoading();
    this.queryEventMessage(this.data.info);
    this.readMessage(this.data.info);
    if (wx.getStorageSync('zhenduan')) {
      wx.removeStorageSync('zhenduan')
    }
    if (wx.getStorageSync('guomin')) {
      wx.removeStorageSync('guomin')
    }
    if (wx.getStorageSync('detail')) {
      wx.removeStorageSync('detail')
    }
   

    // 隐藏导航栏加载框  
    wx.hideNavigationBarLoading();
    // 停止下拉动作  
    wx.stopPullDownRefresh();
  },

  
  // 患者信息
  clientQueryEventDetails(datas) {
    let that = this;
    let params = { "eventCode": datas.eventCode };
    app.agriknow2.clientQueryEventDetails(params).then(res => {
      if (res.code == 0) {
        that.setData({ userInfo: res.data, imgUrl: res.data.imgUrlList });
      }
    })
  },

  // 事件信息 详情
  queryEventMessage(datas) {
    let that = this;
    let params = { "eventCode": that.data.eventCode };
    app.agriknow2.queryEventMessage(params).then(res => {
      if (res.code == 0) {
        that.setData({ incidentDetail: res.data, projectCode: res.projectCode });
      }
    })
  },


  deleteImg(e) {
    let that = this, imglist = this.data.imgUrl
    wx.showModal({
      title: '提示',
      content: '您要删除这张图片吗?',
      success(res) {
        if (res.confirm) {
          imglist.splice(e.currentTarget.dataset.index, 1)
          that.setData({
            imgUrl: imglist
          })
        }
      }
    })
  },

  // 图片放大
  previewImage: function (e) {
    wx.previewImage({
      current: e.currentTarget.id, // 当前显示图片的http链接
      urls: this.data.imgUrl // 需要预览的图片http链接列表
    })
  },


  // 消息变为已读
  readMessage(datas) {
    let that = this;
    let params = {
      messageID: that.data.info.messageId
    };
    app.agriknow2.readMessagePro111(params).then(res => {
      if (res.code === 0) {
      }
    })
  },


  // 患者详情
  queryPatientInfoByEvent() {
    let that = this;
    let params = { "eventCode": that.data.eventCode, };
    app.agriknow2.queryPatientInfoByEvent(params).then(res => {
      if (res.code === 0) {
        
        that.setData({ userInfo: res.projectPatient, sexIdx: parseInt(res.projectPatient.sex)-1});
      }
    })
  },

  // 身份证
  idNumberBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name !== '' && name.length === 18) {
      that.setData({ idNumberStu: true })
    } else {
      that.setData({ idNumberStu: false })
    }
    that.setData({
      ['userInfo.idNumber']: name,
    })
  },

  // 手机号
 mobilePhoneBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name !== '' && name.length === 11) {
      that.setData({ mobilePhoneStu: true })
    } else {
      that.setData({ mobilePhoneStu: false })
    }
    that.setData({
      ['userInfo.patientPhone']: name,
    })
  },

  // 姓名
  userNameBlur(e) {
    var that = this;
    let name = e.detail.value;
    if (name.length > 1 && name.length < 15) {
      that.setData({ userNameStu: true })
    } else {
      that.setData({ userNameStu: false })
    }
    that.setData({
      ['userInfo.patientName']: name,
    })
  },

  // 体重
  weightBlur(e) {
    var that = this;
    let name = e.detail.value;
    that.setData({
      ['userInfo.patientWeight']: name,
    })
  },
  

  // 关系选择
  relationChange(e) {
    this.setData({
      relationIdx: e.detail.value
    })
  },


  // 性别选择
  bindSexChange(e) {
    this.setData({
      sexIdx: e.detail.value
    })
  },

  
   // 过敏史
  bindGuominChange(e) {
    this.setData({
      guominIdx: e.detail.value
    });

    if (e.detail.value == 0){
      wx.removeStorageSync('guomin');
      this.setData({ ['userInfo.allergyHistory']:''});
    }
  },

  //上传图片 从云服务取到地址
  updloadWay1: function () {
    let that = this;
    if (!that.data.userInfo.patientName || that.data.userInfo.patientName.length <= 1 || that.data.userInfo.patientName.length > 15){
      wx.showModal({
        title: '错误提示',
        content: '请填写患者姓名(15个字符)',
        showCancel: false,
        success: function (res) { }
      });
      return;
    }
    if (!phoneRegWay(that.data.userInfo.patientPhone)) {
      return;
    }
    if (!phoneRegWay2(that.data.userInfo.idNumber)) {
      return;
    }

    if (that.data.guominIdx == 0){
      that.setData({ ['userInfo.allergyHistory']:''});
    }

    var nowTime = util.formatTime(new Date());
    let data = this.data.imgUrl;
  
    that.setData({ noBtn:true});
    let n = -1;
    if (data.length > 0){
      for (var item in data) {
        let typeArr = data[item].split('.');
        let type = typeArr[typeArr.length - 2] + '.' + typeArr[typeArr.length - 1];
        uploadImage(type, data[item], 'img/' + nowTime + '/',
          function (result) {
            n++;
            that.setData({ imgUrlGetApi: that.data.imgUrlGetApi.concat(result) })
            if (n == data.length - 1 && item == data.length - 1) {
              that.uploadImageTemplateWay(); // 保存到数据库
            }
          }, function (result) {
          }
        )
      }
    }else{
      that.uploadImageTemplateWay(); // 保存到数据库
    }
    
  },

  // 首页-事件提交-患者信息模板
  uploadImageTemplateWay() {
    var that = this;

    that.setData({
      ['userInfo.relationship']: parseInt(that.data.relationIdx)+1,
      ['userInfo.patientSex']: parseInt(that.data.sexIdx) + 1,
      ['userInfo.projectCode']: that.data.incidentDetail.projectCode,
      ['userInfo.eventCode']: that.data.eventCode,
      ['userInfo.patientCode']: that.data.incidentDetail.eventExecutorCode,
      ['userInfo.messageReceiverRelationId']: that.data.incidentDetail.messageReceiverRelationId,
      ['userInfo.isAllergy']: parseInt(that.data.guominIdx)
    })
    let fileInfos = [];
    let imgUrlGetApi = that.data.imgUrlGetApi;
    for (var item in imgUrlGetApi) {
      var namearr = imgUrlGetApi[item].split('/');
      var name = namearr[namearr.length - 1];
      let data = {
        "projectCode": that.data.incidentDetail.projectCode,
        "eventCode": that.data.eventCode,
        "fileName": name,
        "path": imgUrlGetApi[item],
        "size": 30
      };
      fileInfos.push(data);
    }

    let params = {
      imgUrlList: fileInfos,
      ...that.data.userInfo
    }


    app.agriknow2.editClientInfo(params, 'noloading').then(res => {
      if (res.code == 0) {
        wx.showToast({
          title: '提交成功！',
          icon: 'none'
        })
        setTimeout(function () {
          wx.navigateBack({})
        }, 1500)
      } else {
        wx.showModal({
          title: '错作失败',
          content: res.msg,
          showCancel: false,
          success: function (res) { }
        });
      }
    })
  },



  
  // 跳转输入内容
  disease(e) {
    this.setData({ diseaseType: e.currentTarget.dataset.type })
    wx.navigateTo({
      url: '/pages/manage_keshi_disease/index?type=' + e.currentTarget.dataset.type,
    })
  },

  // 详情图片列表
  queryFilesByEventCode() {
    let that = this;
    let params = { "eventCode": that.data.eventCode, };
    app.agriknow2.queryFilesByEventCode(params).then(res => {
      if (res.code === 0) {
        let data = res.fileInfoList;
        let arr = [];
        for(var item in data){
          arr.push(data[item].path);
        }
        that.setData({ imgUrlData: arr});
      }
    })
  },


  // 图片选择
  chooseImage: function (e) {
    var that = this;
    if (this.data.imgUrl.length >= 9) {
      wx.showToast({
        title: '最多上传九张',
        icon: 'none'
      })
      return false;
    }
    wx.chooseImage({
      count: 9 - this.data.imgUrl.length,
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        that.setData({
          imgUrl: that.data.imgUrl.concat(res.tempFilePaths)
        });
      }
    })
  },


 





  // 图片放大
  previewImage: function (e) {
    wx.previewImage({
      current: e.currentTarget.id, // 当前显示图片的http链接
      urls: this.data.imgUrl // 需要预览的图片http链接列表
    })
  },

  
  // 弹框窗口设置
  toastSetWay(title, info, stu) {
    var that = this;
    that.setData({ toastTitle: title, toastInfo: info, toastIsStu: stu });
    if (stu){
      var time = setInterval(function () {
        that.setData({ toastTitle: title, toastInfo: info, toastIsStu: false });
        clearInterval(time);
      }, 3000);
    }
  },
  

  sureBtn(){
        wx.navigateTo({ url: '../index_message_list/index' }); // 跳转到售票页面
  },

  

  // 时间选择
  bindTimeChange(e) {
    this.setData({
      time: e.detail.value
    })
  },

 

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

 
  /**
     * 用户点击右上角分享
     */
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
    }
    return {
      title: '医好康',
      path: 'pages/index_message_list/index',
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  }
})

/**
 * 提示框
 */
function showToastWay(msg) {
  wx.showToast({
    title: msg,
    icon: 'none',
    duration: 1500
  })
}



/**
*  身份证验证
*/
function phoneRegWay2(phone) {
  if (phone == null || phone == '') {
    showToastWay('请输入身份证')
    return false;
  }
  var reg = /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/;

  if (!reg.test(phone)) {
    showToastWay('请输入有效身份证！')
    return false;
  }
  return true;
}

/**
*  手机号码验证
*/
function phoneRegWay(phone) {
  if (phone == null || phone == '') {
    showToastWay('请输入手机号')
    return false;
  }
  var phoneReg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
  if (!phoneReg.test(phone)) {
    showToastWay('请输入有效手机号！')
    return false;
  }
  return true;
}