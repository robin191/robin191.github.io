const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    nvabarData: {
      showCapsule: 1, //是否显示左上角图标   1表示显示    0表示不显示
      title: '问题咨询', //导航栏 中间的标题
    },
    wheight: "0px",
    scrollHeight: "0px",
    height: app.globalDatas.height * 2 + 22,
    page: 1,
    keyWord: "",

    problemList: [
      { 
        createTime: "一月",
        problemInfoVoList: [
          {
            problemContent: "第二医院",
            problemStatus: '0'

          },
          {
            problemContent: "第医院",
            problemStatus: '1'
          }
        ],
        
      },
      {
        createTime: "一月",
        problemInfoVoList: [
          {
            problemContent: "第二医院",
            problemStatus: '0'
          },
          {
            problemContent: "第医院",
            problemStatus: '1'
          }
        ],
      }
    ],
    isHasproblemList: true,

    isScroll: false,
    scrollTop: 0,
    old: {
      scrollTop: 0
    }
    

  },

  /**
   * 生命周期函数--监听页面加载
   */
//   onLoad: function (options) {
//     this.onGetproblemList(this.page, this.keyWord, false)
//   },

//   onNavTopage() {
//     wx.navigateTo({
//       url: "../Online consultation_index/index"
//     })
//   },
//   onGoprobleInfo(problemId) {
//     wx.navigateTo({
//       url: "/pages/wode/myProblem/myproblem-info?problemId=" + problemId
//     })
//   },
//   onScrollChange() {
//     this.page += 1;
//     this.onGetproblemList(this.page, this.keyWord, true)

//   },
//   onScroll(e) {
//     console.log(e, "onscroll")
//     this.old.scrollTop = e.detail.scrollTop
//   },
//   goTop() {
//     wx.nextTick(function () {
//       this.scrollTop = this.old.scrollTop + 1
//     });
//   },
//   onGetproblemList(page, keyWord, isScroll) {
//     let DATA = {
//       page: page + '',
//       limit: "10",
//       keyWord: keyWord,
//     };
//     console.log("刷新");

//     app.agriknow2.problemHomePage(DATA).then(res => {
//       if (res.code === 0) {
//         if (res.data) {
//           this.isHasproblemList = true;
//           if (isScroll) {
//             this.problemList.push(...res.data.list);
//           } else {
//             this.problemList = res.data.list;
//           }

//         } else {
//           if (isScroll) {
//             this.page -= 1;
//           };
//           if (page > 1) {
//             this.isHasproblemList = true;
//           } else {
//             this.isHasproblemList = false;
//           }

//         }

//       } else {
//         this.problemList = [];
//       }

//       console.log(this.problemList)
//     })

//   },
//   onUpdataproble() {
//     // this.onGetproblemList();
//   },
//   onPushproblem() {
//     this.problemList.push(1);
//   },
//   onInputChange(e) {
//     console.log(e);
//     this.keyWord = e.detail.value;
//   },
//   onSearch() {
//     this.page = 1;
//     this.onGetproblemList(this.page, this.keyWord, false)
//   },
//   /**
//  * 生命周期函数--监听页面显示
//  */
  onShow: function () {
    // this.goTop();
    // this.page = 1;
    // this.onGetproblemList(this.page, this.keyWord, false);
    this.setData({ wheight: app.globalDatas.wheight});
    this.setData({ scrollHeight: app.globalDatas.wheight - 136});
    

    
  },
  /**
 * 页面相关事件处理函数--监听用户下拉动作
 */
  onPullDownRefresh: function () {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },



  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  
})

/**
 * 提示框
 */
