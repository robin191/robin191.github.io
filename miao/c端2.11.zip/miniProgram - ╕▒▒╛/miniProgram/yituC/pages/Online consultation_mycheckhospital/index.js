// pages/Online consultation_mycheckhospital/Online consultation_mycheckhospital.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    Height: "0px",
    scrollHeight: "0px",
    tabList: [
      {
        tabName: "附近医院",
        isChecked: true
      },
      {
        tabName: "我的医院",
        isChecked: false
      }
    ],
    info: {},
    hospitalList: [],
    hospitalList1: [],
    hospitalList2: [],
    page: 1,
    latitude: "",
    longitude: "",
    isScroll: true,
    scrollTop: 0,
    old: {
      scrollTop: 0
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.Height = getApp().globalData.Height + 'px';
    this.scrollHeight = (getApp().globalData.Height - 60) + 'px';
    console.log(options, this.Height, this.scrollHeight, 3333333333333)
    this.info = JSON.parse(options.info)
    this.onNear();
    this.onGetHospital(0, this.info);
  },

  onNear() {
    const that = this;
    uni.authorize({
      scope: "scope.userLocation",
      success() {
        uni.getLocation({
          success(e) {
            that.latitude = e.latitude;
            that.longitude = e.longitude;
            that.onNearHospital(1, e.latitude, e.longitude, that.info)
          },
          fail(err) {
            console.log(err);
            uni.showToast({
              title: "网络异常，请稍后重试。",
              icon: "none",
              duration: 2000
            })
          }
        })
      }
    })

  },
  onScrollChange() {
    if (this.isScroll) {
      this.page += 1;
      this.onNearHospital(this.page, this.latitude, this.longitude, this.info)
    }

  },
  onScroll(e) {
    console.log(e, "onscroll")
    if (this.isScroll) {
      this.old.scrollTop = e.detail.scrollTop
    }
  },
  goTop() {
    wx.nextTick(function () {
      this.scrollTop = this.old.scrollTop + 1
    });
  },
  onNearHospital(page, latitude, longitude, options) {
    // let DATA = {
    // 	page:page,
    // 	limit:10,
    // 	latitude:latitude,
    // 	longitude:longitude
    // }

    this.$http_get("/app/problem/obtainNearHospital")
      .then(res => {
        console.log(res);
        if (res.code === 0 && res.data.length > 0) {
          for (let item of res.data || []) {
            this.hospitalList1.push({
              title: item.name || "",
              hospitalCode: item.code || "",
              isChecked: options.hospitalCode === item.code ? true : false,
            })
          }
        } else {
          this.hospitalList1 = []
        }
        this.hospitalList = this.hospitalList1;
        console.log(this.hospitalList)
      })


  },
  onGetHospital(type, options) {
    this.hospitalList2 = [];
    let DATA = {
      type: type
    }
    this.$http_get("/app/patient/obtainHospitalList", { data: DATA })
      .then(res => {
        console.log(res);
        if (res.code === 0) {
          for (let item of res.data || []) {
            this.hospitalList2.push({
              title: item.hospitalName,
              hospitalCode: item.hospitalCode,
              isChecked: options.hospitalCode === item.hospitalCode ? true : false,
            })
          }
        } else {
          this.hospitalList2 = []
        };
        this.hospitalList = this.hospitalList2

      }).catch(err => { console.log(err) })
  },
  onCheckTab(e) {
    console.log("选择的tab", e)
    let index = e.target.id.split('-')[1];
    for (let item of this.tabList) {
      item.isChecked = false;
    }
    this.tabList[index].isChecked = true;
    if (index == 0) {
      this.isScroll = true;
      this.hospitalList = this.hospitalList1;
      this.goTop()
    } else if (index == 1) {
      this.isScroll = false;
      if (this.hospitalList2.length > 0) {
        this.hospitalList = this.hospitalList2;
      } else {
        this.onGetHospital(0, this.info);
      }

    } else {
      for (let item of this.tabList) {
        item.isChecked = false;
      }
      this.onNear()
      this.tabList[0].isChecked = true;
    }

  },
  onItemInfoClick(index) {
    uni.navigateTo({
      url: "/pages/wode/myHospital/myhospital-info?hospitalCode=" + index
    })
  },
  onCheckedRadio(e) {
    console.log(e);
    for (let item of this.hospitalList) {
      item.isChecked = false;
      if (item.hospitalCode === e.target.value) {
        item.isChecked = true;
        uni.$emit("onCheckedHospital", item)
      }
    }

  },
  onNavPage(e) {
    uni.navigateTo({
      url: "/pages/wode/myHospital/myhospital-info?problem=1&hospitalCode=" + e.hospitalCode
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})