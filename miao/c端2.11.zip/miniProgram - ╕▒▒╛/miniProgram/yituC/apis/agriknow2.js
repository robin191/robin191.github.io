/**
 * name: agriknow.js
 * description: 后台api 封装 方法
 */
import request from './request.js'

class agriknow2 {
  constructor() {
    // this._baseUrl = 'http://192.168.1.33:8181/yitu-bsp/' // 本地
    // this._baseUrl = 'http://192.168.1.101:8181/yitu-bsp/' // 服务
    // this._baseUrl = 'http://192.168.1.85:8181/yitu-bsp/' // 本1
    // this._baseUrl = 'http://123.57.15.65:8181/yitu-bsp/' //  医途阿里云地址



    // this._baseUrl = 'http://192.168.1.33:8183/yitu-csp/' //  患者端

    this._baseUrl = 'http://60.205.222.17:8183/yitu-csp/' //  医途阿里云地址
    this._Url = 'http://60.205.222.17:8000' //本部后台地址


    this._defaultHeader2 = { 'Content-Type': 'application/json' }
    this._defaultHeaderToken = { 'token': wx.getStorageSync('token'), 'Content-Type': 'application/json' }
    this._urlencodedToken = { 'token': wx.getStorageSync('token'), 'Content-Type': 'application/x-www-form-urlencoded' }

    this._defaultHeader = { 'Content-Type': 'application/json;charset=utf-8' }
    this._urlencoded = { 'Content-Type': 'application/x-www-form-urlencoded' }
    this._request = new request;
    this._request.setErrorHandler(this.errorHander)
  }

  /**
   * 统一的异常处理方法
   */
  errorHander(res) {
    wx.showToast({
      title: '网络连接异常',
    })
    console.error(res)
    wx.redirectTo({
      url: '../pages/user-login/index'
    })
  }

  /** ***************************************  用户信息 开始 *************************************** **/
  /**
   * 根据 code 获取 openid http://192.168.1.33:8183/yitu-csp/app/login
   */
  userLogin(data) {
    return this._request.postRequest(this._baseUrl + 'app/login', data, this._urlencoded).then(res => res.data);
  }


  /**
   * POST /app/add 解密微信用户基本信息，并添加/更新到数据库
   * referrerCode  referrerCode   userInfo   userInfoIv  phoneNumber   phoneNumberIv
   */
  userAdd(data, token) {
    return this._request.postRequest(this._baseUrl + 'app/add', data, { 'token': token, ...this._urlencodedToken }).then(res => res.data);
  }


  /**
   * POST /app/getPhoneNumber 获取微信用户手机号
   * userInfo userInfoIv  phoneNumber phoneNumberIv
   */
  usergetPhoneNumber(data) {
    return this._request.postRequest(this._baseUrl + 'app/getPhoneNumber', data, this._urlencodedToken).then(res => res.data);
  }


  /**
   * POST 登录4-检查个人信息是否完善
   */
  checkPersonInfo(data) {
    return this._request.postRequest(this._baseUrl + 'client/checkPersonInfo', data, this._urlencodedToken, 'noloading').then(res => res.data);
  }

  /**
   * POST 登录6-个人信息
   */
  queryPersonalInformation(data) {
    return this._request.postRequest(this._baseUrl + 'client/queryPersonalInformation', data, this._urlencodedToken, 'noloading').then(res => res.data);
  }

  /**
  * 登录5-完善个人信息
  */
  perfectClientInfo(data) {
    return this._request.postRequest(this._baseUrl + 'client/perfectClientInfo', data, this._urlencodedToken, 'noloading').then(res => res.data);
  }

  /**
  * 我的-意见反馈
  */
  uploadFeedback(data) {
    return this._request.postRequest(this._baseUrl + 'messagesCenter/uploadFeedback', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  /**
  * 查询患者信息-个人朋友亲属
  */
  queryClientInfoByAll(data) {
    return this._request.postRequest(this._baseUrl + 'client/queryClientInfo', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }




   /** ***************************************  用户信息 结束 *************************************** **/



   /** ***************************************  首页消息 开始 *************************************** **/
  
  /**
    * 扫描医生二维码成为他的患者
    */
  becomeXXspatientScan(data) {
    return this._request.postRequest(this._baseUrl + 'scanQRcode/becomeXXspatient', data, this._urlencodedToken, 'noloading').then(res => res.data);
  }

  /**
    * 首页-查看事件消息2-提交保存患者模板信息
    */
  editClientInfo(data) {
    return this._request.postRequest(this._baseUrl + 'messagesCenter/editClientInfo', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
    * 首页-铃铛-查看已完成的事件信息 患者事件
    */
  clientQueryEventDetails(data) {
    return this._request.postRequest(this._baseUrl + 'client/queryEventDetails', data, this._urlencodedToken).then(res => res.data);
  }

  /**
   * 首页-消息列表 消息删除
   */
  deleteMyMessage(data) {
    return this._request.postRequest(this._baseUrl + 'messagesCenter/deleteMessage', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
   * POST 首页-未读消息  "isRead": 1 已读   0 未读
   */
  queryMessagesCenter(data) {
    return this._request.postRequest(this._baseUrl + 'messagesCenter/queryMessagesCenter', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  /**
   * 首页-查看事件消息1
   */
  queryEventMessage(data) {
    return this._request.postRequest(this._baseUrl + 'messagesCenter/queryEventMessage', data, this._urlencodedToken, 'noloading').then(res => res.data);
  }

  /**
   * 首页-读取消息更新消息状态
   */
  readMessagePro111(data) {
    return this._request.postRequest(this._baseUrl + 'messagesCenter/readMessage', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  /**
 * 首页-推荐消息-查看医院详情[根据项目编码查询]
 */
  queryHospitalDeatilByProjectCode(data) {
    return this._request.postRequest(this._baseUrl + 'myHospital/queryHospitalDeatilByProjectCode', data, this._urlencodedToken, 'noloading').then(res => res.data);
  }

  
  /**
   *首页-查看事件消息2-提交保存患者模板信息
  */
  editClientInfoMsg(data) {
    return this._request.postRequest(this._baseUrl + 'messagesCenter/editClientInfo', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }



   /** ***************************************  首页消息 结束 *************************************** **/




    /** ***************************************  我的 开始 *************************************** **/
  /**
  * 我的-我的医院-推荐医院
  */
  queryRecomendHospitalHos(data,type) {
    let url = 'myHospital/queryAllHospital'
    if(type == 1){
      url = 'myHospital/queryProjectHospital'
    } else if(type == 2){
      url = 'myHospital/queryRecomendHospital'
    }
    return this._request.postRequest(this._baseUrl + url, data, this._defaultHeaderToken).then(res => res.data);
  }
  
  /**
    * 我的-我的医院-推荐医院
    */
  // queryRecomendHospitalHos(data) {
  //   return this._request.postRequest(this._baseUrl + 'myHospital/queryRecomendHospital', data, this._defaultHeaderToken).then(res => res.data);
  // }
  
  /**
    * 我的-我的医院-项目医院
    */
  queryProjectHospitalHos(data) {
    return this._request.postRequest(this._baseUrl + 'myHospital/queryProjectHospital', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
    * 我的-我的医院-所有医院
    */
  queryAllHospitalHos(data) {
    return this._request.postRequest(this._baseUrl + 'myHospital/queryAllHospital', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
    * 我的-医院详情
    */
  queryHospitalDeatilHos(data) {
    return this._request.postRequest(this._baseUrl + 'myHospital/queryHospitalDeatil', data, this._urlencodedToken, 'noloading').then(res => res.data);
  }

  /**
  * 我的-个人信息头像等修改
  */
  editPersonalInformatiIon(data) {
    return this._request.postRequest(this._baseUrl + 'client/editPersonalInformatiIon', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }
     /** ***************************************  我的 结束 *************************************** **/

















  /*************新加 */
  queryHospitalSendmessagePatients(data) {
    return this._request.postRequest(this._baseUrl + 'app/clientuserinfo/queryHospitalSendmessagePatients', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  hospitalSendToPatient(data) {
    return this._request.postRequest(this._baseUrl + 'app/sendmessage/hospitalSendToPatient', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  queryMyPatientRegionList(data) {
    return this._request.postRequest(this._baseUrl + 'app/sysregion/queryMyPatientRegionList', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  /***************************新加接口******************************* */
  /**
     * 推荐管理-确认病患
     */
  queryHospitalRecommends(data) {
    return this._request.postRequest(this._baseUrl + 'app/clientuserinfo/queryHospitalRecommend', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  queryRegionList(data) {
    return this._request.postRequest(this._baseUrl + 'app/sysregion/queryRegionList', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  queryConfirmRecommend(data) {
    return this._request.postRequest(this._baseUrl + 'app/clientuserinfo/queryConfirmRecommend', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }


  /**
    * 管理-推荐报表
    */
  myHospitalRecommendReport(data) {
    return this._request.postRequest(this._baseUrl + 'app/recommend/myHospitalRecommendReport', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }
  /**
   * 管理-项目报表
   */
  myHospitalProjectReport1(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectinfo/myHospitalProjectReport', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }
  /**
    * 我的-反馈
    */
  bUserFeedback(data) {
    return this._request.postRequest(this._baseUrl + 'app/feedback/bUserFeedback', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }


  /**
* 管理-患者注销-扫码二维码
 
*/
  queryConfirmRecommendPage(data) {
    return this._request.postRequest(this._baseUrl + 'app/clientuserinfo/queryConfirmRecommendPage', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
    * 管理-患者注销-确认推荐
   
    */
  confirmRecommend(data) {
    return this._request.postRequest(this._baseUrl + 'app/recommend/confirmRecommend', data, this._defaultHeaderToken).then(res => res.data);
  }
  /*******诊所列表********* */
  queryCooperateWithOrgan(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldetail/queryCooperateWithOrgan', data, this._defaultHeaderToken).then(res => res.data);
  }

  /** *************************************** 项目模块 开始 *************************************** **/

  /**
  *项目详情-项目信息（包含患者信息下面患者关系等信息） POST /app/projecinfo/queryProjectInfo
  */
  queryProjectInfo(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectinfo/queryProjectInfo', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
    * 项目详情-患者信息 病历图片 app/fileinfo/queryFilesByEventCode
    */
  queryFilesByEventCode(data) {
    return this._request.postRequest(this._baseUrl + 'app/fileinfo/queryFilesByEventCode', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
  * 项目详情-患者信息-基本信息 app/projectpatient/queryPatientInfoByProject
  */
  queryPatientInfoByProject(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectpatient/queryPatientInfoByProject', data, this._urlencodedToken).then(res => res.data);
  }

  /**
 * 患者信息-修改患者信息
 */
  updatePatientInfoWithFilesPro(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectpatient/updatePatientInfoWithFiles', data, this._defaultHeaderToken).then(res => res.data);
  }




  /**
   * 新建项目-选择医生（管理员）
   */
  addHospitalDoctorList(data) {
    return this._request.postRequest(this._baseUrl + 'app/doctorhospitalrelation/hospitalDoctorList', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
   * 项目详情-项目信息-查询移交对象
   */
  // queryTransferTeams(data) {
  //   return this._request.postRequest(this._baseUrl + 'app/projectteam/queryEventTransferTeams', data, this._urlencodedToken).then(res => res.data);
  // }

 queryTransferTeams(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectteam/queryTransferTeams', data, this._urlencodedToken).then(res => res.data);
  }

  /**
   * 项目详情-项目信息-项目成员移除
   */
  memberQuit(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectteam/memberQuit', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
    * 项目详情-项目信息-管理员移交
    */
  transferAuthority(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectteam/transferAuthority', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
   * 项目详情- 我要退出
   */
  memberQuit1(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectteam/memberQuit', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
       * 关闭项目  --- 有问题
       */
  closeProject(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectinfo/closeProject', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
     * 项目详情-项目信息-备忘录列表查询 app/doctormemorandum/queryMemorandumList
     */
  queryMemorandumList(data) {
    return this._request.postRequest(this._baseUrl + 'app/doctormemorandum/queryMemorandumList', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  /**
   * 项目详情-项目信息-备忘录新增
   */
  addMemorandum(data) {
    return this._request.postRequest(this._baseUrl + 'app/doctormemorandum/addMemorandum', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
     * 项目详情-项目信息-备忘录修改
     */
  updateMemorandum(data) {
    return this._request.postRequest(this._baseUrl + 'app/doctormemorandum/updateMemorandum', data, this._defaultHeaderToken).then(res => res.data);
  }


  /**
   * 项目详情-项目信息-项目文件   app/fileinfo/queryProjectFiles
   */
  queryProjectFiles(data) {
    return this._request.postRequest(this._baseUrl + 'app/fileinfo/queryProjectFiles', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
   * 项目详情-项目信息-编辑文件（删除）   app/fileinfo/deleteFiles
   */
  deleteFiles(data) {
    return this._request.postRequest(this._baseUrl + 'app/fileinfo/deleteFiles', data, this._defaultHeaderToken).then(res => res.data);
  }


  /**
    * 项目地点下拉框  app/sysregion/queryMyProjectRegionList
    */
  queryMyProjectRegionList(data) {
    return this._request.postRequest(this._baseUrl + 'app/sysregion/queryMyProjectRegionList', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  /**
      * 项目首页-项目列表(传参有更新) 我的项目列表
      */
  queryMyProject(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectinfo/queryMyProject', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }




  /**
  * 项目详情-团队成员 projectCode multipart/form-data app/projectteam/queryProjectTeams
  */
  queryProjectTeams(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectteam/queryProjectTeams', data, this._urlencodedToken).then(res => res.data);
  }

  /**
  * 项目详情-事件列表 projectCode /app/eventinfo/queryEventListOfProject
  */
  queryEventListOfProject(data) {
    return this._request.postRequest(this._baseUrl + 'app/eventinfo/queryEventListOfProject', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  /**
  * 新建事件接口 projectCode /app/eventinfo/addEvent
  */

  addEvent(data) {
    return this._request.postRequest(this._baseUrl + 'app/eventinfo/addEvent', data, this._urlencodedToken, 'noloading').then(res => res.data);
  }

  /**
    * 医院列表 POST /app/hospitaldetail / getMyCooperationHospital
    */
  getMyCooperationHospital(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldetail/getMyCooperationHospital', data, this._urlencodedToken, 'noloading').then(res => res.data);
  }

  /**
    * 医生列表 POST /app/doctordetail/queryDoctorByHospitalById   /app/doctorhospitalrelation/getByHospitalCode
    */
  queryDoctorByHospitalById(data) {
    return this._request.postRequest(this._baseUrl + 'app/doctorhospitalrelation/getByHospitalCode', data, this._urlencodedToken, 'noloading').then(res => res.data);
  }

 


  /**
   * POST 新建项目  app/projectinfo/createProject
   */
  createProject(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectinfo/createProject', data, this._defaultHeaderToken).then(res => res.data);
  }



  /************************ 建立事件  开始  **************************************/

  /**
    * 事件模板数据列表  app/sysdict/querySysDict
    */
  querySysDict(data) {
    return this._request.postRequest(this._baseUrl + 'app/sysdict/querySysDict', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
   * 执行人  app/projectteam/queryProjectTeams
   */
  queryInProjectTeams11(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectteam/queryInProjectTeams', data, this._urlencodedToken).then(res => res.data);
  }

  /**
   * 执行人  app/projectteam/queryProjectTeams
   */
  iqueryProjectTeams(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectteam/queryProjectTeams', data, this._urlencodedToken).then(res => res.data);
  }

  /**
  * 查询患者  app/projectpatient/queryPatientByProjectCode
  */
  iqueryPatientByProjectCode(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectpatient/queryPatientByProjectCode', data, this._urlencodedToken).then(res => res.data);
  }

  /**
 * 建立事件  app/eventinfo/addEvent
 */
  iaddEvent(data) {
    return this._request.postRequest(this._baseUrl + 'app/eventinfo/addEvent', data, this._urlencodedToken).then(res => res.data);
  }


  /************************ 建立事件  结束  **************************************/


  /**
  * POST /app/projectteam/addMembers 添加患者11
  */
  addMembersPro(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectteam/addMembers', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
   * POST /app/projecinfo/addPatientToProject 项目添加患者
   */
  proaddPatientToProject(data) {
    return this._request.postRequest(this._baseUrl + 'app/projecinfo/addPatientToProject', data, this._urlencodedToken).then(res => res.data);
  }



  /**
 * POST /app/projecinfo/delete   删除
 */
  deleteProjecinfo(data) {
    return this._request.postRequest(this._baseUrl + 'app/projecinfo/delete', data, this._urlencodedToken).then(res => res.data);
  }

  /**
 * GET /app/projecinfo/info/{id}  根据ID查询项目信息
 */
  projecinfo(data) {
    return this._request.getRequest(this._baseUrl + 'app/projecinfo/info', data, this._urlencodedToken).then(res => res.data);
  }

  /**
  * POST /app/projecinfo/list  查询项目列表
  */
  projecinfoList(data) {
    return this._request.postRequest(this._baseUrl + 'app/projecinfo/list', data, this._urlencodedToken).then(res => res.data);
  }

  /**
    * POST /app/projecinfo/myHospitalProjectReport  查询项目信息
    */
  myHospitalProjectReport(data) {
    return this._request.postRequest(this._baseUrl + 'app/projecinfo/myHospitalProjectReport', data, this._urlencodedToken).then(res => res.data);
  }






  /**
      * /app/projecinfo/update  修改
      */
  projecinfoUpdate(data) {
    return this._request.postRequest(this._baseUrl + 'app/projecinfo/update', data, this._urlencodedToken).then(res => res.data);
  }



/** *************************************** 项目模块 结束 *************************************** **/



  /** *************************************** 首页 开始 *************************************** **/

  /**
    * 首页-查看事件-患者基本信息
    */
  queryPatientInfoByEvent(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectpatient/queryPatientInfoByEvent', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  /**
   *首页-查看事件-患者病历图片
   */
  queryFilesByEventCode(data) {
    return this._request.postRequest(this._baseUrl + 'app/fileinfo/queryFilesByEventCode', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  /**
   *首页-事件提交-患者信息模板
  */
  commitPatientInfoWithFiles(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectpatient/commitPatientInfoWithFiles', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  /**
   * 首页-事件提交-图片模板
   */
  uploadImageTemplate(data) {
    return this._request.postRequest(this._baseUrl + 'app/fileinfo/uploadImageTemplate', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  /**
 * 首页-事件提交-日程模板
 */
  commitScheduleTemplateModel(data) {
    return this._request.postRequest(this._baseUrl + 'app/myschedule/commitScheduleTemplate', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  /**
  * 首页-事件提交-视频/音频模板
  */
  uploadVideoTemplate(data) {
    return this._request.postRequest(this._baseUrl + 'app/fileinfo/uploadVideoTemplate', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  /**
 * 首页-事件提交-其它文件模板
 */
  uploadOtherFilesTemplate(data) {
    return this._request.postRequest(this._baseUrl + 'app/fileinfo/uploadOtherFilesTemplate', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  
/**
 * 首页-查看事件 - 查询文件信息（各种文件类事件）
 */
  queryFilesByEventCode(data) {
    return this._request.postRequest(this._baseUrl + 'app/fileinfo/queryFilesByEventCode', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
}

  /**
   * 首页-查看事件-查询日程信息
   */
  queryScheduleByEventCode(data) {
    return this._request.postRequest(this._baseUrl + 'app/myschedule/queryScheduleByEventCode', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }
  


  /**
   * 首页-查看事件-查询事件基本信息
   */
  getEventBaseInfo(data) {
    return this._request.postRequest(this._baseUrl + 'app/eventinfo/getEventBaseInfo', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  /**
   * 首页-查看事件-团队成员查看状态
   */
  queryIsRead(data) {
    return this._request.postRequest(this._baseUrl + 'app/messagereceiverrelation/queryIsRead', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  /**
   * 首页-查看事件-添加备注
   */
  addEventRemark(data) {
    return this._request.postRequest(this._baseUrl + 'app/eventremarks/addEventRemark', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  /**
  * 首页-查看事件-备注与移交列表
  */
  eventremarksList(data) {
    return this._request.postRequest(this._baseUrl + 'app/eventremarks/list', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }

  /**
    * 移交事件处理人
    */
  // queryProjectTeamsPro(data) {
  //   return this._request.postRequest(this._baseUrl + 'app/projectteam/queryTransferTeams', data, this._urlencodedToken, 'noloading').then(res => res.data);
  // }
  queryProjectTeamsPro(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectteam/queryEventTransferTeams', data, this._urlencodedToken, 'noloading').then(res => res.data);
  }



  /**
   * 移交事件
   */
  changeEventExecutor(data) {
    return this._request.postRequest(this._baseUrl + 'app/eventinfo/changeEventExecutor', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }


  /**
   * 首页-消息列表（未读、已读）
   */
  listMessage(data,noloading) {
    return this._request.postRequest(this._baseUrl + 'app/sendmessage/listMessage', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }



  /**
   * 首页-消息查看
   */
  readMessage(data) {
    return this._request.postRequest(this._baseUrl + 'app/messagereceiverrelation/readMessage', data, this._defaultHeaderToken, 'noloading').then(res => res.data);
  }


/** *************************************** 首页 结束 *************************************** **/





  /** *************************************** 管理模块 开始 *************************************** **/

    /** ********************************** 患者推荐 开始  ****************/
  
  /**
  * 患者管理-添加患者
  */
  hospitalAddPatient(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldetail/hospitalAddPatient', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
  * 患者管理-患者列表
  */
  queryHospitalPatientsMan(data) {
    return this._request.postRequest(this._baseUrl + 'app/clientuserinfo/queryHospitalPatients', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
 * 患者管理-患者信息  
 */
  queryClientUserinfo(data) {
    return this._request.postRequest(this._baseUrl + 'app/clientuserinfo/queryClientUserinfo', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
    * 添加患者-扫描二维码或输入手机号查询患者信息  POST 
    */
  queryClientUserinfo1(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectinfo/queryClientUserinfo', data, this._defaultHeaderToken).then(res => res.data);
  }


  /**
 * 管理-推荐患者-选择医生列表

 */
  getByHospitalCodeMan(data) {
    return this._request.postRequest(this._baseUrl + 'app/doctorhospitalrelation/getByHospitalCode', data, this._urlencodedToken).then(res => res.data);
  }

  /**
 * 管理-推荐患者-选择机构列表
 */
  queryCooperateWithOrganMan(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldetail/queryCooperateWithOrgan', data, this._defaultHeaderToken).then(res => res.data);
  }


  /**
 * 管理-推荐患者-医生推荐到诊所
 */
  recommendPatientMan(data) {
    return this._request.postRequest(this._baseUrl + 'app/recommend/recommendPatient', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
 * 管理-推荐患者-推荐到医院
 */
  recommendPatient2222(data) {
    return this._request.postRequest(this._baseUrl + 'app/recommend/recommendPatient', data, this._defaultHeaderToken).then(res => res.data);
  }




    /** ********************************** 患者推荐 结束  ****************/

  /** ********************************** 科室管理 开始  ****************/


  /**
      * 科室管理-新增科室类型
      */
  addDepartmentType(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldepartmenttype/addDepartmentType', data, this._defaultHeaderToken).then(res => res.data);
  }


  /**
   * 科室管理-删除科室
   */
  deleteDepartmentType(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldepartmenttype/deleteDepartmentType', data, this._defaultHeaderToken).then(res => res.data);
  }
  /**
      * 科室管理-科室类型
      */
  queryDepartmentTypelist(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldepartmenttype/queryDepartmentTypelist', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
      * 科室管理-科室列表
      */
  getDepartmentVosByHospitalCode(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldepartment/getDepartmentVosByHospitalCode', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
     * 添加医生-科室列表
     */
  hospitaldepartmentLists(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldepartment/list', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
      * 科室管理-科室详情
      */
  queryDepartment(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldepartment/queryDepartment', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
  *管理-科室管理-医生列表
  */
  myHospitalDoctorList(data) {
    return this._request.postRequest(this._baseUrl + 'app/doctorhospitalrelation/myHospitalDoctorList', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
       * 科室管理-科室修改
       */
  updateDepartment(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldepartment/updateDepartment', data, this._defaultHeaderToken).then(res => res.data);
  }
  /**
     * 科室管理-新增科室
     */
  addDepartment(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldepartment/addDepartment', data, this._defaultHeaderToken).then(res => res.data);
  }

  // /**
  //    * 科室管理-修改科室
  //    */
  // updateDepartment(data) {
  //   return this._request.postRequest(this._baseUrl + 'app/hospitaldepartment/updateDepartment', data, this._urlencodedToken).then(res => res.data);
  // }

  /**
     * 科室管理-删除科室
     */
  deleteDepartment(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldepartment/deleteDepartment', data, this._defaultHeaderToken).then(res => res.data);
  }
  /** ********************************** 科室管理 结束  ****************/



  /** ********************************** 医生管理 开始  ****************/
  /**
    * 管理-医生列表
    */
  myHospitalDoctorList(data) {
    return this._request.postRequest(this._baseUrl + 'app/doctorhospitalrelation/myHospitalDoctorList', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
    * 医生详情
    */
  queryHospitalDoctor(data) {
    return this._request.postRequest(this._baseUrl + 'app/doctorhospitalrelation/queryHospitalDoctor', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
      * 管理-医生管理-移除医生
      */
  deleteHospitalDoctor(data) {
    return this._request.postRequest(this._baseUrl + 'app/doctorhospitalrelation/deleteHospitalDoctor', data, this._defaultHeaderToken).then(res => res.data);
  }


  /**
   * 管理-医生管理-医生详情修改
   */
  updateHospitalDoctor(data) {
    return this._request.postRequest(this._baseUrl + 'app/doctorhospitalrelation/updateHospitalDoctor', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
    * 管理-医生管理-新增医生
    */
  addHospitalDoctor(data) {
    return this._request.postRequest(this._baseUrl + 'app/doctorhospitalrelation/addHospitalDoctor', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
  * 管理-医生管理-新增医生确认
  */
  addHospitalDoctorConfirm(data) {
    return this._request.postRequest(this._baseUrl + 'app/doctorhospitalrelation/addHospitalDoctorConfirm', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
  * 管理-医生管理-医生详情修改
  */
  // updateHospitalDoctor(data) {
  //   return this._request.postRequest(this._baseUrl + 'app/doctorhospitalrelation/updateHospitalDoctor', data, this._urlencodedToken).then(res => res.data);
  // }

  /** ********************************** 医生管理 结束  ****************/

  /**
      * 管理-医院信息
      */
  getMyHospitalDetail(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldetail/getMyHospitalDetail', data, this._urlencodedToken).then(res => res.data);
  }

  /**
     *  管理-医院信息-修改
     */
  updateMyHospitalDetail(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldetail/updateMyHospitalDetail', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
  * 推荐管理-待确认+已确认
  */
  queryHospitalRecommend(data) {
    return this._request.postRequest(this._baseUrl + 'app/clientuserinfo/queryHospitalRecommend', data, this._urlencodedToken).then(res => res.data);
  }

  /**
  * 患者管理-患者信息
  */
  queryHospitalPatients(data) {
    return this._request.postRequest(this._baseUrl + 'app/clientuserinfo/queryHospitalPatients', data, this._urlencodedToken).then(res => res.data);
  }

    /** *************************************** 管理模块 开始 *************************************** **/




  /** *************************************** 我的 开始 *************************************** **/
 
  /**
 * 登录-医生角色权限
 */
  getHighestRoleLevelByUserCode(data, noLoading) {
    return this._request.postRequest(this._baseUrl + 'app/doctorhospitalrelation/getHighestRoleLevelByUserCode', data, this._defaultHeaderToken, noLoading).then(res => res.data);
  }
   /** ************* 个人信息 开始 ********* **/
  /**
    * 我的-修改个人详细信息
    */
  updateMyDoctorInfo(data) {
    return this._request.postRequest(this._baseUrl + 'app/doctordetail/updateMyDoctorInfo', data, this._defaultHeaderToken).then(res => res.data);
  }
  /**
   * 我的-个人详细信息
   */
  queryMyDoctorInfo(data) {
    return this._request.postRequest(this._baseUrl + 'app/doctordetail/queryMyDoctorInfo', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
  * 我的-就职医院
  */
  myHospitaldetailList(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldetail/list', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
  * 我的-科室列表
  */
  myHospitaldepartmentList(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldepartment/list', data, this._defaultHeaderToken).then(res => res.data);
  }
  
  /**
  * 我的-职称列表
  */
  myQuerySysDict(data) {
    return this._request.postRequest(this._baseUrl + 'app/sysdict/querySysDict', data, this._defaultHeaderToken).then(res => res.data);
  }
 /** ************* 个人信息 结束 ********* **/

  /** ************* 日程 开始 ********* **/

  /**
   * 我的-我的日程-添加
   */
  addSchedule(data) {
    return this._request.postRequest(this._baseUrl + 'app/myschedule/addSchedule', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
   * 我的日程-根据具体日期查询
   */
  queryMyScheduleByDate(data) {
    return this._request.postRequest(this._baseUrl + 'app/myschedule/queryMyScheduleByDate', data, this._urlencodedToken).then(res => res.data);
  }

  /**
  * 我的日程-根据开始结束日期查询
  */
  queryMySchedules(data) {
    return this._request.postRequest(this._baseUrl + 'app/myschedule/queryMySchedules', data, this._defaultHeaderToken).then(res => res.data);
  }

  /** ************* 日程 结束 ********* **/



  /** *************************** 患者 开始 ************* **/

  /**
     *我的-新增患者
     */
  doctorAddPatient(data) {
    return this._request.postRequest(this._baseUrl + 'app/doctordetail/doctorAddPatient', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
     * 我的-我的患者列表
     */
  queryMyPatients(data) {
    return this._request.postRequest(this._baseUrl + 'app/clientuserinfo/queryMyPatients', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
   * 我的-我的患者-推荐中&已就诊
   */
  queryHospitalRecommend(data) {
    return this._request.postRequest(this._baseUrl + 'app/clientuserinfo/queryHospitalRecommend', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
   * 我的-推荐患者-诊所到医院
   */
  recommendPatient(data) {
    return this._request.postRequest(this._baseUrl + 'app/recommend/recommendPatient', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
   * 我的-推荐患者 - 医院到诊所
   */
  recommendPatient(data) {
    return this._request.postRequest(this._baseUrl + 'app/recommend/recommendPatient', data, this._defaultHeaderToken).then(res => res.data);
  }
  /** *************************** 患者 结束 ************* **/


  /**
   * 我的-个人信息
   */
  getMyHomePageUserInfo(data) {
    return this._request.postRequest(this._baseUrl + 'app/businessuserinfo/getMyHomePageUserInfo', data, this._defaultHeaderToken).then(res => res.data);
  }

  /** *************************** 医院 开始 ************* **/
  /**
  * 我的-正在合作中的医院
  */
  getMyCooperationHospital(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldetail/getMyCooperationHospital', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
  * 我的-历史合作的医院
  */
  getMyHistoryHospital(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldetail/getMyHistoryHospital', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
  * 我的-我的医院-医院信息 详情
  */
  getHospitalDetail(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldetail/getHospitalDetail', data, this._defaultHeaderToken).then(res => res.data);
  }


  /**
  * 我的-我的医院-项目清单
  */
  queryMyProjectHo(data) {
    return this._request.postRequest(this._baseUrl + 'app/projectinfo/queryMyProject', data, this._defaultHeaderToken).then(res => res.data);
  }

  /**
  * 我的-查询我的医院-医院信息
  */
  getHospitalDetailHo(data) {
    return this._request.postRequest(this._baseUrl + 'app/hospitaldetail/getHospitalDetail', data, this._urlencodedToken).then(res => res.data);
  }

  /**
  * 我的-推荐患者-医院到诊所
  */
  recommendPatient(data) {
    return this._request.postRequest(this._baseUrl + 'app/recommend/recommendPatient', data, this._defaultHeaderToken).then(res => res.data);
  }
  /** *************************** 医院 结束 ************* **/

  /** *************************************** 我的 结束 *************************************** **/



 /** *************************************** 问题咨询*************************************** **/
 /**
  * 首页
  */
  problemHomePage(data) {
    return this._request.postRequest(this._Url + 'app/problem/problemHomePage', data, this._defaultHeaderToken).then(res => res.data);
  }

  obtainNearHospital(data) {
    return this._request.getRequest(this._Url + 'app/problem/obtainNearHospital', data, this._defaultHeaderToken).then(res => res.data);
  }






















   










 /** *************************************** sys-address  地址信息 开始 *************************************** **/
  
  /**
     * POST /app/sysaddress/list  列表查询  params
     */
  sysaddress(data) {
    return this._request.postRequest(this._baseUrl + 'app/sysaddress/list', data, this._urlencodedToken).then(res => res.data);
  }




 /** ***************************************  地址信息 结束 *************************************** **/



 /** *************************************** 消息中心  sendmessage 开始 *************************************** **/

 /** ***************************************  消息中心  sendmessage 结束 *************************************** **/



   



  /**
  * 添加优惠券
  */
  addCoupon(data) {
    return this._request.postRequest(this._baseUrl + 'wechat/addCoupon', data).then(res => res.data);
  }

  /**
   * 列表优惠券
   */
  getCouponList(data) {
    return this._request.postRequest(this._baseUrl + 'wechat/couponlist', data).then(res => res.data);
  }


  /**
   * 绘制二维码方法
   */
  getqrcodeApi(data) {
    return this._request.postRequest(this._baseUrl + 'wechat/getqrcode', data).then(res => res.data);
  }

}
export default agriknow2